# Motor Imagery BCI — NPN and Cross-Dataset Transfer

Code for two papers on motor-imagery EEG decoding.

## Paper A — NPN
"Quantifying the Contribution of Neurophysiological Priors to Deep Motor-Imagery
Decoding: Channel Dependence and Data Efficiency"

CSP-initialized deep decoding, controlled against random initialization, with
channel-dependence and data-efficiency experiments across four public datasets.

## Paper B — Cross-Dataset Transfer
"When Does Motor Imagery Transfer Across Datasets? A Twelve-Direction Benchmark
of Alignment, Domain Similarity, and Zero-Labeled-Calibration Decoding"

## Datasets
BCI-IV-2a (22 ch, MI), BCI-IV-2b (3 ch, MI), PhysioNet EEGMMIDB (17 ch, MI),
High-Gamma (17 ch, motor execution). Set your local paths in `npn/config.py`.

## Layout
```
npn/
  variants.py            17-method within-subject harness (NPN, CSP, FBCSP, deep baselines)
  fbcsp_net.py           NPN model (8-band, CSP-initialized spatial layer)
  within_loader.py       BCI-IV-2a/2b loader
  crossdata.py           PhysioNet / High-Gamma loader (COMMON3 and SM 17-channel montage)
  config.py              data paths and settings
  augment.py             segmentation-recombination augmentation
  paper_experiments.py   channel-dependence, data-efficiency, frozen control, Riemannian
  riemann_init.py, riemann_variants.py   Riemannian CSP-init variants
  figures.py, regen_figures.py, flagship_figures.py   paper figures
  make_npn_pipeline_figure.py    pipeline figure from real 2a data
  make_pipeline_panels.py        methodology panels
  stats_tables.py        statistics and result tables
  overnight.py           overnight experiment runner
  prior_experiments/     CSP-Net comparison (Exp A/B, scale-controlled prior, diagnostics)
    prior_experiments.py, moabb_loaders.py, run_prior_experiments.py, test_prior_experiments.py

transfer/
  transfer_fewshot.py, transfer_improve.py, transfer_extended.py   transfer pipeline + factorial
  transfer_stats.py      bootstrap CI, paired permutation (b+1)/(B+1), Holm
  transfer_analysis.py   domain distance, alignment shift, asymmetry
  overnight_transfer.py, overnight_revision.py   runners
  verify_and_consolidate.py    channel verification + paper tables
  make_transfer_figures.py, make_revision_figures.py
```

## Install
```
pip install -r requirements.txt
```
NPN and transfer scripts run from their own folder. The CSP-Net comparison also
needs `pip install moabb` and uses its own MOABB loader.

## Reproduce (NPN)
```
cd npn
python overnight.py                    # within-subject benchmark
python paper_experiments.py            # channels, efficiency, frozen control, Riemannian
python prior_experiments/run_prior_experiments.py run --preset tonight --loader moabb --datasets 2a --seeds 42,43 --root /path/mne_data --out results/prior.csv
python prior_experiments/run_prior_experiments.py summarize --inputs "results/prior*.csv" --out-summary results/prior_summary.csv
```

## Reproduce (transfer)
```
cd transfer
python overnight_transfer.py
python overnight_revision.py
python transfer_stats.py
python verify_and_consolidate.py
```

## Protocol notes
- NPN main experiments: 8-30 Hz zero-phase FIR (MNE default), imagery window
  0.5-2.5 s. The CSP-Net comparison uses the MOABB loader (0.5-4.0 s, both
  sessions) and is reported as a separate, internally matched analysis.
- CSP filters are estimated on the training fold only.
- Transfer is transductive zero-labeled-calibration; target labels never enter
  alignment, the tangent reference, or the classifier.
- Statistics are subject-level with Holm correction.

## License
MIT (see LICENSE).
