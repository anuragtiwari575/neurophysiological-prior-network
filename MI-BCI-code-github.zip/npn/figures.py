"""
Publication figures for the within-subject study, built entirely from
results/master_within.csv (schema: dataset,method,subject,acc with acc in [0,1]).

Figures (results/figures/, 300 dpi PNG + PDF):
  fig1_main_accuracy      grouped bars, mean accuracy per method per dataset
  fig2_paired_box         per-subject boxplots, proposed vs FBCSP vs best deep
  fig3_ablation           CSP-prior family bars (init, K, F, augmentation)
  fig4_paired_scatter     per-subject FBCSPNet vs FBCSP (honest comparability view)
  fig5_mean_rank          mean rank per method across datasets (lower is better)

Pure matplotlib/pandas/numpy; no torch. Self-test via --selftest builds every
figure from synthetic data and asserts the files exist and are non-empty.
American spelling, no em-dashes in any label.
"""
from __future__ import annotations
import os
import argparse
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

PROPOSED = "FBCSPNet"
DATASET_ORDER = ["2a", "2b", "PhysioNet", "HGD"]
CHANCE = {"2a": 25.0, "2b": 50.0, "PhysioNet": 50.0, "HGD": 50.0}
ABLATION_FAMILY = ["random", "base", "K16", "wideF", "aug5", "FBCSPNet"]
CLASSICAL = ["CSP", "FBCSP"]
BRAINDECODE = ["EEGNetv4", "ShallowFBCSPNet", "Deep4Net", "EEGConformer", "ATCNet",
               "EEGITNet", "EEGInception", "EEGInceptionMI", "TCN"]
PRETTY = {
    "random": "Random init", "base": "Base", "K16": "K=16", "wideF": "Wide F",
    "aug5": "Aug x5", "FBCSPNet": "TrustMI-Net", "CSP": "CSP", "FBCSP": "FBCSP",
    "EEGNetv4": "EEGNet-v4", "ShallowFBCSPNet": "ShallowConvNet",
    "Deep4Net": "DeepConvNet", "EEGConformer": "EEG-Conformer",
    "ATCNet": "ATCNet", "EEGITNet": "EEG-ITNet", "EEGInception": "EEG-Inception",
    "EEGInceptionMI": "EEG-Inception-MI", "TCN": "TCN",
}
C_PROP = "#C44E52"     # proposed (warm red)
C_CLASS = "#2E5A87"    # classical (deep blue)
C_DEEP = "#B0B0B0"     # deep baselines (light gray)
plt.rcParams.update({
    "font.size": 11, "font.family": "DejaVu Sans", "axes.titlesize": 12,
    "axes.labelsize": 11, "axes.titleweight": "bold", "axes.labelweight": "medium",
    "xtick.labelsize": 9.5, "ytick.labelsize": 9.5, "legend.fontsize": 8.5,
    "axes.linewidth": 0.9, "axes.edgecolor": "#444444", "figure.dpi": 120,
    "savefig.bbox": "tight", "axes.grid": True, "grid.color": "#DDDDDD",
    "grid.linewidth": 0.7, "grid.alpha": 0.9,
})
plt.rcParams["axes.spines.top"] = False
plt.rcParams["axes.spines.right"] = False
# modern muted palette
PAL = ["#2E5A87", "#C44E52", "#55A868", "#8172B3", "#CCB974", "#64B5CD",
       "#E17C05", "#7F7F7F"]


def load(path):
    df = pd.read_csv(path)
    df["subject"] = df["subject"].astype(str)
    df["acc"] = df["acc"].astype(float) * 100.0
    return df


def _color(m):
    return C_PROP if m == PROPOSED else C_CLASS if m in CLASSICAL else C_DEEP


def _save(fig, out_dir, name):
    import time
    os.makedirs(out_dir, exist_ok=True)
    for ext in ("png", "pdf"):
        fp = os.path.join(out_dir, f"{name}.{ext}")
        for attempt in range(5):                       # OneDrive can transiently lock files
            try:
                fig.savefig(fp, dpi=300, bbox_inches="tight")
                break
            except OSError:
                if attempt == 4:
                    raise
                time.sleep(0.6)
    plt.close(fig)


def fig1_main_accuracy(df, out_dir):
    order = CLASSICAL + BRAINDECODE + [PROPOSED]
    order = [m for m in order if m in df["method"].unique()]
    dsets = [d for d in DATASET_ORDER if d in df["dataset"].unique()]
    piv = df.pivot_table("acc", "method", "dataset", aggfunc="mean")
    x = np.arange(len(dsets))
    n = max(len(order), 1)
    w = 0.82 / n
    fig, ax = plt.subplots(figsize=(11, 4.6))
    ax.set_axisbelow(True)
    ax.grid(axis="y", color="#DDDDDD", linewidth=0.7)
    ax.grid(axis="x", visible=False)
    for i, m in enumerate(order):
        vals = [piv.loc[m, d] if (m in piv.index and d in piv.columns
                                  and pd.notna(piv.loc[m, d])) else np.nan for d in dsets]
        prop = (m == PROPOSED)
        ax.bar(x + i * w, vals, w, label=PRETTY.get(m, m), color=_color(m),
               edgecolor="white", linewidth=0.6,
               zorder=3, alpha=1.0 if prop else 0.92)
    for xi, d in enumerate(dsets):
        ax.hlines(CHANCE[d], xi - 0.06, xi + 0.82 - w + 0.06,
                  color="#999999", ls=(0, (4, 3)), lw=1.0, zorder=2)
    ax.set_xticks(x + (0.82 - w) / 2)
    ax.set_xticklabels(dsets, fontweight="bold")
    ax.set_ylabel("Accuracy (%)")
    ax.set_title("Within-subject accuracy across datasets", pad=10)
    ax.set_ylim(0, 100)
    ax.legend(ncol=6, loc="upper center", bbox_to_anchor=(0.5, -0.13),
              frameon=False, columnspacing=1.1, handlelength=1.3)
    _save(fig, out_dir, "fig1_main_accuracy")


def fig2_paired_box(df, out_dir):
    # proposed vs FBCSP vs best deep (by mean), per dataset, per-subject spread
    dsets = [d for d in DATASET_ORDER if d in df["dataset"].unique()]
    deep_means = df[df["method"].isin(BRAINDECODE)].groupby("method")["acc"].mean()
    best_deep = deep_means.idxmax() if len(deep_means) else None
    groups = [PROPOSED, "FBCSP"] + ([best_deep] if best_deep else [])
    cols = [C_PROP, C_CLASS, C_DEEP]
    fig, axes = plt.subplots(1, len(dsets), figsize=(3.2 * len(dsets), 3.6), sharey=True)
    if len(dsets) == 1:
        axes = [axes]
    for ax, d in zip(axes, dsets):
        data = [df[(df.dataset == d) & (df.method == g)]["acc"].values for g in groups]
        bp = ax.boxplot(data, patch_artist=True, widths=0.6,
                        medianprops=dict(color="black"))
        for patch, c in zip(bp["boxes"], cols):
            patch.set_facecolor(c); patch.set_alpha(0.75)
        ax.axhline(CHANCE[d], color="k", ls=":", lw=0.8, alpha=0.5)
        ax.set_xticks(range(1, len(groups) + 1))
        ax.set_xticklabels([PRETTY.get(g, g) for g in groups], rotation=30, ha="right",
                           fontsize=8)
        ax.set_title(d)
    axes[0].set_ylabel("Accuracy (percent)")
    fig.suptitle("Per-subject accuracy: proposed vs strongest classical and deep baseline")
    _save(fig, out_dir, "fig2_paired_box")


def fig3_ablation(df, out_dir):
    fam = [m for m in ABLATION_FAMILY if m in df["method"].unique()]
    dsets = [d for d in DATASET_ORDER if d in df["dataset"].unique()]
    piv = df[df.method.isin(fam)].pivot_table("acc", "method", "dataset", aggfunc="mean")
    x = np.arange(len(fam))
    w = 0.8 / max(len(dsets), 1)
    fig, ax = plt.subplots(figsize=(8, 4))
    for i, d in enumerate(dsets):
        vals = [piv.loc[m, d] if d in piv.columns and pd.notna(piv.loc[m, d]) else 0
                for m in fam]
        ax.bar(x + i * w, vals, w, label=d, edgecolor="white", linewidth=0.3)
    ax.set_xticks(x + 0.4 - w / 2)
    ax.set_xticklabels([PRETTY.get(m, m) for m in fam], rotation=20, ha="right")
    ax.set_ylabel("Accuracy (percent)")
    ax.set_title("Ablation of the CSP-prior family")
    ax.legend(title="Dataset", fontsize=8)
    ax.set_ylim(0, 100)
    _save(fig, out_dir, "fig3_ablation")


def fig4_paired_scatter(df, out_dir):
    # per-subject FBCSPNet vs FBCSP, one point per (dataset,subject)
    a = df[df.method == PROPOSED].set_index(["dataset", "subject"])["acc"]
    b = df[df.method == "FBCSP"].set_index(["dataset", "subject"])["acc"]
    idx = a.index.intersection(b.index)
    fig, ax = plt.subplots(figsize=(4.6, 4.6))
    markers = {"2a": "o", "2b": "s", "PhysioNet": "^", "HGD": "D"}
    for d in DATASET_ORDER:
        sub = [i for i in idx if i[0] == d]
        if sub:
            ax.scatter([b[i] for i in sub], [a[i] for i in sub],
                       marker=markers.get(d, "o"), label=d, alpha=0.8, s=36,
                       edgecolor="white", linewidth=0.5)
    lo, hi = 20, 100
    ax.plot([lo, hi], [lo, hi], "k--", lw=1, alpha=0.6)
    ax.set_xlim(lo, hi); ax.set_ylim(lo, hi)
    ax.set_xlabel("FBCSP accuracy (percent)")
    ax.set_ylabel("FBCSPNet accuracy (percent)")
    ax.set_title("Per-subject: FBCSPNet vs FBCSP\n(above diagonal = proposed wins)")
    ax.legend(fontsize=8)
    ax.set_aspect("equal")
    _save(fig, out_dir, "fig4_paired_scatter")


def fig5_mean_rank(df, out_dir):
    order = CLASSICAL + BRAINDECODE + [PROPOSED]
    order = [m for m in order if m in df["method"].unique()]
    piv = df.pivot_table("acc", ["dataset", "subject"], "method")
    piv = piv[[m for m in order if m in piv.columns]]
    ranks = piv.rank(axis=1, ascending=False)
    mean_rank = ranks.mean().sort_values()
    fig, ax = plt.subplots(figsize=(6.4, 4.8))
    ax.set_axisbelow(True); ax.grid(axis="x", color="#DDDDDD", linewidth=0.7)
    ax.grid(axis="y", visible=False)
    colors = [_color(m) for m in mean_rank.index]
    bars = ax.barh([PRETTY.get(m, m) for m in mean_rank.index], mean_rank.values,
                   color=colors, edgecolor="white", linewidth=0.6, zorder=3,
                   alpha=0.94)
    ax.invert_yaxis()
    ax.set_xlabel("Mean rank across subjects (lower is better)")
    ax.set_title("Overall mean rank", pad=8)
    ax.set_xlim(0, max(mean_rank.values) * 1.12)
    for b, v in zip(bars, mean_rank.values):
        ax.text(v + 0.08, b.get_y() + b.get_height() / 2, f"{v:.2f}",
                va="center", ha="left", fontsize=8.5, fontweight="medium",
                color="#333333")
    _save(fig, out_dir, "fig5_mean_rank")


def run(path, out_dir):
    df = load(path)
    os.makedirs(out_dir, exist_ok=True)
    fig1_main_accuracy(df, out_dir)
    fig2_paired_box(df, out_dir)
    fig3_ablation(df, out_dir)
    fig4_paired_scatter(df, out_dir)
    fig5_mean_rank(df, out_dir)
    made = sorted(f for f in os.listdir(out_dir) if f.endswith(".png"))
    print("Figures written to", out_dir)
    for f in made:
        print("  ", f)
    return made


def _selftest():
    import tempfile
    rng = np.random.default_rng(0)
    methods = CLASSICAL + BRAINDECODE + ABLATION_FAMILY
    means = {"FBCSPNet": 72, "FBCSP": 68, "CSP": 64, "base": 68, "K16": 67,
             "wideF": 67, "aug5": 68, "random": 58}
    nsub = {"2a": 9, "2b": 9, "PhysioNet": 20, "HGD": 14}
    rows = []
    for d in DATASET_ORDER:
        for m in set(methods):
            mu = means.get(m, 58)
            for s in range(1, nsub[d] + 1):
                rows.append((d, m, s, float(np.clip(rng.normal(mu, 10), 5, 99) / 100)))
    p = os.path.join(tempfile.mkdtemp(), "master_within.csv")
    pd.DataFrame(rows, columns=["dataset", "method", "subject", "acc"]).to_csv(p, index=False)
    out = tempfile.mkdtemp()
    made = run(p, out)
    for name in ["fig1_main_accuracy", "fig2_paired_box", "fig3_ablation",
                 "fig4_paired_scatter", "fig5_mean_rank"]:
        fp = os.path.join(out, name + ".png")
        assert os.path.exists(fp) and os.path.getsize(fp) > 1000, name
        assert os.path.exists(os.path.join(out, name + ".pdf")), name + " pdf"
    print("\nSELF-TEST PASSED: 5 figures (png+pdf) generated and non-empty")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", default=None)
    ap.add_argument("--out", default=None)
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    if a.selftest:
        _selftest()
    else:
        base = r"C:\Users\Anurag Tiwari\OneDrive\Desktop\Motor Imagery Classification-Work"
        csv = a.csv or os.path.join(base, "results", "master_within.csv")
        out = a.out or os.path.join(base, "results", "figures")
        run(csv, out)
