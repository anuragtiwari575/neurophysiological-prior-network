"""
Methodology-pipeline panels from ACTUAL EEG data (no synthetic data).

Generates the seven data-derived panels A-G of the cross-dataset transfer
pipeline, each computed with the exact preprocessing and equations of the
manuscript on the shared C3/Cz/C4 triplet:

  A  EEG waveform of one real trial (8-30 Hz, fourth-order zero-phase Butterworth)
  B  frequency response of that exact filter (scipy butter + sosfreqz)
  C  trace-normalized regularized trial covariance S_i = XX^T/tr(XX^T) + eps I
  D  source Riemannian (Frechet) mean reference R_s over all source trials
  E  Riemannian-aligned trial covariance  S~_i = R_s^-1/2 S_i R_s^-1/2
  F  tangent-space vector z_i = vec_sym( log(Rbar^-1/2 S~_i Rbar^-1/2) ) in R^6,
     with Rbar the frozen Riemannian mean of aligned SOURCE covariances
  G  source-trained logistic regression in the true 6D tangent space, shown in
     2D by PCA (visualization only; classifier is trained in 6D)

Target labels are never used for covariance estimation, alignment, tangent
reference, classifier training, or any selection. Every panel's numbers are
saved to CSV/NPZ and a metadata JSON records the exact dataset, subject, trial
index, class, and parameters. Deterministic seeds throughout.

Run on the machine where the datasets and the project loaders live:
    python make_pipeline_panels.py --source 2a --example-subject 1 --eps 1e-6
Panels C and E need the regularization epsilon; the default 1e-6 matches the
project's covariance code (reg=1e-6). Override with --eps if your run differs.
American spelling, no em-dashes.
"""
from __future__ import annotations
import os
import json
import argparse
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.signal import butter, sosfiltfilt, sosfreqz
from scipy.linalg import fractional_matrix_power as _fmp, logm

CH = ["C3", "Cz", "C4"]
COMMON_CH_IDX = {"2a": [7, 9, 11], "2b": [0, 1, 2],
                 "PhysioNet": [6, 8, 10], "HGD": [6, 8, 10]}
plt.rcParams.update({"font.size": 11, "axes.spines.top": False,
                     "axes.spines.right": False, "figure.dpi": 300})


# --------------------------- SPD helpers (exact manuscript ops) ---------------------------
def invsqrtm(M):
    return np.real(_fmp(M, -0.5))


def trace_norm_cov(X, eps):
    """S_i = X X^T / tr(X X^T) + eps I, exactly as in the manuscript."""
    S = X @ X.T
    S = S / np.trace(S)
    return S + eps * np.eye(S.shape[0])


def tangent_vector(Stilde, Rbar):
    """z_i = vec_sym( log(Rbar^-1/2 Stilde Rbar^-1/2) ), upper triangle with
    sqrt(2) on off-diagonals (standard tangent-space vectorization)."""
    P = invsqrtm(Rbar)
    L = logm(P @ Stilde @ P)
    L = np.real(0.5 * (L + L.T))
    C = L.shape[0]
    z, labels = [], []
    r2 = np.sqrt(2.0)
    for i in range(C):
        for j in range(i, C):
            z.append(L[i, j] if i == j else r2 * L[i, j])
            labels.append(f"{CH[i]}-{CH[j]}")
    return np.array(z), labels


# --------------------------- data ---------------------------
def load_source(dataset, root=None):
    """Return per-trial C3/Cz/C4 signals X (n,3,T), labels y, and fs, using the
    project loaders. Restricted to the shared triplet and 2-class L/R."""
    import variants as V
    idx = COMMON_CH_IDX[dataset]
    Xs, ys = [], []
    subs = list(V.subjects(dataset))
    fs = None
    for s in subs:
        X, y = V.load_within(dataset, s)
        cl = np.unique(y)
        if len(cl) > 2:
            keep = np.isin(y, cl[:2]); X, y = X[keep], y[keep]
        y = (y == np.unique(y)[-1]).astype(int)
        Xs.append(X[:, idx, :].astype(float)); ys.append(y)
    fs = getattr(V, "DATASET_FS", {}).get(dataset, {"2a": 250, "2b": 250,
                                                    "PhysioNet": 160, "HGD": 250}[dataset])
    return Xs, np.concatenate(ys), fs, subs


def bandpass(X, fs, lo=8, hi=30, order=4):
    """Fourth-order zero-phase Butterworth band-pass, exactly as preprocessing."""
    sos = butter(order, [lo, hi], btype="band", fs=fs, output="sos")
    return sosfiltfilt(sos, X, axis=-1)


# --------------------------- panels ---------------------------
def panel_A(x_bp, fs, out):
    """x_bp: (3, T) band-passed example trial."""
    T = x_bp.shape[1]
    seconds = min(3.0, T / fs)
    n = int(seconds * fs)
    t = np.arange(n) / fs
    fig, ax = plt.subplots(figsize=(5.6, 3.2))
    offs = [2, 0, -2]
    for c in range(3):
        s = x_bp[c, :n]
        s = s / (np.max(np.abs(s)) + 1e-12)     # display normalization only
        ax.plot(t, s + offs[c], lw=0.8, color="#2E5A87")
        ax.text(-0.02 * seconds, offs[c], CH[c], ha="right", va="center", fontweight="bold")
    ax.set_xlabel("Time (s)"); ax.set_yticks([]); ax.set_xlim(0, seconds)
    ax.spines["left"].set_visible(False)
    _save(fig, out, "panelA_eeg_waveform")


def panel_B(fs, out, lo=8, hi=30, order=4):
    sos = butter(order, [lo, hi], btype="band", fs=fs, output="sos")
    w, h = sosfreqz(sos, worN=4096, fs=fs)
    mag = np.abs(h)
    fig, ax = plt.subplots(figsize=(5.0, 3.2))
    ax.plot(w, mag, color="#2E5A87", lw=1.6)
    for f in (lo, hi):
        ax.axvline(f, color="#C44E52", ls="--", lw=1.0)
        ax.text(f, 1.02, f"{f} Hz", ha="center", color="#C44E52", fontsize=9)
    ax.set_xlim(0, min(60, fs / 2)); ax.set_ylim(0, 1.08)
    ax.set_xlabel("Frequency (Hz)"); ax.set_ylabel("Magnitude")
    _save(fig, out, "panelB_filter_response")
    return w, mag


def _heatmap(M, out, name, title=None, vlim=None, cmap="viridis"):
    fig, ax = plt.subplots(figsize=(3.4, 3.2))
    vmin, vmax = (vlim if vlim else (M.min(), M.max()))
    im = ax.imshow(M, cmap=cmap, vmin=vmin, vmax=vmax)
    ax.set_xticks(range(3)); ax.set_xticklabels(CH)
    ax.set_yticks(range(3)); ax.set_yticklabels(CH)
    for i in range(3):
        for j in range(3):
            ax.text(j, i, f"{M[i,j]:.3f}", ha="center", va="center",
                    color="white" if (M[i, j] - vmin) / (vmax - vmin + 1e-9) < 0.5 else "black",
                    fontsize=9)
    if title:
        ax.set_title(title, fontsize=10)
    ax.set_aspect("equal")
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    _save(fig, out, name)


def _save(fig, out, name):
    os.makedirs(out, exist_ok=True)
    for ext in ("png", "pdf", "svg"):
        fig.savefig(os.path.join(out, f"{name}.{ext}"), dpi=300, bbox_inches="tight")
    plt.close(fig)


# --------------------------- main pipeline ---------------------------
def run(dataset, example_subject, eps, out, root=None, seed=0):
    np.random.seed(seed)
    try:
        from pyriemann.geometry.mean import mean_riemann
    except Exception:
        from pyriemann.utils.mean import mean_riemann

    Xs, y, fs, subs = load_source(dataset, root)
    meta = dict(dataset=dataset, fs=fs, eps=eps, channels=CH,
                channel_indices=COMMON_CH_IDX[dataset], seed=seed,
                n_source_trials=int(sum(len(x) for x in Xs)), subjects=list(map(int, subs)))

    # pick the example trial: first trial of the requested subject
    si = subs.index(example_subject) if example_subject in subs else 0
    X_subj = Xs[si]
    ex_idx = 0
    x_raw = X_subj[ex_idx]                                  # (3, T) raw triplet
    x_bp = bandpass(x_raw[None], fs)[0]                     # band-passed for display + covariance
    meta.update(example_subject=int(subs[si]), example_trial_index=int(ex_idx))

    # ---- band-pass ALL source trials for covariance pipeline ----
    Xbp = [bandpass(x, fs) for x in Xs]                     # list of (n,3,T)

    # ---- Panel A, B ----
    panel_A(x_bp, fs, out)
    w, mag = panel_B(fs, out)

    # ---- Panel C: example trial covariance ----
    S_i = trace_norm_cov(x_bp, eps)
    _heatmap(S_i, out, "panelC_trial_covariance", title="$S_i$")

    # ---- source covariances (all trials) ----
    S_all = np.stack([trace_norm_cov(x[k], eps)
                      for x in Xbp for k in range(x.shape[0])], axis=0)

    # ---- Panel D: source Riemannian reference R_s ----
    R_s = mean_riemann(S_all)
    _heatmap(R_s, out, "panelD_source_reference", title="$R_s$ (source Riemannian mean)")

    # ---- Panel E: aligned example covariance ----
    P = invsqrtm(R_s)
    S_tilde_i = P @ S_i @ P
    # shared color scale C<->E for interpretability
    vlim = (min(S_i.min(), S_tilde_i.min()), max(S_i.max(), S_tilde_i.max()))
    _heatmap(S_i, out, "panelC_trial_covariance",
             title="$S_i$", vlim=vlim)                       # re-save C with shared scale
    _heatmap(S_tilde_i, out, "panelE_aligned_covariance",
             title=r"$\tilde S_i = R_s^{-1/2} S_i R_s^{-1/2}$", vlim=vlim)

    # verify alignment. For Riemannian alignment the RIEMANNIAN (geometric) mean
    # of the aligned covariances equals the identity by construction; the
    # arithmetic mean does not, so we report both honestly.
    S_tilde_all = np.stack([P @ s @ P for s in S_all], axis=0)
    mean_aligned = S_tilde_all.mean(0)
    dev_arith = float(np.linalg.norm(mean_aligned - np.eye(3)))
    geo_mean_aligned = mean_riemann(S_tilde_all)
    dev_geo = float(np.linalg.norm(geo_mean_aligned - np.eye(3)))
    meta["riemannian_mean_aligned_deviation_from_identity"] = dev_geo
    meta["arithmetic_mean_aligned_deviation_from_identity"] = dev_arith
    print(f"[verify] Riemannian alignment: ||RiemannianMean(S~_i) - I||_F = {dev_geo:.4e} "
          f"(this is the quantity that is zero by construction)")
    print(f"[verify] (for reference) ||arithmeticMean(S~_i) - I||_F = {dev_arith:.4e} "
          f"(not expected to be zero under Riemannian alignment)")

    # ---- Panel F: tangent vector at frozen source Rbar ----
    Rbar = mean_riemann(S_tilde_all)                        # frozen source tangent reference
    z_i, zlabels = tangent_vector(S_tilde_i, Rbar)
    fig, ax = plt.subplots(figsize=(5.2, 3.0))
    ax.bar(range(6), z_i, color="#2E5A87", edgecolor="#333", linewidth=0.6)
    ax.set_xticks(range(6)); ax.set_xticklabels(zlabels, rotation=30, ha="right")
    ax.axhline(0, color="#999", lw=0.7)
    ax.set_ylabel("tangent component"); ax.set_xlabel(r"$z_i \in \mathbb{R}^6$")
    _save(fig, out, "panelF_tangent_vector")

    # ---- Panel G: source-trained LR in 6D, PCA to 2D for view ----
    from sklearn.linear_model import LogisticRegression
    from sklearn.decomposition import PCA
    Z = np.stack([tangent_vector(s, Rbar)[0] for s in S_tilde_all], axis=0)  # (N,6)
    clf = LogisticRegression(max_iter=1000).fit(Z, y)      # trained in true 6D
    pca = PCA(n_components=2, random_state=seed).fit(Z)
    Z2 = pca.transform(Z)
    fig, ax = plt.subplots(figsize=(5.0, 4.0))
    for cls, col, mk in [(0, "#2E5A87", "o"), (1, "#C44E52", "^")]:
        m = y == cls
        ax.scatter(Z2[m, 0], Z2[m, 1], s=18, c=col, marker=mk, alpha=0.7,
                   label=f"class {cls}")
    ax.set_xlabel("PCA-1 (view only)"); ax.set_ylabel("PCA-2 (view only)")
    ax.legend(frameon=False, fontsize=9)
    ax.text(0.02, 0.98, "LR trained in 6D; PCA for display only",
            transform=ax.transAxes, va="top", fontsize=8, color="#555")
    _save(fig, out, "panelG_lr_feature_space")

    # ---- save all numerical values ----
    np.savez(os.path.join(out, "panel_values.npz"),
             x_bp_example=x_bp, filter_w=w, filter_mag=mag,
             S_i=S_i, R_s=R_s, S_tilde_i=S_tilde_i, Rbar=Rbar,
             mean_aligned_arith=mean_aligned, mean_aligned_geo=geo_mean_aligned, z_i=z_i,
             Z_source=Z, y_source=y, pca_components=pca.components_)
    np.savetxt(os.path.join(out, "panelC_S_i.csv"), S_i, delimiter=",", header=",".join(CH))
    np.savetxt(os.path.join(out, "panelD_R_s.csv"), R_s, delimiter=",", header=",".join(CH))
    np.savetxt(os.path.join(out, "panelE_S_tilde_i.csv"), S_tilde_i, delimiter=",", header=",".join(CH))
    np.savetxt(os.path.join(out, "panelF_z_i.csv"),
               np.array([z_i]), delimiter=",", header=",".join(zlabels))
    with open(os.path.join(out, "metadata.json"), "w") as f:
        json.dump(meta, f, indent=2)
    print(f"[done] panels + values + metadata written to {out}")
    print(f"[meta] {json.dumps(meta, indent=2)}")


def _selftest():
    """Numeric-only self-test (no dataset): SPD ops, trace-norm, tangent dim,
    and identity-after-alignment property on a small real-covariance set built
    from deterministic band-limited signals (NOT used as a data panel)."""
    rng = np.random.default_rng(0)
    fs, T = 250, 512
    # deterministic band-limited signals only to exercise the math paths
    t = np.arange(T) / fs
    trials = []
    for k in range(30):
        x = np.vstack([np.sin(2*np.pi*(10+2*c)*t + rng.uniform(0, 6)) +
                       0.3*rng.standard_normal(T) for c in range(3)])
        trials.append(bandpass(x, fs))
    eps = 1e-6
    S = np.stack([trace_norm_cov(x, eps) for x in trials])
    assert np.allclose(S, np.transpose(S, (0, 2, 1)), atol=1e-9)          # symmetry
    assert np.all([np.all(np.linalg.eigvalsh(s) > 0) for s in S])         # SPD
    from pyriemann.utils.mean import mean_riemann
    R = mean_riemann(S); P = invsqrtm(R)
    Sa = np.stack([P @ s @ P for s in S])
    dev = np.linalg.norm(Sa.mean(0) - np.eye(3))
    z, labels = tangent_vector(Sa[0], mean_riemann(Sa))
    assert z.shape == (6,) and labels == ["C3-C3", "C3-Cz", "C3-C4", "Cz-Cz", "Cz-C4", "C4-C4"]
    print(f"SELF-TEST PASSED: trace-norm covariance SPD+symmetric, invsqrt align, "
          f"tangent dim=6 with correct labels, ||mean(S~)-I||={dev:.3e}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", default="2a", choices=list(COMMON_CH_IDX))
    ap.add_argument("--example-subject", type=int, default=1)
    ap.add_argument("--eps", type=float, default=1e-6,
                    help="covariance regularization; 1e-6 matches project code")
    ap.add_argument("--root", default=None)
    ap.add_argument("--out", default="pipeline_panels")
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    if a.selftest:
        _selftest()
    else:
        run(a.source, a.example_subject, a.eps, a.out, a.root)
