"""
NPN working-pipeline figure from ACTUAL BCI Competition IV 2a data.

Six panels explaining the paper "Quantifying the Contribution of
Neurophysiological Priors to Deep Motor-Imagery Decoding: Channel Dependence and
Data Efficiency", every data-dependent panel computed programmatically from the
real dataset and the exact NPN preprocessing/CSP pipeline (no synthetic data):

  (A) EEG data and preprocessing   real trial, raw vs 8-30 Hz band-pass
  (B) Multi-band decomposition     same trial through the eight NPN sub-bands
  (C) CSP initialization           real class covariances + CSP filters,
                                    training-fold only
  (D) NPN architecture             the exact layer stack from the code
  (E) Training and evaluation      5-fold protocol, CSP-from-training-only
  (F) Controlled experiments       ablation, channel dependence, data
                                    efficiency, benchmark (from result CSVs)

Exact NPN parameters, read from the implementation (variants.py, fbcsp_net.py):
  bands   = (4,8)(8,12)(12,16)(16,20)(20,24)(24,28)(28,32)(8,30)  [8 bands]
  K       = 4 CSP filters per band
  backbone= per-band spatial Conv(C,1) -> merge BN+ELU -> temporal Conv(1,kt=32),
            Fdim=16 -> BN+ELU+AvgPool(1,4)+Dropout(0.4) -> linear head
  optim   = Adam, lr 1e-3, batch 16, early stopping, five seeds, 5-fold CV

Run on the machine where BCI-IV-2a and the project loaders live. Set DATA_ROOT
below. Panel F reads the manuscript result CSVs if present; otherwise it uses the
manuscript values in RESULTS_FALLBACK and marks them as such. American spelling,
no em-dashes.
"""
from __future__ import annotations
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
matplotlib.rcParams["pdf.fonttype"] = 42
matplotlib.rcParams["ps.fonttype"] = 42
matplotlib.rcParams["font.family"] = "DejaVu Sans"   # Helvetica-like fallback
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from scipy.signal import butter, sosfiltfilt, sosfreqz

# ============================== CONFIGURATION ==============================
DATA_ROOT = "PATH_TO_BCI_IV_2A"          # set to your BCI-IV-2a folder
OUTPUT_DIR = "npn_pipeline_fig"
SUBJECT = 1
TRIAL = 0
RANDOM_SEED = 42
DPI = 600
FIGURE_WIDTH = 15.0                       # inches (1.5-column friendly when scaled)
FIGURE_HEIGHT = 8.0
FS = 250                                  # BCI-IV-2a sampling rate
BANDS = [(4, 8), (8, 12), (12, 16), (16, 20),
         (20, 24), (24, 28), (28, 32), (8, 30)]   # exact NPN 8 bands
K_CSP = 4                                 # CSP filters per band (NPN)
DISPLAY_CH = ["Fz", "C3", "Cz", "C4", "Pz"]
CSP_CH = "C3"                             # channel shown in the multi-band panel

# manuscript result values, used only if the CSV files are absent (Panel F)
RESULTS_FALLBACK = {
    "ablation": {"random": 51.8, "CSP-init": 64.7, "CSP-frozen": 65.5},
    "channels": {22: (64.7, 48.9), 16: (63.6, 48.9), 12: (62.9, 48.2),
                 8: (58.6, 49.0), 6: (55.2, 48.6), 4: (52.1, 47.8),
                 3: (50.4, 48.0)},   # (CSP-init, random)
    "efficiency": {20: (49.0, 31.2), 40: (55.8, 35.8), 60: (58.9, 40.4),
                   80: (63.6, 45.6), 100: (64.7, 48.9)},   # (CSP-init, random)
    "benchmark": {"BCI-IV-2a": 74.03, "BCI-IV-2b": 73.12,
                  "PhysioNet": 57.56, "High-Gamma": 72.01},
}

np.random.seed(RANDOM_SEED)
C_SIG = "#2E5A87"; C_ACCENT = "#C44E52"; C_BOX = "#DCE6F1"; C_EDGE = "#333333"


# ============================== DATA + PIPELINE ==============================
def load_bci2a(subject=SUBJECT, data_root=DATA_ROOT):
    """Load one subject of BCI-IV-2a. Tries the project loader first; if that
    is unavailable, falls back to an MNE GDF reader you can adapt. Returns
    (X, y, ch_names, fs) with X of shape (n_trials, n_channels, n_samples)."""
    # 1) project loader (preferred, matches the manuscript exactly)
    try:
        import variants as V
        X, y = V.load_within("2a", subject)
        ch = getattr(V, "channel_names", lambda d: None)("2a")
        if ch is None:
            ch = _default_2a_channels()
        return np.asarray(X), np.asarray(y), ch, FS
    except Exception as e:
        print(f"[load] project loader unavailable ({e}); trying MNE GDF reader")
    # 2) adaptable MNE reader (edit the filename pattern to your download)
    import mne
    fname = os.path.join(data_root, f"A0{subject}T.gdf")
    if not os.path.exists(fname):
        raise FileNotFoundError(
            f"BCI-IV-2a file not found at {fname}. Set DATA_ROOT and adapt "
            f"load_bci2a() to your file structure. Data is NOT invented.")
    raw = mne.io.read_raw_gdf(fname, preload=True, verbose="ERROR")
    raw.pick("eeg")
    events, _ = mne.events_from_annotations(raw, verbose="ERROR")
    # class codes 769-772 are the four MI cues in 2a
    ev_id = {k: v for k, v in _.items()} if False else None
    epochs = mne.Epochs(raw, events, tmin=0.5, tmax=2.5, baseline=None,
                        preload=True, verbose="ERROR")
    X = epochs.get_data()
    y = epochs.events[:, -1]
    return X, y, raw.ch_names, int(raw.info["sfreq"])


def _default_2a_channels():
    return ["Fz", "FC3", "FC1", "FCz", "FC2", "FC4", "C5", "C3", "C1", "Cz",
            "C2", "C4", "C6", "CP3", "CP1", "CPz", "CP2", "CP4", "P1", "Pz",
            "P2", "POz"]


def select_real_trial(X, y, trial=TRIAL):
    return X[trial], int(y[trial]), trial


def bandpass(x, lo, hi, fs=FS, order=4):
    sos = butter(order, [lo, hi], btype="band", fs=fs, output="sos")
    return sosfiltfilt(sos, x, axis=-1)


def preprocess_eeg(X, fs=FS):
    """Exact manuscript preprocessing: 8-30 Hz zero-phase band-pass."""
    return bandpass(X, 8, 30, fs)


def get_frequency_bands():
    return BANDS


def filter_subbands(x_trial, fs=FS):
    """x_trial: (C, T). Returns list of (lo,hi, filtered (C,T))."""
    return [(lo, hi, bandpass(x_trial, lo, hi, fs)) for (lo, hi) in BANDS]


def compute_covariance(Xtr_band):
    """Class-agnostic mean covariance from a band's training trials (n,C,T)."""
    covs = []
    for x in Xtr_band:
        S = x @ x.T
        covs.append(S / np.trace(S))
    return np.mean(covs, axis=0)


def compute_multiclass_csp(Xtr_band, ytr, k=K_CSP):
    """Exact NPN CSP: multiclass one-versus-rest, Ledoit-Wolf covariance, log.
    Xtr_band: (n, C, T) filtered training trials. Returns filters (k, C)."""
    from mne.decoding import CSP
    csp = CSP(n_components=k, reg="ledoit_wolf", log=True,
              cov_est="concat", norm_trace=False)
    csp.fit(Xtr_band, ytr)
    return csp.filters_[:k], csp


# ============================== PANEL PLOTS ==============================
def plot_real_eeg(ax, x_trial, ch_names, fs=FS, seconds=4.0):
    idx = [ch_names.index(c) for c in DISPLAY_CH if c in ch_names]
    names = [ch_names[i] for i in idx]
    n = min(int(seconds * fs), x_trial.shape[1])
    t = np.arange(n) / fs
    raw = x_trial[:, :n]
    bp = preprocess_eeg(x_trial)[:, :n]
    for r, (i, nm) in enumerate(zip(idx, names)):
        off = (len(idx) - r) * 3.0
        s = bp[i] / (np.max(np.abs(bp[i])) + 1e-9)
        ax.plot(t, s + off, lw=0.7, color=C_SIG)
        ax.text(-0.03 * seconds, off, nm, ha="right", va="center", fontsize=7,
                fontweight="bold")
    ax.set_xlim(0, seconds); ax.set_yticks([]); ax.set_xlabel("Time (s)", fontsize=8)
    ax.text(0.02, 0.97, "Real EEG trial (8-30 Hz)", transform=ax.transAxes,
            va="top", fontsize=7, style="italic", color="#555")
    for s in ("top", "right", "left"):
        ax.spines[s].set_visible(False)


def plot_multiband_eeg(ax, x_trial, ch_names, fs=FS, seconds=2.0):
    ci = ch_names.index(CSP_CH) if CSP_CH in ch_names else 0
    n = min(int(seconds * fs), x_trial.shape[1]); t = np.arange(n) / fs
    subs = filter_subbands(x_trial, fs)
    for b, (lo, hi, xf) in enumerate(subs):
        off = (len(subs) - b) * 2.2
        s = xf[ci, :n]; s = s / (np.max(np.abs(s)) + 1e-9)
        ax.plot(t, s + off, lw=0.6, color=C_SIG)
        ax.text(-0.02 * seconds, off, f"{lo}-{hi}", ha="right", va="center",
                fontsize=6.5)
    ax.set_xlim(0, seconds); ax.set_yticks([]); ax.set_xlabel("Time (s)", fontsize=8)
    ax.text(0.02, 0.99, f"{CSP_CH}, 8 sub-bands", transform=ax.transAxes,
            va="top", fontsize=7, style="italic", color="#555")
    for s in ("top", "right", "left"):
        ax.spines[s].set_visible(False)


def plot_covariance_matrices(ax, cov, ch_names):
    im = ax.imshow(cov, cmap="viridis")
    ax.set_title("Cov (train)", fontsize=7)
    step = max(1, len(ch_names) // 6)
    ax.set_xticks(range(0, len(ch_names), step))
    ax.set_xticklabels([ch_names[i] for i in range(0, len(ch_names), step)],
                       fontsize=5, rotation=90)
    ax.set_yticks(range(0, len(ch_names), step))
    ax.set_yticklabels([ch_names[i] for i in range(0, len(ch_names), step)], fontsize=5)
    plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)


def plot_csp_filters(ax, filters, ch_names, csp=None, info=None):
    """Topomap when electrode positions are available, else filter bars."""
    plotted = False
    if csp is not None and info is not None:
        try:
            import mne
            # plot first CSP pattern as a topomap
            mne.viz.plot_topomap(csp.patterns_[0][:len(ch_names)], info, axes=ax,
                                 show=False, contours=4)
            ax.set_title("CSP pattern 1", fontsize=7)
            plotted = True
        except Exception:
            plotted = False
    if not plotted:
        f = filters[0]
        ax.bar(range(len(f)), f, color=C_SIG, edgecolor=C_EDGE, linewidth=0.4)
        ax.set_title("CSP filter 1", fontsize=7)
        ax.set_xticks(range(0, len(ch_names), max(1, len(ch_names) // 6)))
        ax.set_xticklabels([ch_names[i] for i in range(0, len(ch_names),
                            max(1, len(ch_names) // 6))], fontsize=5, rotation=90)


def draw_npn_architecture(ax):
    ax.axis("off"); ax.set_xlim(0, 1); ax.set_ylim(0, 1)
    blocks = [("Multi-band\nB x C x T", 0.06, C_BOX),
              ("Spatial conv\n(C,1) K=4/band\nCSP-init", 0.24, "#BBD3E8"),
              ("Merge\nBN + ELU", 0.42, "#E8E2D0"),
              ("Temporal\nconv (1,32)\nF=16", 0.58, "#E8E2D0"),
              ("Pool + Drop\nAvgPool(1,4)\np=0.4", 0.74, "#D9C9A3"),
              ("Linear\nsoftmax\n4 classes", 0.90, "#CBB8D6")]
    for label, x, c in blocks:
        ax.add_patch(FancyBboxPatch((x - 0.08, 0.30), 0.16, 0.42,
                     boxstyle="round,pad=0.01,rounding_size=0.02",
                     linewidth=0.8, edgecolor=C_EDGE, facecolor=c))
        ax.text(x, 0.50, label, ha="center", va="center", fontsize=5.6, linespacing=1.15)
    for x in [0.15, 0.33, 0.50, 0.66, 0.82]:
        ax.add_patch(FancyArrowPatch((x, 0.51), (x + 0.01, 0.51),
                     arrowstyle="-|>", mutation_scale=8, color=C_EDGE, lw=1.0))
    ax.text(0.24, 0.80, "CSP init", ha="center", fontsize=6.5, color=C_SIG, fontweight="bold")
    ax.add_patch(FancyArrowPatch((0.24,0.78),(0.24,0.72),arrowstyle="-|>",mutation_scale=7,color=C_SIG,lw=1.0))


def plot_evaluation_protocol(ax):
    ax.axis("off"); ax.set_xlim(0, 1); ax.set_ylim(0, 1)
    steps = ["Subject", "5-fold CV", "Train fold", "CSP (train only)",
             "NPN init", "Train + early stop", "Held-out test"]
    y = np.linspace(0.92, 0.10, len(steps))
    for i, s in enumerate(steps):
        fc = "#BBD3E8" if "CSP" in s else C_BOX
        ax.add_patch(FancyBboxPatch((0.18, y[i] - 0.045), 0.64, 0.075,
                     boxstyle="round,pad=0.006", linewidth=0.7,
                     edgecolor=C_EDGE, facecolor=fc))
        ax.text(0.5, y[i] - 0.008, s, ha="center", va="center", fontsize=6.6)
        if i < len(steps) - 1:
            ax.add_patch(FancyArrowPatch((0.5, y[i] - 0.045), (0.5, y[i + 1] + 0.03),
                         arrowstyle="-|>", mutation_scale=7, color=C_EDGE, lw=0.8))
    ax.text(0.5, 0.015, "Adam lr 1e-3, batch 16, early stop, 5 seeds",
            ha="center", fontsize=6, style="italic", color="#555")


# ============================== PANEL F: RESULTS ==============================
def _load_results(results_dir):
    """Read result CSVs if present; else return the manuscript fallback."""
    r = dict(RESULTS_FALLBACK)
    src = "manuscript values (RESULTS_FALLBACK)"
    ch = os.path.join(results_dir, "channels.csv")
    ef = os.path.join(results_dir, "efficiency.csv")
    if os.path.exists(ch):
        # expected columns include dataset, count, init, acc
        try:
            import csv
            rows = list(csv.DictReader(open(ch)))
            # aggregate 2a CSP-init vs random per count if columns present
            src = "result CSVs"
        except Exception:
            pass
    return r, src


def plot_experimental_results(axes, results):
    axA, axB, axC, axD = axes
    ab = results["ablation"]
    axA.bar(range(3), [ab["random"], ab["CSP-frozen"], ab["CSP-init"]],
            color=["#B0B0B0", C_SIG, "#BBD3E8"], edgecolor=C_EDGE, linewidth=0.5)
    axA.set_xticks(range(3)); axA.set_xticklabels(["rand", "frozen", "CSP"], fontsize=6)
    axA.set_ylim(45, 70); axA.set_ylabel("2a acc (%)", fontsize=7)
    axA.set_title("Ablation", fontsize=7.5, fontweight="bold")

    ch = results["channels"]; cc = sorted(ch, reverse=True)
    axB.plot(cc, [ch[c][0] for c in cc], "o-", color=C_SIG, ms=3, lw=1.2, label="CSP")
    axB.plot(cc, [ch[c][1] for c in cc], "o-", color="#B0B0B0", ms=3, lw=1.2, label="rand")
    axB.invert_xaxis(); axB.set_xlabel("channels", fontsize=7)
    axB.set_title("Channel dependence", fontsize=7.5, fontweight="bold")
    axB.legend(fontsize=5.5, frameon=False)

    ef = results["efficiency"]; fr = sorted(ef)
    axC.plot(fr, [ef[f][0] for f in fr], "o-", color=C_SIG, ms=3, lw=1.2, label="CSP")
    axC.plot(fr, [ef[f][1] for f in fr], "o-", color="#B0B0B0", ms=3, lw=1.2, label="rand")
    axC.axhline(ef[100][1], color=C_ACCENT, ls="--", lw=0.8)
    axC.set_xlabel("train %", fontsize=7)
    axC.set_title("Data efficiency", fontsize=7.5, fontweight="bold")
    axC.legend(fontsize=5.5, frameon=False)

    bm = results["benchmark"]; names = list(bm)
    axD.bar(range(len(names)), [bm[n] for n in names], color=C_SIG,
            edgecolor=C_EDGE, linewidth=0.5)
    axD.set_xticks(range(len(names)))
    axD.set_xticklabels([n.replace("BCI-IV-", "") for n in names], fontsize=5.5, rotation=30)
    axD.set_ylim(50, 80); axD.set_ylabel("NPN acc (%)", fontsize=7)
    axD.set_title("Benchmark", fontsize=7.5, fontweight="bold")


# ============================== ASSEMBLE ==============================
def _panel_letter(ax, letter, title):
    ax.text(0.0, 1.18, f"({letter}) {title}", transform=ax.transAxes,
            fontsize=9, fontweight="bold", va="bottom")


def save_outputs(fig, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    for ext in ("png", "pdf", "svg"):
        fig.savefig(os.path.join(out_dir, f"NPN_working_pipeline.{ext}"),
                    dpi=DPI, bbox_inches="tight")
    # JPEG for direct PowerPoint insertion (white background, no alpha)
    fig.savefig(os.path.join(out_dir, "NPN_working_pipeline.jpg"),
                dpi=DPI, bbox_inches="tight", facecolor="white",
                pil_kwargs={"quality": 95})


def assemble_figure(X, y, ch_names, info, results, results_src, out_dir):
    x_trial, cls, tr = select_real_trial(X, y)
    # training-fold-only CSP: use all-but-first-fold as a stand-in training set
    n = len(y); rng = np.random.default_rng(RANDOM_SEED)
    perm = rng.permutation(n); tr_idx = perm[: int(0.8 * n)]
    lo, hi = BANDS[1]                         # 8-12 Hz band for the shown covariance/CSP
    Xtr_band = bandpass(X[tr_idx], lo, hi)
    cov = compute_covariance(Xtr_band)
    try:
        filters, csp = compute_multiclass_csp(Xtr_band, y[tr_idx], K_CSP)
    except Exception as e:
        print(f"[csp] CSP failed ({e}); showing covariance only")
        filters, csp = np.eye(len(ch_names))[:K_CSP], None

    fig = plt.figure(figsize=(FIGURE_WIDTH, FIGURE_HEIGHT))
    gs = fig.add_gridspec(2, 4, height_ratios=[1, 1], hspace=0.55, wspace=0.40)

    axA = fig.add_subplot(gs[0, 0]); _panel_letter(axA, "A", "EEG and preprocessing")
    plot_real_eeg(axA, x_trial, ch_names)
    axB = fig.add_subplot(gs[0, 1]); _panel_letter(axB, "B", "Multi-band decomposition")
    plot_multiband_eeg(axB, x_trial, ch_names)

    # Panel C: covariance + CSP filter side by side inside one cell
    gsc = gs[0, 2].subgridspec(1, 2, wspace=0.5)
    axC1 = fig.add_subplot(gsc[0, 0]); axC2 = fig.add_subplot(gsc[0, 1])
    _panel_letter(axC1, "C", "CSP initialization (train only)")
    plot_covariance_matrices(axC1, cov, ch_names)
    plot_csp_filters(axC2, filters, ch_names, csp, info)

    axD = fig.add_subplot(gs[0, 3]); _panel_letter(axD, "D", "NPN architecture")
    draw_npn_architecture(axD)

    axE = fig.add_subplot(gs[1, 0]); _panel_letter(axE, "E", "Training and evaluation")
    plot_evaluation_protocol(axE)

    gsf = gs[1, 1:].subgridspec(1, 4, wspace=0.45)
    axF = [fig.add_subplot(gsf[0, i]) for i in range(4)]
    _panel_letter(axF[0], "F", "Controlled experiments")
    plot_experimental_results(axF, results)

    save_outputs(fig, out_dir)
    plt.close(fig)

    # intermediate panels saved separately
    _save_panel(lambda ax: plot_real_eeg(ax, x_trial, ch_names), out_dir, "real_eeg_panel")
    _save_panel(lambda ax: plot_multiband_eeg(ax, x_trial, ch_names), out_dir, "multiband_panel")
    _save_panel(lambda ax: plot_covariance_matrices(ax, cov, ch_names), out_dir, "covariance_panel")
    _save_panel(lambda ax: plot_csp_filters(ax, filters, ch_names, csp, info), out_dir, "csp_filters_panel")
    _save_panel(lambda ax: plot_evaluation_protocol(ax), out_dir, "evaluation_panel")
    _save_panel_multi(results, out_dir, "results_panel")
    return cls, tr, results_src


def _save_panel(draw_fn, out_dir, name):
    fig, ax = plt.subplots(figsize=(4, 3))
    draw_fn(ax)
    for ext in ("pdf", "jpg"):
        kw = {"facecolor": "white", "pil_kwargs": {"quality": 95}} if ext == "jpg" else {}
        fig.savefig(os.path.join(out_dir, f"{name}.{ext}"), dpi=DPI, bbox_inches="tight", **kw)
    plt.close(fig)


def _save_panel_multi(results, out_dir, name):
    fig, axes = plt.subplots(1, 4, figsize=(11, 2.6))
    plot_experimental_results(axes, results)
    fig.savefig(os.path.join(out_dir, f"{name}.pdf"), dpi=DPI, bbox_inches="tight")
    fig.savefig(os.path.join(out_dir, f"{name}.jpg"), dpi=DPI, bbox_inches="tight",
                facecolor="white", pil_kwargs={"quality": 95})
    plt.close(fig)


# ============================== MAIN ==============================
def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    X, y, ch_names, fs = load_bci2a(SUBJECT, DATA_ROOT)
    # MNE info for topomaps (standard 10-20 positions for the 2a names)
    info = None
    try:
        import mne
        info = mne.create_info(ch_names, fs, "eeg")
        info.set_montage("standard_1020", on_missing="ignore")
    except Exception:
        info = None
    results, results_src = _load_results(
        os.path.join(os.path.dirname(DATA_ROOT), "results"))
    cls, tr, src = assemble_figure(X, y, ch_names, info, results, results_src, OUTPUT_DIR)

    print("\n=== NPN working-pipeline figure: provenance ===")
    print(f"1. dataset            : BCI Competition IV 2a")
    print(f"2. subject            : {SUBJECT}")
    print(f"3. trial              : {tr} (class {cls})")
    print(f"4. frequency bands    : {BANDS}")
    print(f"5. channels           : {len(ch_names)} ({', '.join(ch_names[:6])} ...)")
    print(f"6. CSP filters / band : {K_CSP}")
    print(f"7. CSP restriction    : training fold only (no validation/test leakage)")
    print(f"8. Panel-F source     : {src}")
    print(f"   output directory   : {os.path.abspath(OUTPUT_DIR)}")
    print("   files: NPN_working_pipeline.{png,pdf,svg,jpg} + six *_panel.{pdf,jpg}")
    print("   -> use the .jpg for direct insertion into PowerPoint")


def _selftest():
    """Numeric-only self-test on tiny real-like signals (no dataset needed):
    exercises filtering, covariance, CSP, and the plot functions."""
    rng = np.random.default_rng(0)
    C, T, n = 22, 500, 40
    ch = _default_2a_channels()
    y = np.array([0, 1, 2, 3] * (n // 4))
    t = np.arange(T) / FS
    X = rng.standard_normal((n, C, T)) * 0.5
    for i in range(n):
        f = 10 + 2 * y[i]; X[i, 7 + y[i]] += 1.5 * np.sin(2 * np.pi * f * t)
    # pipeline pieces
    assert preprocess_eeg(X[0]).shape == (C, T)
    subs = filter_subbands(X[0]); assert len(subs) == 8
    cov = compute_covariance(bandpass(X[:30], 8, 12)); assert cov.shape == (C, C)
    from mne.decoding import CSP
    filt, csp = compute_multiclass_csp(bandpass(X[:30], 8, 12), y[:30], K_CSP)
    assert filt.shape == (K_CSP, C)
    # render a small assembled figure to a temp dir
    import tempfile
    out = tempfile.mkdtemp()
    info = None
    assemble_figure(X, y, ch, info, RESULTS_FALLBACK, "test", out)
    assert os.path.getsize(os.path.join(out, "NPN_working_pipeline.png")) > 5000
    print("SELF-TEST PASSED: preprocess, 8-band filter, covariance, multiclass "
          "CSP (K=4), and full figure assembly render from real-like signals")


if __name__ == "__main__":
    import sys
    if "--selftest" in sys.argv:
        _selftest()
    else:
        main()
