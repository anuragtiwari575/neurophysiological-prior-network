"""
Regenerate the three result figures with the paper name NPN (not FBCSPNet).

Reads results/master_within.csv (schema: dataset,method,subject,acc, with acc a
fraction) and writes, at 300 dpi png+pdf, into the output directory:
  fig1_main_accuracy   grouped accuracy bars per method and dataset
  fig4_paired_scatter  per-subject NPN vs FBCSP scatter with the identity line
  fig5_mean_rank       overall mean rank per method (lower is better)

The proposed method is stored in the CSV under its code name (FBCSPNet); this
script relabels it to NPN everywhere it appears in a figure, so the code name
never reaches the manuscript. Nothing is fabricated: every point and bar comes
from the CSV.

Usage:
    python regen_figures.py --csv results/master_within.csv --out C:\\mi_figures\\final
    python regen_figures.py                 # uses default project paths
    python regen_figures.py --selftest      # renders from a synthetic CSV

The CSV method label of the proposed model is set by --proposed (default
FBCSPNet) and is displayed as the value of --display (default NPN). American
spelling, no em-dashes.
"""
from __future__ import annotations
import os
import argparse
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({
    "font.size": 11, "axes.titlesize": 12, "axes.titleweight": "bold",
    "axes.labelsize": 11, "axes.linewidth": 0.9, "axes.edgecolor": "#444444",
    "axes.grid": True, "grid.color": "#DDDDDD", "grid.linewidth": 0.7,
    "axes.spines.top": False, "axes.spines.right": False,
})
C_MAIN, C_CLASSIC, C_OTHER = "#2E5A87", "#5B8AB5", "#B0B0B0"

# display order and pretty names for the deep baselines; anything not listed is
# shown under its CSV name.
PRETTY = {
    "CSP": "CSP", "FBCSP": "FBCSP", "EEGNetv4": "EEGNet-v4",
    "ShallowFBCSPNet": "ShallowConvNet", "Deep4Net": "DeepConvNet",
    "EEGConformer": "EEG-Conformer", "ATCNet": "ATCNet",
    "EEGITNet": "EEG-ITNet", "EEGInception": "EEG-Inception",
    "EEGInceptionMI": "EEG-Inception-MI", "TCN": "TCN",
}
DSET_ORDER = ["2a", "2b", "PhysioNet", "HGD"]


def _save(fig, out_dir, name):
    os.makedirs(out_dir, exist_ok=True)
    for ext in ("png", "pdf"):
        fig.savefig(os.path.join(out_dir, f"{name}.{ext}"), dpi=300,
                    bbox_inches="tight")
    plt.close(fig)


def _load(csv, proposed, display):
    df = pd.read_csv(csv)
    df["method"] = df["method"].replace({proposed: display})
    df["acc"] = df["acc"].astype(float)
    if df["acc"].max() <= 1.5:            # fractions -> percent
        df["acc"] = df["acc"] * 100.0
    return df


def _pretty(name, display):
    return display if name == display else PRETTY.get(name, name)


def fig_main_accuracy(df, out_dir, display):
    dsets = [d for d in DSET_ORDER if d in df["dataset"].unique()]
    methods = (df.groupby("method")["acc"].mean().sort_values().index.tolist())
    methods = [m for m in methods if m != display] + [display]   # proposed last
    x = np.arange(len(dsets)); w = 0.8 / max(len(methods), 1)
    fig, ax = plt.subplots(figsize=(9, 4.6))
    for i, me in enumerate(methods):
        vals = [df[(df.dataset == d) & (df.method == me)]["acc"].mean()
                for d in dsets]
        color = (C_MAIN if me == display
                 else C_CLASSIC if me in ("FBCSP", "CSP") else None)
        ax.bar(x + (i - len(methods) / 2) * w, vals, w,
               label=_pretty(me, display), color=color,
               edgecolor="#333333", linewidth=0.3)
    ax.set_xticks(x); ax.set_xticklabels(dsets)
    ax.set_ylabel("Accuracy (percent)"); ax.set_ylim(0, 100)
    ax.set_title("Within-subject accuracy across datasets")
    ax.legend(ncol=4, fontsize=7, loc="upper center",
              bbox_to_anchor=(0.5, -0.12), frameon=False)
    _save(fig, out_dir, "fig1_main_accuracy")


def fig_paired_scatter(df, out_dir, display, comparator="FBCSP"):
    markers = {"2a": "o", "2b": "s", "PhysioNet": "^", "HGD": "D"}
    palette = {"2a": "#4C78A8", "2b": "#F58518", "PhysioNet": "#54A24B",
               "HGD": "#E45756"}
    fig, ax = plt.subplots(figsize=(5.6, 5.6))
    lo, hi = 20, 100
    ax.plot([lo, hi], [lo, hi], "--", color="#555555", lw=1.2, zorder=1)
    for d in [d for d in DSET_ORDER if d in df["dataset"].unique()]:
        sub = df[df.dataset == d]
        p = sub[sub.method == display].set_index("subject")["acc"]
        c = sub[sub.method == comparator].set_index("subject")["acc"]
        common = sorted(set(p.index) & set(c.index))
        if not common:
            continue
        ax.scatter([c[s] for s in common], [p[s] for s in common],
                   marker=markers.get(d, "o"), s=42, alpha=0.85,
                   color=palette.get(d, "#888"), edgecolor="white",
                   linewidth=0.5, label=d, zorder=3)
    ax.set_xlim(lo, hi); ax.set_ylim(lo, hi); ax.set_aspect("equal")
    ax.set_xlabel(f"{comparator} accuracy (percent)")
    ax.set_ylabel(f"{display} accuracy (percent)")
    ax.set_title(f"Per-subject: {display} vs {comparator}\n"
                 f"(above diagonal = proposed wins)")
    ax.legend(fontsize=9, loc="lower right", frameon=True)
    _save(fig, out_dir, "fig4_paired_scatter")


def fig_mean_rank(df, out_dir, display):
    # rank methods within each subject-dataset cell, lower acc = worse rank
    piv = df.pivot_table(index=["dataset", "subject"], columns="method",
                         values="acc")
    ranks = piv.rank(axis=1, ascending=False)      # 1 = best
    mean_rank = ranks.mean(axis=0).sort_values()
    m = [_pretty(x, display) for x in mean_rank.index]
    rk = mean_rank.values
    colors = [C_MAIN if mm == display else
              (C_CLASSIC if mm in ("FBCSP", "CSP") else C_OTHER) for mm in m]
    fig, ax = plt.subplots(figsize=(6.4, 4.6))
    y = np.arange(len(m))[::-1]
    ax.barh(y, rk, color=colors, edgecolor="#333333", linewidth=0.5)
    for yi, r in zip(y, rk):
        ax.text(r + 0.08, yi, f"{r:.2f}", va="center", fontsize=8.5)
    ax.set_yticks(y); ax.set_yticklabels(m, fontsize=9)
    ax.set_xlabel("Mean rank across subjects (lower is better)")
    ax.set_title("Overall mean rank")
    ax.set_xlim(0, max(rk) + 1)
    _save(fig, out_dir, "fig5_mean_rank")


def run(csv, out_dir, proposed, display):
    df = _load(csv, proposed, display)
    fig_main_accuracy(df, out_dir, display)
    fig_paired_scatter(df, out_dir, display)
    fig_mean_rank(df, out_dir, display)
    print(f"Regenerated fig1_main_accuracy, fig4_paired_scatter, fig5_mean_rank "
          f"with label '{display}' in {out_dir}")


def _selftest():
    import tempfile
    rng = np.random.default_rng(0)
    rows = []
    methods = ["FBCSPNet", "FBCSP", "CSP", "EEGNetv4", "Deep4Net"]
    base = {"FBCSPNet": 0.72, "FBCSP": 0.70, "CSP": 0.66, "EEGNetv4": 0.60,
            "Deep4Net": 0.57}
    for d, n in [("2a", 9), ("2b", 9), ("PhysioNet", 20), ("HGD", 14)]:
        for s in range(1, n + 1):
            for me in methods:
                rows.append((d, me, s, base[me] + rng.normal(0, 0.05)))
    csv = os.path.join(tempfile.mkdtemp(), "master_within.csv")
    pd.DataFrame(rows, columns=["dataset", "method", "subject", "acc"]).to_csv(
        csv, index=False)
    out = tempfile.mkdtemp()
    run(csv, out, "FBCSPNet", "NPN")
    for n in ("fig1_main_accuracy", "fig4_paired_scatter", "fig5_mean_rank"):
        assert os.path.getsize(os.path.join(out, n + ".pdf")) > 1000
        assert os.path.getsize(os.path.join(out, n + ".png")) > 1000
    # confirm the code name does not leak into a rendered label by re-reading df
    df = _load(csv, "FBCSPNet", "NPN")
    assert "FBCSPNet" not in df["method"].unique() and "NPN" in df["method"].unique()
    print("SELF-TEST PASSED: three figures render, proposed relabeled to NPN, "
          "no fabrication (all from CSV)")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    base = r"C:\Users\Anurag Tiwari\OneDrive\Desktop\Motor Imagery Classification-Work"
    ap.add_argument("--csv", default=os.path.join(base, "results", "master_within.csv"))
    ap.add_argument("--out", default=r"C:\mi_figures\final")
    ap.add_argument("--proposed", default="FBCSPNet",
                    help="method label of the proposed model in the CSV")
    ap.add_argument("--display", default="NPN",
                    help="name to show for the proposed model in figures")
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    if a.selftest:
        _selftest()
    else:
        run(a.csv, a.out, a.proposed, a.display)
