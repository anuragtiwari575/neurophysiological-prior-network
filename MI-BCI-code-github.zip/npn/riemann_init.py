"""
Riemannian tangent-space prior initialization (variant A1).

Instead of initializing the NPN spatial layer from Euclidean CSP filters, this
module derives spatial filters from the geometry of the SPD manifold:

  1. estimate a Riemannian (geometric) mean M of the trial covariances;
  2. map every trial to the tangent space at M, giving a symmetric matrix
     S_i = logm(M^-1/2 C_i M^-1/2);
  3. form the class-discriminative direction in the tangent space (mean of one
     class minus the mean of the rest), which is itself a symmetric matrix D;
  4. eigendecompose D and map its leading eigenvectors back through M^-1/2 to
     obtain spatial filters in channel space.

The result is a CSP-like set of spatial filters, but built from the Riemannian
geometric mean and tangent-space discriminability rather than from the
Euclidean covariance average and a generalized eigenproblem. The hypothesis is
that the geometric mean is more robust on noisy montages (e.g. PhysioNet),
where the Euclidean CSP degrades.

The manifold routines use pyriemann when available; a numpy fallback (Frechet
mean by gradient descent on the AIRM metric) keeps the pure-numeric parts
testable without it. The vectorize/unvectorize roundtrip and the filter shapes
are self-tested (--selftest); NPN integration is exercised on the machine.
"""
from __future__ import annotations
import numpy as np

try:                                           # pyriemann >= 0.13 moved these
    from pyriemann.geometry.mean import mean_riemann as _mean_riemann
except Exception:
    try:
        from pyriemann.utils.mean import mean_riemann as _mean_riemann
    except Exception:
        _mean_riemann = None


# --------------------------- SPD utilities ---------------------------
def _sqrtm(M):
    w, V = np.linalg.eigh(M)
    w = np.clip(w, 1e-12, None)
    return (V * np.sqrt(w)) @ V.T


def _invsqrtm(M):
    w, V = np.linalg.eigh(M)
    w = np.clip(w, 1e-12, None)
    return (V * (1.0 / np.sqrt(w))) @ V.T


def _logm(M):
    w, V = np.linalg.eigh(M)
    w = np.clip(w, 1e-12, None)
    return (V * np.log(w)) @ V.T


def trial_covariances(X, reg=1e-6):
    """Trace-normalized, regularized covariance of each trial in X (n, C, T)."""
    n, C, T = X.shape
    covs = np.empty((n, C, C))
    for i in range(n):
        x = X[i]
        S = x @ x.T
        S /= (np.trace(S) + 1e-12)
        covs[i] = S + reg * np.eye(C)
    return covs


def riemannian_mean(covs, n_iter=50, tol=1e-9):
    """Frechet mean on the SPD manifold under the affine-invariant metric.
    Uses pyriemann if present, else a numpy gradient descent."""
    if _mean_riemann is not None:
        return _mean_riemann(covs)
    M = covs.mean(0)                            # Euclidean init
    for _ in range(n_iter):
        Mis = _invsqrtm(M); Ms = _sqrtm(M)
        S = np.mean([_logm(Mis @ C @ Mis) for C in covs], axis=0)
        M = Ms @ _expm(S) @ Ms
        if np.linalg.norm(S) < tol:
            break
    return M


def _expm(M):
    w, V = np.linalg.eigh(M)
    return (V * np.exp(w)) @ V.T


def tangent_at(covs, M):
    """Tangent-space symmetric matrices S_i at reference M (not vectorized)."""
    Mis = _invsqrtm(M)
    return np.stack([_logm(Mis @ C @ Mis) for C in covs], axis=0)   # (n, C, C)


# --------------------------- A1: filters ---------------------------
def tangent_discriminative_filters(X, y, k):
    """Riemannian tangent-space discriminative spatial filters.
    X: (n, C, T) band-limited trials. Returns (<=k*, C) filter rows."""
    covs = trial_covariances(X)
    C = covs.shape[1]
    M = riemannian_mean(covs)
    S = tangent_at(covs, M)                     # (n, C, C) symmetric
    Mis = _invsqrtm(M)
    classes = np.unique(y)
    filters = []
    if len(classes) == 2:
        D = S[y == classes[0]].mean(0) - S[y == classes[1]].mean(0)
        D = 0.5 * (D + D.T)
        w, V = np.linalg.eigh(D)               # ascending
        order = np.argsort(np.abs(w))[::-1]     # most discriminative first
        for j in order[:k]:
            filters.append(Mis @ V[:, j])       # map back to channel space
    else:                                       # one-vs-rest, one filter each
        for cl in classes:
            D = S[y == cl].mean(0) - S[y != cl].mean(0)
            D = 0.5 * (D + D.T)
            w, V = np.linalg.eigh(D)
            j = np.argmax(np.abs(w))
            filters.append(Mis @ V[:, j])
        # pad with next-strongest global directions to reach k
        if len(filters) < k:
            Dall = S.std(0)
            w, V = np.linalg.eigh(0.5 * (Dall + Dall.T))
            for j in np.argsort(np.abs(w))[::-1]:
                filters.append(Mis @ V[:, j])
                if len(filters) >= k:
                    break
    F = np.array(filters[:k], dtype=np.float32)
    # unit-normalize rows for a well-scaled initialization
    F /= (np.linalg.norm(F, axis=1, keepdims=True) + 1e-12)
    return F


def band_riemann_filters(Xs, y, k):
    """Per-band Riemannian filters. Xs: (n, B, C, T). Returns list of (k, C)."""
    return [tangent_discriminative_filters(Xs[:, b], y, k)
            for b in range(Xs.shape[1])]


# --------------------------- self-test ---------------------------
def _selftest():
    rng = np.random.default_rng(0)
    n, C, T = 60, 8, 128
    # two classes with distinct spatial-spectral structure
    y = np.array([0] * (n // 2) + [1] * (n // 2))
    t = np.arange(T) / 128.0
    X = rng.standard_normal((n, C, T)) * 0.6
    for i in range(n):
        f = 11 if y[i] == 0 else 20
        ch = 1 if y[i] == 0 else 5
        X[i, ch] += 1.8 * np.sin(2 * np.pi * f * t + rng.uniform(0, 6))
    X = X.astype(np.float32)

    # SPD utilities roundtrip
    S = trial_covariances(X)[0]
    assert np.allclose(_sqrtm(S) @ _sqrtm(S), S, atol=1e-4)
    assert np.allclose(_invsqrtm(S) @ S @ _invsqrtm(S), np.eye(C), atol=1e-4)

    # Riemannian mean is SPD
    M = riemannian_mean(trial_covariances(X))
    assert np.all(np.linalg.eigvalsh(M) > 0)

    # filters: right shape, unit rows, and discriminative
    F = tangent_discriminative_filters(X, y, k=4)
    assert F.shape == (4, C)
    assert np.allclose(np.linalg.norm(F, axis=1), 1.0, atol=1e-5)
    # leading filter should separate classes in log-variance
    proj = (F[0] @ X).reshape(n, T)
    lv = np.log(proj.var(axis=1) + 1e-9)
    sep = abs(lv[y == 0].mean() - lv[y == 1].mean()) / (lv.std() + 1e-9)
    assert sep > 0.2, f"weak separation {sep:.3f}"

    # multiclass path
    y3 = rng.integers(0, 3, n)
    F3 = tangent_discriminative_filters(X, y3, k=4)
    assert F3.shape[1] == C and F3.shape[0] == 4

    # band wrapper
    Xs = np.stack([X, X * 0.9, X * 1.1], axis=1)
    fb = band_riemann_filters(Xs, y, k=3)
    assert len(fb) == 3 and fb[0].shape == (3, C)

    print(f"SELF-TEST PASSED: SPD sqrt/invsqrt roundtrip, Riemannian mean SPD, "
          f"tangent filters unit-normed and class-separating (sep={sep:.2f}), "
          f"multiclass + band wrappers OK")


if __name__ == "__main__":
    import sys
    if "--selftest" in sys.argv:
        _selftest()
    else:
        print("import band_riemann_filters / tangent_discriminative_filters")
