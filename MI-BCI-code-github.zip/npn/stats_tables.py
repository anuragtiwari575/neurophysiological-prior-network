"""
Paired statistics and publication tables for the within-subject study.

Reads results/master_within.csv (schema: dataset,method,subject,acc with acc in
[0,1], one fold-averaged value per subject) and produces:

  1. Paired tests of the proposed model vs every other method, per dataset and
     pooled across datasets: paired t-test + Wilcoxon signed-rank, mean
     difference, Cohen's dz effect size, Holm-corrected p-values.
  2. Main comparison table (mean +/- std per method per dataset, overall mean,
     rank), split from the ablation table.
  3. Ablation table (CSP-prior family only: initialization, K, F, augmentation).

Outputs (results/):
  stats_paired.csv, table_main.csv, table_ablation.csv, tables.tex
and prints everything.

Pure pandas/scipy; no torch. Sandbox self-test in __main__ guard at bottom via
--selftest.
"""
from __future__ import annotations
import os
import sys
import argparse
import numpy as np
import pandas as pd
from scipy import stats

PROPOSED = "FBCSPNet"
CHANCE = {"2a": 0.25, "2b": 0.50, "PhysioNet": 0.50, "HGD": 0.50}
DATASET_ORDER = ["2a", "2b", "PhysioNet", "HGD"]

# method grouping for the two tables
CLASSICAL = ["CSP", "FBCSP"]
ABLATION_FAMILY = ["random", "base", "K16", "wideF", "aug5", "FBCSPNet"]
BRAINDECODE = ["EEGNetv4", "ShallowFBCSPNet", "Deep4Net", "EEGConformer", "ATCNet",
               "EEGITNet", "EEGInception", "EEGInceptionMI", "TCN"]
# main table = classical + braindecode baselines + the proposed model
MAIN_METHODS = CLASSICAL + BRAINDECODE + [PROPOSED]

PRETTY = {
    "random": "CSPPriorNet (random init)",
    "base": "CSPPriorNet (base)",
    "K16": "CSPPriorNet (K=16)",
    "wideF": "CSPPriorNet (wide F)",
    "aug5": "CSPPriorNet (aug x5)",
    "FBCSPNet": "FBCSPNet (proposed)",
    "EEGNetv4": "EEGNet-v4", "ShallowFBCSPNet": "ShallowConvNet",
    "Deep4Net": "DeepConvNet", "EEGConformer": "EEG-Conformer",
    "EEGITNet": "EEG-ITNet", "EEGInception": "EEG-Inception",
    "EEGInceptionMI": "EEG-Inception-MI", "TCN": "TCN",
}


def load(path):
    df = pd.read_csv(path)
    df["subject"] = df["subject"].astype(str)
    df["acc"] = df["acc"].astype(float) * 100.0          # to percent
    return df


def degenerate_cells(df):
    """Flag (dataset, method) whose mean is at or below chance+2pt: unreliable
    (e.g. FBCSP on 3-channel PhysioNet). Reported, never silently dropped."""
    flags = []
    for (d, m), g in df.groupby(["dataset", "method"]):
        if g["acc"].mean() <= CHANCE[d] * 100 + 2.0:
            flags.append((d, m, round(g["acc"].mean(), 2)))
    return flags


def _paired(a_map, b_map):
    """a_map,b_map: dict subject->acc. Returns paired stats on shared subjects."""
    subs = sorted(set(a_map) & set(b_map))
    a = np.array([a_map[s] for s in subs], float)
    b = np.array([b_map[s] for s in subs], float)
    diff = a - b
    out = {"n": len(subs), "mean_a": a.mean(), "mean_b": b.mean(),
           "mean_diff": diff.mean(), "std_diff": diff.std(ddof=1) if len(subs) > 1 else 0.0}
    # paired t-test
    if len(subs) > 1 and np.any(diff != 0):
        out["t_p"] = float(stats.ttest_rel(a, b).pvalue)
    else:
        out["t_p"] = 1.0
    # Wilcoxon signed-rank (needs at least one non-zero diff)
    if np.any(diff != 0) and len(subs) >= 1:
        try:
            out["w_p"] = float(stats.wilcoxon(a, b, zero_method="wilcox").pvalue)
        except ValueError:
            out["w_p"] = 1.0
    else:
        out["w_p"] = 1.0
    # Cohen's dz for paired design
    out["dz"] = out["mean_diff"] / out["std_diff"] if out["std_diff"] > 0 else 0.0
    return out


def holm(pvals):
    """Holm-Bonferroni step-down. Returns adjusted p-values in original order."""
    m = len(pvals)
    order = np.argsort(pvals)
    adj = np.empty(m)
    running = 0.0
    for rank, idx in enumerate(order):
        val = (m - rank) * pvals[idx]
        running = max(running, val)
        adj[idx] = min(running, 1.0)
    return adj


def paired_stats(df):
    """Proposed vs every other method, per dataset and pooled."""
    rows = []
    methods = [m for m in df["method"].unique() if m != PROPOSED]
    scopes = DATASET_ORDER + ["POOLED"]
    for scope in scopes:
        sub = df if scope == "POOLED" else df[df["dataset"] == scope]
        # subject key namespaced by dataset so pooled pairs stay matched
        def acc_map(method):
            g = sub[sub["method"] == method]
            key = (g["dataset"] + ":" + g["subject"]) if scope == "POOLED" else g["subject"]
            return dict(zip(key, g["acc"]))
        prop = acc_map(PROPOSED)
        if not prop:
            continue
        raw = []
        for m in methods:
            bm = acc_map(m)
            if not bm:
                continue
            st = _paired(prop, bm)
            st.update({"scope": scope, "comparator": m})
            raw.append(st)
        if not raw:
            continue
        adj_t = holm([r["t_p"] for r in raw])
        adj_w = holm([r["w_p"] for r in raw])
        for r, at, aw in zip(raw, adj_t, adj_w):
            r["t_p_holm"], r["w_p_holm"] = at, aw
            rows.append(r)
    cols = ["scope", "comparator", "n", "mean_a", "mean_b", "mean_diff",
            "std_diff", "dz", "t_p", "t_p_holm", "w_p", "w_p_holm"]
    return pd.DataFrame(rows)[cols]


def _stars(p):
    return "***" if p < 1e-3 else "**" if p < 1e-2 else "*" if p < 5e-2 else "ns"


def mean_table(df, methods):
    """mean +/- std per method x dataset, plus overall mean and rank."""
    piv_m = df.pivot_table("acc", "method", "dataset", aggfunc="mean")
    piv_s = df.pivot_table("acc", "method", "dataset", aggfunc="std")
    dsets = [d for d in DATASET_ORDER if d in piv_m.columns]
    rows = []
    for m in methods:
        if m not in piv_m.index:
            continue
        rec = {"method": m}
        vals = []
        for d in dsets:
            mu, sd = piv_m.loc[m, d], piv_s.loc[m, d]
            rec[d] = f"{mu:.2f} +/- {sd:.2f}" if pd.notna(mu) else "-"
            if pd.notna(mu):
                vals.append(mu)
        rec["Mean"] = round(np.mean(vals), 2) if vals else np.nan
        rows.append(rec)
    out = pd.DataFrame(rows).set_index("method")
    out = out.sort_values("Mean", ascending=False)
    out.insert(len(out.columns), "Rank", np.arange(1, len(out) + 1))
    return out, dsets


def to_latex(main, ablation, dsets, stats_df):
    """booktabs tables, no em-dashes, American spelling."""
    def _mu(cell):
        try:
            return float(str(cell).split("+/-")[0])
        except ValueError:
            return -np.inf

    def block(tbl, caption, label):
        cols = dsets + ["Mean", "Rank"]
        # column maxima (for bolding the best per column)
        best = {}
        for c in dsets + ["Mean"]:
            vals = {m: _mu(tbl.loc[m, c]) for m in tbl.index}
            best[c] = max(vals, key=vals.get)
        header = "Method & " + " & ".join(cols) + r" \\"
        lines = [r"\begin{table}[t]", r"\centering",
                 r"\caption{" + caption + "}", r"\label{" + label + "}",
                 r"\begin{tabular}{l" + "c" * len(cols) + "}", r"\toprule", header,
                 r"\midrule"]
        for m, r in tbl.iterrows():
            name = PRETTY.get(m, m)
            cells = []
            for c in cols:
                v = str(r[c])
                if c in best and best[c] == m and _mu(r[c]) > -np.inf:
                    v = r"\textbf{" + v + "}"
                cells.append(v)
            lines.append(name.replace("_", r"\_") + " & " + " & ".join(cells) + r" \\")
        lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}", ""]
        return "\n".join(lines)

    tex = block(main, "Within-subject accuracy (percent) of the proposed model "
                "against classical and deep baselines across four datasets. "
                "Best mean in bold.", "tab:main")
    tex += "\n" + block(ablation, "Ablation of the CSP-prior family: effect of "
                        "initialization, number of spatial filters K, temporal "
                        "width F, and augmentation.", "tab:ablation")
    return tex


def kappa_table(df, methods):
    """BCI kappa = (acc - chance)/(1 - chance) per method per dataset, plus mean.
    Exact for balanced classes (all four MI datasets are class-balanced)."""
    piv = df.pivot_table("acc", "method", "dataset", aggfunc="mean") / 100.0
    dsets = [d for d in DATASET_ORDER if d in piv.columns]
    rows = []
    for m in methods:
        if m not in piv.index:
            continue
        rec = {"method": m}
        ks = []
        for d in dsets:
            acc = piv.loc[m, d]
            if pd.isna(acc):
                rec[d] = "-"; continue
            ch = CHANCE[d]
            k = (acc - ch) / (1 - ch)
            rec[d] = round(k, 3); ks.append(k)
        rec["Mean"] = round(np.mean(ks), 3) if ks else np.nan
        rows.append(rec)
    out = pd.DataFrame(rows).set_index("method").sort_values("Mean", ascending=False)
    return out


def run(path, out_dir):
    df = load(path)
    os.makedirs(out_dir, exist_ok=True)

    flags = degenerate_cells(df)
    if flags:
        print("DEGENERATE cells (mean <= chance+2pt, reported not dropped):")
        for d, m, v in flags:
            print(f"  {d:<10} {m:<16} mean={v:.2f}%  (chance {CHANCE[d]*100:.0f}%)")
        print()

    sdf = paired_stats(df)
    sdf.to_csv(os.path.join(out_dir, "stats_paired.csv"), index=False)
    print("=== Paired tests: {} vs each method ===".format(PROPOSED))
    print(f"  {'scope':<10}{'comparator':<16}{'n':>3}{'d_acc':>8}{'dz':>7}"
          f"{'t_holm':>9}{'W_holm':>9}  sig")
    for _, r in sdf.iterrows():
        print(f"  {r['scope']:<10}{r['comparator']:<16}{int(r['n']):>3}"
              f"{r['mean_diff']:>+8.2f}{r['dz']:>7.2f}"
              f"{r['t_p_holm']:>9.4f}{r['w_p_holm']:>9.4f}  {_stars(r['w_p_holm'])}")

    main, dsets = mean_table(df, MAIN_METHODS)
    abl, _ = mean_table(df, ABLATION_FAMILY)
    kap = kappa_table(df, MAIN_METHODS)
    main.to_csv(os.path.join(out_dir, "table_main.csv"))
    abl.to_csv(os.path.join(out_dir, "table_ablation.csv"))
    kap.to_csv(os.path.join(out_dir, "table_kappa.csv"))

    print("\n=== MAIN TABLE (mean +/- std, ranked) ===")
    print(main.to_string())
    print("\n=== ABLATION TABLE (CSP-prior family) ===")
    print(abl.to_string())
    print("\n=== KAPPA TABLE (Cohen's kappa, ranked) ===")
    print(kap.to_string())

    tex = to_latex(main, abl, dsets, sdf)
    open(os.path.join(out_dir, "tables.tex"), "w").write(tex)
    print(f"\nWrote: stats_paired.csv, table_main.csv, table_ablation.csv, "
          f"table_kappa.csv, tables.tex -> {out_dir}")
    return df, sdf, main, abl


# ------------------------- sandbox self-test -------------------------
def _selftest():
    import tempfile
    rng = np.random.default_rng(0)
    means = {  # approximate real per-dataset means (fraction) to make realistic data
        ("2a", "FBCSPNet"): .74, ("2a", "FBCSP"): .726, ("2a", "CSP"): .645,
        ("2a", "random"): .518, ("2a", "base"): .688, ("2a", "K16"): .70,
        ("2a", "wideF"): .689, ("2a", "aug5"): .705, ("2a", "EEGNetv4"): .56,
        ("2b", "FBCSPNet"): .731, ("2b", "FBCSP"): .739, ("2b", "CSP"): .712,
        ("2b", "random"): .699, ("2b", "base"): .72, ("2b", "K16"): .72,
        ("2b", "wideF"): .711, ("2b", "aug5"): .72, ("2b", "EEGNetv4"): .554,
        ("PhysioNet", "FBCSPNet"): .639, ("PhysioNet", "FBCSP"): .475,
        ("PhysioNet", "CSP"): .614, ("PhysioNet", "aug5"): .642,
        ("PhysioNet", "base"): .62, ("PhysioNet", "K16"): .60,
        ("PhysioNet", "wideF"): .63, ("PhysioNet", "random"): .555,
        ("HGD", "FBCSPNet"): .714, ("HGD", "FBCSP"): .716, ("HGD", "CSP"): .679,
        ("HGD", "base"): .684, ("HGD", "K16"): .659, ("HGD", "wideF"): .686,
        ("HGD", "aug5"): .684, ("HGD", "random"): .689,
    }
    nsub = {"2a": 9, "2b": 9, "PhysioNet": 10, "HGD": 14}
    rows = []
    for (d, m), mu in means.items():
        for s in range(1, nsub[d] + 1):
            rows.append((d, m, s, float(np.clip(rng.normal(mu, 0.07), 0.05, 0.99))))
    p = os.path.join(tempfile.mkdtemp(), "master_within.csv")
    pd.DataFrame(rows, columns=["dataset", "method", "subject", "acc"]).to_csv(p, index=False)
    out = tempfile.mkdtemp()
    df, sdf, main, abl = run(p, out)
    # assertions
    assert main.iloc[0].name == "FBCSPNet", ("best mean not FBCSPNet", main.index.tolist())
    assert set(["scope", "comparator", "t_p_holm", "w_p_holm"]).issubset(sdf.columns)
    assert (sdf["t_p_holm"] <= 1.0).all() and (sdf["t_p_holm"] >= 0).all()
    # holm monotonic sanity: adjusted >= raw
    assert (sdf["t_p_holm"] + 1e-9 >= sdf["t_p"]).all()
    assert os.path.exists(os.path.join(out, "tables.tex"))
    tex = open(os.path.join(out, "tables.tex")).read()
    assert "\\u2014" not in tex and "—" not in tex, "em-dash leaked into LaTeX"
    assert "toprule" in tex and "tab:ablation" in tex
    # degenerate detection caught FBCSP on PhysioNet
    flags = degenerate_cells(df)
    assert any(d == "PhysioNet" and m == "FBCSP" for d, m, _ in flags), flags
    print("\nSELF-TEST PASSED")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", default=None)
    ap.add_argument("--out", default=None)
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    if a.selftest:
        _selftest()
    else:
        base = r"C:\Users\Anurag Tiwari\OneDrive\Desktop\Motor Imagery Classification-Work"
        csv = a.csv or os.path.join(base, "results", "master_within.csv")
        out = a.out or os.path.join(base, "results")
        run(csv, out)
