"""
Five variants of Riemannian tangent-space initialization for the NPN spatial
layer, each returning per-band spatial filters comparable to CSP:

  v1 class_mean   per-class Riemannian (geometric) mean; discriminative
                  direction taken between the two class means in the tangent
                  space at the global mean.
  v2 multi_ref    several reference points (global mean + per-class means);
                  discriminative directions are pooled across references so the
                  init is not tied to a single tangent point.
  v3 whiten_csp   Riemannian-mean whitening followed by a standard CSP
                  generalized eigenproblem on the whitened covariances
                  (a robust-whitening hybrid of CSP).
  v4 geodesic     directions that most separate the classes along the geodesic
                  between the two class Riemannian means (log-map of one mean at
                  the other), eigendecomposed for spatial filters.
  v5 logeuclid    same construction as the baseline A1 tangent method but under
                  the log-Euclidean metric (matrix-log mean) instead of AIRM.

All variants return (k, C) unit-normalized filter rows per band and estimate
everything on the training partition only. Manifold routines use pyriemann
when present, with a numpy AIRM fallback. The constructions and shapes are
self-tested (--selftest). American spelling, no em-dashes.
"""
from __future__ import annotations
import numpy as np

try:
    from pyriemann.geometry.mean import mean_riemann as _mean_riemann
except Exception:
    try:
        from pyriemann.utils.mean import mean_riemann as _mean_riemann
    except Exception:
        _mean_riemann = None


# ----------------------------- SPD utilities -----------------------------
def _eigh(M):
    w, V = np.linalg.eigh(0.5 * (M + M.T))
    return np.clip(w, 1e-12, None), V


def _sqrtm(M):
    w, V = _eigh(M); return (V * np.sqrt(w)) @ V.T


def _invsqrtm(M):
    w, V = _eigh(M); return (V * (1.0 / np.sqrt(w))) @ V.T


def _logm(M):
    w, V = _eigh(M); return (V * np.log(w)) @ V.T


def _expm(M):
    w, V = np.linalg.eigh(0.5 * (M + M.T)); return (V * np.exp(w)) @ V.T


def trial_covariances(X, reg=1e-6):
    n, C, T = X.shape
    covs = np.empty((n, C, C))
    for i in range(n):
        S = X[i] @ X[i].T
        S /= (np.trace(S) + 1e-12)
        covs[i] = S + reg * np.eye(C)
    return covs


def airm_mean(covs, n_iter=50, tol=1e-9):
    if _mean_riemann is not None:
        return _mean_riemann(covs)
    M = covs.mean(0)
    for _ in range(n_iter):
        Mis, Ms = _invsqrtm(M), _sqrtm(M)
        S = np.mean([_logm(Mis @ C @ Mis) for C in covs], axis=0)
        M = Ms @ _expm(S) @ Ms
        if np.linalg.norm(S) < tol:
            break
    return M


def logeuclid_mean(covs):
    return _expm(np.mean([_logm(C) for C in covs], axis=0))


def _tangent(covs, M):
    Mis = _invsqrtm(M)
    return np.stack([_logm(Mis @ C @ Mis) for C in covs], axis=0), Mis


def _filters_from_symmetric(D, Mis, k):
    """Top-k spatial filters from a symmetric discriminative matrix D, mapped
    back to channel space by Mis (= M^-1/2)."""
    D = 0.5 * (D + D.T)
    w, V = np.linalg.eigh(D)
    order = np.argsort(np.abs(w))[::-1][:k]
    F = np.array([Mis @ V[:, j] for j in order], dtype=np.float32)
    F /= (np.linalg.norm(F, axis=1, keepdims=True) + 1e-12)
    return F




def _pad_to_k(rows, k):
    F = list(rows)
    while len(F) < k and len(F) > 0:
        F.append(F[len(F) % len(rows)])
    F = np.array(F[:k], np.float32)
    return F / (np.linalg.norm(F, axis=1, keepdims=True) + 1e-12)

# ----------------------------- the five variants -----------------------------
def v1_class_mean(X, y, k):
    covs = trial_covariances(X); classes = np.unique(y)
    M = airm_mean(covs); S, Mis = _tangent(covs, M)
    if len(classes) == 2:
        D = S[y == classes[0]].mean(0) - S[y == classes[1]].mean(0)
        return _filters_from_symmetric(D, Mis, k)
    rows = [_filters_from_symmetric(S[y == c].mean(0) - S[y != c].mean(0), Mis, 1)[0]
            for c in classes]
    return _pad_to_k(rows, k)


def v2_multi_ref(X, y, k):
    covs = trial_covariances(X); classes = np.unique(y)
    refs = [airm_mean(covs)] + [airm_mean(covs[y == c]) for c in classes]
    pooled = []
    for R in refs:
        S, Mis = _tangent(covs, R)
        if len(classes) == 2:
            D = S[y == classes[0]].mean(0) - S[y == classes[1]].mean(0)
            pooled.append(_filters_from_symmetric(D, Mis, k))
        else:
            for c in classes:
                D = S[y == c].mean(0) - S[y != c].mean(0)
                pooled.append(_filters_from_symmetric(D, Mis, 1))
    allF = np.vstack(pooled)
    chosen = []
    for f in allF:
        g = f.copy()
        for c in chosen:
            g = g - (g @ c) * c
        if np.linalg.norm(g) > 1e-6 and len(chosen) < k:
            chosen.append(g / np.linalg.norm(g))
    while len(chosen) < k:
        chosen.append(allF[len(chosen) % len(allF)])
    return _pad_to_k(chosen, k)


def v3_whiten_csp(X, y, k):
    covs = trial_covariances(X); classes = np.unique(y)
    M = airm_mean(covs); P = _invsqrtm(M)
    covw = np.stack([P @ C @ P.T for C in covs], axis=0)
    Cn = covw.shape[1]
    def _gevd(S1, S2):
        w, V = np.linalg.eigh(np.linalg.solve(S1 + S2 + 1e-6 * np.eye(Cn), S1))
        return w, V
    if len(classes) == 2:
        w, V = _gevd(covw[y == classes[0]].mean(0), covw[y == classes[1]].mean(0))
        order = np.argsort(np.abs(w - 0.5))[::-1][:k]
        rows = [P.T @ V[:, j] for j in order]
    else:
        rows = []
        for c in classes:
            w, V = _gevd(covw[y == c].mean(0), covw[y != c].mean(0))
            rows.append(P.T @ V[:, np.argmax(np.abs(w - 0.5))])
    return _pad_to_k(rows, k)


def v4_geodesic(X, y, k):
    covs = trial_covariances(X); classes = np.unique(y)
    if len(classes) == 2:
        M1 = airm_mean(covs[y == classes[0]]); M2 = airm_mean(covs[y == classes[1]])
        M1is = _invsqrtm(M1); D = _logm(M1is @ M2 @ M1is)
        return _filters_from_symmetric(D, M1is, k)
    rows = []
    for c in classes:
        M1 = airm_mean(covs[y == c]); M2 = airm_mean(covs[y != c])
        M1is = _invsqrtm(M1)
        rows.append(_filters_from_symmetric(_logm(M1is @ M2 @ M1is), M1is, 1)[0])
    return _pad_to_k(rows, k)


def v5_logeuclid(X, y, k):
    covs = trial_covariances(X); classes = np.unique(y)
    logs = np.stack([_logm(C) for C in covs], axis=0)
    Mlog = logs.mean(0); S = logs - Mlog
    Mis = _invsqrtm(_expm(Mlog))
    if len(classes) == 2:
        D = S[y == classes[0]].mean(0) - S[y == classes[1]].mean(0)
        return _filters_from_symmetric(D, Mis, k)
    rows = [_filters_from_symmetric(S[y == c].mean(0) - S[y != c].mean(0), Mis, 1)[0]
            for c in classes]
    return _pad_to_k(rows, k)


VARIANTS = {
    "class_mean": v1_class_mean,
    "multi_ref":  v2_multi_ref,
    "whiten_csp": v3_whiten_csp,
    "geodesic":   v4_geodesic,
    "logeuclid":  v5_logeuclid,
}


def band_filters(Xs, y, k, variant):
    fn = VARIANTS[variant]
    return [fn(Xs[:, b], y, k) for b in range(Xs.shape[1])]


# ----------------------------- self-test -----------------------------
def _selftest():
    rng = np.random.default_rng(0)
    n, C, T = 60, 8, 128
    y = np.array([0] * (n // 2) + [1] * (n // 2))
    t = np.arange(T) / 128.0
    X = rng.standard_normal((n, C, T)) * 0.6
    for i in range(n):
        f, ch = (11, 1) if y[i] == 0 else (20, 5)
        X[i, ch] += 1.8 * np.sin(2 * np.pi * f * t + rng.uniform(0, 6))
    X = X.astype(np.float32)

    for name, fn in VARIANTS.items():
        F = fn(X, y, 4)
        assert F.shape == (4, C), (name, F.shape)
        assert np.allclose(np.linalg.norm(F, axis=1), 1.0, atol=1e-4), name
        proj = (F[0] @ X).reshape(n, T)
        lv = np.log(proj.var(1) + 1e-9)
        sep = abs(lv[y == 0].mean() - lv[y == 1].mean()) / (lv.std() + 1e-9)
        print(f"  {name:<11} leading-filter class separation = {sep:.2f}")
        assert sep > 0.1, f"{name} weak ({sep:.2f})"

    # multiclass + band wrapper on one variant
    y3 = rng.integers(0, 3, n)
    assert v1_class_mean(X, y3, 4).shape == (4, C)
    Xs = np.stack([X, X * 0.9, X * 1.1], axis=1)
    fb = band_filters(Xs, y, 3, "whiten_csp")
    assert len(fb) == 3 and fb[0].shape == (3, C)
    print("SELF-TEST PASSED: all five variants produce unit-normed, "
          "class-separating filters; multiclass + band wrappers OK")


if __name__ == "__main__":
    import sys
    if "--selftest" in sys.argv:
        _selftest()
    else:
        print("variants:", list(VARIANTS))
