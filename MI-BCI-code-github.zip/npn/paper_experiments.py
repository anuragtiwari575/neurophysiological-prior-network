"""
Integrated experiment harness for the paper's surviving strong claims.

Four experiments behind one entry point, each crash-safe and resumable:
  channels   Channel-count causal test: subsample channels {22,16,12,8,6,4,3}
             and measure prior gain dAcc = Acc(CSP-init) - Acc(random-init).
  efficiency Training-set-size curve {20,40,60,80,100}% x {csp,random}.
  riemann    Riemannian baseline: MDM and tangent-space logistic regression.
  stats      Per-subject tables + hierarchical (nested) bootstrap CI from
             results/master_within.csv.

Usage:
    python paper_experiments.py channels   --datasets 2a
    python paper_experiments.py efficiency --datasets 2a,2b
    python paper_experiments.py riemann    --datasets 2a,2b,PhysioNet,HGD
    python paper_experiments.py stats
    python paper_experiments.py all        --datasets 2a,2b

Pure numerics self-tested (--selftest); training is torch, machine-smoked.
No em-dashes, American spelling.
"""
from __future__ import annotations
import os
import argparse
import numpy as np

try:
    import torch
    import torch.nn as nn
    _HAS_TORCH = True
except Exception:
    _HAS_TORCH = False

_RESULTS = None
CH_COUNTS = [22, 16, 12, 8, 6, 4, 3]
FRACTIONS = [0.2, 0.4, 0.6, 0.8, 1.0]


def _res_dir():
    if _RESULTS is not None:
        return _RESULTS
    base = r"C:\Users\Anurag Tiwari\OneDrive\Desktop\Motor Imagery Classification-Work"
    return os.path.join(base, "results")


def _done(path, keyn):
    if not os.path.exists(path):
        return set()
    return set(tuple(r.split(",")[:keyn]) for r in open(path).read().splitlines()[1:] if r.strip())


def _append(path, header, row):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    new = not os.path.exists(path)
    with open(path, "a") as f:
        if new:
            f.write(header + "\n")
        f.write(row + "\n")


def subsample_channels(n_channels, keep):
    if keep >= n_channels:
        return list(range(n_channels))
    idx = np.linspace(0, n_channels - 1, keep)
    return sorted(set(int(round(i)) for i in idx))[:keep]


def hierarchical_bootstrap(diffs_by_dataset, n=5000, alpha=0.05, seed=0):
    rng = np.random.default_rng(seed)
    dsets = [d for d, v in diffs_by_dataset.items() if len(v) > 0]
    if not dsets:
        return np.nan, np.nan, np.nan
    boots = np.empty(n)
    for b in range(n):
        per_ds = []
        for d in dsets:
            v = np.asarray(diffs_by_dataset[d], float)
            per_ds.append(v[rng.integers(0, len(v), len(v))].mean())
        boots[b] = np.mean(per_ds)
    obs = np.mean([np.mean(diffs_by_dataset[d]) for d in dsets])
    lo, hi = np.quantile(boots, [alpha / 2, 1 - alpha / 2])
    return float(obs), float(lo), float(hi)


def cohens_dz(diffs):
    d = np.asarray(diffs, float)
    return float(d.mean() / d.std(ddof=1)) if len(d) > 1 and d.std(ddof=1) > 0 else 0.0


def _fit_net(Xs, y, n_cls, init, epochs=300, seed=42, frac=1.0):
    from fbcsp_net import build_fbcspnet
    from augment import augment_train
    from mne.decoding import CSP
    from sklearn.model_selection import StratifiedKFold, train_test_split
    from sklearn.metrics import accuracy_score
    device = "cuda" if torch.cuda.is_available() else "cpu"
    nb, C = Xs.shape[1], Xs.shape[2]; K = min(4, C)
    skf = StratifiedKFold(5, shuffle=True, random_state=42); accs = []
    for tr, te in skf.split(np.zeros(len(y)), y):
        Xtr, ytr, Xte, yte = Xs[tr], y[tr], Xs[te], y[te]
        if frac < 1.0:
            keep, _ = train_test_split(np.arange(len(ytr)), train_size=frac,
                                       stratify=ytr, random_state=42)
            Xtr, ytr = Xtr[keep], ytr[keep]
        band_filters = []
        for b in range(nb):
            c = CSP(n_components=K, reg="ledoit_wolf", log=True)
            c.fit(Xtr[:, b], ytr); band_filters.append(c.filters_)
        ti, vi = train_test_split(np.arange(len(ytr)), test_size=0.15,
                                  stratify=ytr, random_state=42)
        fa, ya = augment_train(Xtr[ti].reshape(len(ti), nb * C, Xtr.shape[3]),
                               ytr[ti], factor=3.0, seed=42)
        Xa = fa.reshape(len(ya), nb, C, fa.shape[2])
        Tn = min(Xa.shape[3], Xtr[vi].shape[3], Xte.shape[3])
        Xa, Xv, Xte2 = Xa[..., :Tn], Xtr[vi][..., :Tn], Xte[..., :Tn]
        def t(a, d):
            return torch.tensor(np.asarray(a), dtype=d).to(device)
        torch.manual_seed(seed)
        model = build_fbcspnet(n_cls, C, band_filters, K=K, Fdim=16, kt=32).to(device)
        if init == "random":
            for m in model.spatials:
                nn.init.xavier_uniform_(m.weight)
        with torch.no_grad():
            model(t(Xa[:2], torch.float32))
        opt = torch.optim.Adam(model.parameters(), lr=1e-3); ce = nn.CrossEntropyLoss()
        LX, Ly = t(Xa, torch.float32), t(ya, torch.long)
        Xv_t, Xte_t = t(Xv, torch.float32), t(Xte2, torch.float32)
        best, bs, wait = -1, None, 0
        for _ in range(epochs):
            model.train(); perm = torch.randperm(len(Ly))
            for i in range(0, len(perm), 16):
                idx = perm[i:i + 16]; opt.zero_grad()
                ce(model(LX[idx]), Ly[idx]).backward(); opt.step()
            model.eval()
            with torch.no_grad():
                va = accuracy_score(ytr[vi], model(Xv_t).argmax(1).cpu())
            if va > best:
                best, bs, wait = va, {k: v.detach().cpu().clone()
                                      for k, v in model.state_dict().items()}, 0
            else:
                wait += 1
                if wait >= 60:
                    break
        if bs:
            model.load_state_dict(bs)
        model.eval()
        with torch.no_grad():
            accs.append(accuracy_score(yte, model(Xte_t).argmax(1).cpu()))
    return float(np.mean(accs))


def exp_channels(datasets=("2a",), epochs=300):
    import variants as V
    path = os.path.join(_res_dir(), "channels.csv"); done = _done(path, 3)
    for ds in datasets:
        for subj in V.subjects(ds):
            Xs, y = V.load_bands(ds, subj)
            Xs = ((Xs - Xs.mean(-1, keepdims=True)) /
                  (Xs.std(-1, keepdims=True) + 1e-7)).astype(np.float32)
            C = Xs.shape[2]
            keeps = [k for k in CH_COUNTS if k <= C]
            if C not in keeps:
                keeps = [C] + keeps
            for keep in keeps:
                if (ds, str(subj), str(keep)) in done:
                    continue
                Xk = Xs[:, :, subsample_channels(C, keep), :]
                try:
                    acsp = _fit_net(Xk, y, V.DATASET_NCLS[ds], "csp", epochs)
                    arnd = _fit_net(Xk, y, V.DATASET_NCLS[ds], "random", epochs)
                    _append(path, "dataset,subject,channels,acc_csp,acc_random,prior_gain",
                            f"{ds},{subj},{keep},{acsp:.4f},{arnd:.4f},{acsp-arnd:.4f}")
                    print(f"  {ds} S{subj} ch={keep:<3} csp={acsp*100:5.2f} "
                          f"rnd={arnd*100:5.2f} gain={(acsp-arnd)*100:+5.2f}", flush=True)
                except Exception as e:
                    print(f"  {ds} S{subj} ch={keep} FAILED: {e}", flush=True)


def exp_efficiency(datasets=("2a", "2b"), epochs=300):
    import variants as V
    path = os.path.join(_res_dir(), "efficiency.csv"); done = _done(path, 4)
    for ds in datasets:
        for subj in V.subjects(ds):
            Xs, y = V.load_bands(ds, subj)
            Xs = ((Xs - Xs.mean(-1, keepdims=True)) /
                  (Xs.std(-1, keepdims=True) + 1e-7)).astype(np.float32)
            for frac in FRACTIONS:
                for init in ("csp", "random"):
                    if (ds, str(subj), f"{frac}", init) in done:
                        continue
                    try:
                        a = _fit_net(Xs, y, V.DATASET_NCLS[ds], init, epochs, frac=frac)
                        _append(path, "dataset,subject,frac,init,acc",
                                f"{ds},{subj},{frac},{init},{a:.4f}")
                        print(f"  {ds} S{subj} frac={frac} {init:<6} acc={a*100:5.2f}", flush=True)
                    except Exception as e:
                        print(f"  {ds} S{subj} {frac} {init} FAILED: {e}", flush=True)


def exp_riemann(datasets=("2a", "2b", "PhysioNet", "HGD")):
    import variants as V
    from sklearn.model_selection import StratifiedKFold
    from sklearn.metrics import accuracy_score
    try:
        from pyriemann.estimation import Covariances
        from pyriemann.classification import MDM
        try:                                    # class renamed across versions
            from pyriemann.classification import TSClassifier as _TSC
        except Exception:
            from pyriemann.classification import TSclassifier as _TSC
    except Exception as e:
        print(f"pyriemann import failed ({e}). Run: "
              "pip install pyriemann --break-system-packages")
        return
    path = os.path.join(_res_dir(), "riemann.csv"); done = _done(path, 3)
    for ds in datasets:
        for subj in V.subjects(ds):
            X, y = V.load_within(ds, subj)
            skf = StratifiedKFold(5, shuffle=True, random_state=42)
            for name, mk in [("MDM", lambda: MDM()), ("TS+LR", lambda: _TSC())]:
                if (ds, str(subj), name) in done:
                    continue
                try:
                    accs = []
                    for tr, te in skf.split(X, y):
                        cov = Covariances("oas")
                        Ctr = cov.fit_transform(X[tr]); Cte = cov.transform(X[te])
                        clf = mk(); clf.fit(Ctr, y[tr])
                        accs.append(accuracy_score(y[te], clf.predict(Cte)))
                    a = float(np.mean(accs))
                    _append(path, "dataset,subject,method,acc", f"{ds},{subj},{name},{a:.4f}")
                    print(f"  {ds} S{subj} {name:<6} acc={a*100:5.2f}", flush=True)
                except Exception as e:
                    print(f"  {ds} S{subj} {name} FAILED: {e}", flush=True)


def exp_stats(proposed="FBCSPNet", comparator="FBCSP"):
    p = os.path.join(_res_dir(), "master_within.csv")
    if not os.path.exists(p):
        print("master_within.csv not found"); return
    rows = [r.split(",") for r in open(p).read().splitlines()[1:] if r.strip()]
    by = {}
    for ds, m, s, acc in rows:
        by.setdefault((ds, m), {})[s] = float(acc) * 100
    dsets = sorted({r[0] for r in rows})
    print(f"\n=== Per-subject {proposed} - {comparator} (accuracy points) ===")
    diffs_by_ds = {}
    for ds in dsets:
        a = by.get((ds, proposed), {}); b = by.get((ds, comparator), {})
        subs = sorted(set(a) & set(b), key=lambda x: int(x) if x.isdigit() else x)
        d = np.array([a[s] - b[s] for s in subs]); diffs_by_ds[ds] = d
        if len(d):
            print(f"  {ds:<10} n={len(d):<3} mean_diff={d.mean():+6.2f} dz={cohens_dz(d):+.2f}  "
                  + " ".join(f"{x:+.0f}" for x in d))
    mean, lo, hi = hierarchical_bootstrap(diffs_by_ds)
    print(f"\n  Hierarchical bootstrap (subjects nested in datasets):")
    print(f"  mean difference = {mean:+.2f} pts, 95% CI [{lo:+.2f}, {hi:+.2f}]")
    print("  -> " + ("proposed significantly higher (CI>0)" if lo > 0 else
                     "comparator significantly higher (CI<0)" if hi < 0 else
                     "parity (CI includes 0)"))


def run(cmd, datasets, epochs):
    if not _HAS_TORCH and cmd in ("channels", "efficiency", "all"):
        raise RuntimeError("torch not available on this machine")
    if cmd == "channels":
        exp_channels(datasets, epochs)
    elif cmd == "efficiency":
        exp_efficiency(datasets, epochs)
    elif cmd == "riemann":
        exp_riemann(datasets)
    elif cmd == "stats":
        exp_stats()
    elif cmd == "all":
        exp_channels(datasets, epochs); exp_efficiency(datasets, epochs)
        exp_riemann(datasets); exp_stats()


def _selftest():
    for keep in CH_COUNTS:
        idx = subsample_channels(22, keep)
        assert len(idx) == keep and max(idx) < 22 and idx == sorted(set(idx))
    assert subsample_channels(3, 6) == [0, 1, 2]
    d = {"2a": np.array([1.4, 2.0, -0.5, 3.1, 0.2, 1.1, 2.5, 0.8, 1.9]),
         "2b": np.array([-0.8, 0.5, -1.0, 0.2]),
         "PN": np.array([7.0, 6.5, 5.2, 8.1, 4.9, 6.0])}
    m, lo, hi = hierarchical_bootstrap(d, n=3000); assert lo <= m <= hi
    dpos = {"a": np.array([5., 6., 4.5, 5.5, 6.5]), "b": np.array([4., 5., 6.])}
    _, lop, _ = hierarchical_bootstrap(dpos, n=3000); assert lop > 0
    assert cohens_dz([1, 2, 3]) > 0 and cohens_dz([1, 1, 1]) == 0.0
    import tempfile
    global _RESULTS
    _RESULTS = tempfile.mkdtemp()
    with open(os.path.join(_RESULTS, "master_within.csv"), "w") as f:
        f.write("dataset,method,subject,acc\n")
        for s in range(1, 6):
            f.write(f"2a,FBCSPNet,{s},{0.74+0.01*s}\n2a,FBCSP,{s},{0.72+0.01*s}\n")
    exp_stats(); _RESULTS = None
    print("\nSELF-TEST PASSED: channel subsample, hierarchical bootstrap (nested CI), "
          "effect size, per-subject stats reader all verified")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", nargs="?", default="stats",
                    choices=["channels", "efficiency", "riemann", "stats", "all"])
    ap.add_argument("--datasets", default="2a,2b,PhysioNet,HGD")
    ap.add_argument("--epochs", type=int, default=300)
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    if a.selftest:
        _selftest()
    else:
        run(a.cmd, tuple(a.datasets.split(",")), a.epochs)
