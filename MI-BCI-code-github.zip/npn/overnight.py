"""
Overnight master runner for the motor-imagery paper.

Runs every remaining experiment back to back, each crash-safe and resumable,
so the whole thing can be launched once and left for several hours. Anything
already computed is skipped (each experiment keeps its own CSV and skips done
cells), a failure in one experiment never stops the next, everything is
timestamped to results/overnight_log.txt, and at the end a consolidated
MORNING SUMMARY table is printed and written to results/overnight_summary.txt.

What it runs, in order (edit STAGES to change):
  1. paper_experiments channels   (2a)          channel-count causal test
  2. paper_experiments efficiency (2a,2b)       data-efficiency curve
  3. paper_experiments riemann    (all 4)       Riemannian baselines
  4. uncertainty_cohort           (all 4)       cohort uncertainty/calibration
  5. paper_experiments stats                    hierarchical bootstrap
  6. figures                      (from CSV)    result figures

Usage (leave it running):
    python overnight.py
    python overnight.py --hours 6           # soft time budget; stops starting
                                            # new stages after the budget
Restarting the same command resumes: finished cells are skipped.

Only the orchestration and the summary reader are logic here; the heavy work
lives in the already-tested modules. Windows note: set Power > Sleep = Never
so the machine does not suspend mid run.
"""
from __future__ import annotations
import os
import sys
import time
import argparse
import datetime
import traceback

BASE = r"C:\Users\Anurag Tiwari\OneDrive\Desktop\Motor Imagery Classification-Work"
RESULTS = os.path.join(BASE, "results")
LOG = os.path.join(RESULTS, "overnight_log.txt")
SUMMARY = os.path.join(RESULTS, "overnight_summary.txt")

# each stage: (label, callable-name, kwargs). Callables are resolved lazily so
# an import error in one module does not stop the others.
STAGES = [
    ("channels 2a",        "channels",   {"datasets": ("2a",)}),
    ("efficiency 2a,2b",   "efficiency", {"datasets": ("2a", "2b")}),
    ("riemann all",        "riemann",    {"datasets": ("2a", "2b", "PhysioNet", "HGD")}),
    ("uncertainty cohort", "uncert",     {"datasets": ("2a", "2b", "PhysioNet", "HGD")}),
    ("hierarchical stats", "stats",      {}),
    ("result figures",     "figures",    {}),
]


def _log(msg):
    line = f"[{datetime.datetime.now():%Y-%m-%d %H:%M:%S}] {msg}"
    print(line, flush=True)
    os.makedirs(RESULTS, exist_ok=True)
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(line + "\n")


def _dispatch(name, kwargs):
    if name == "channels":
        import paper_experiments as P
        P.exp_channels(**kwargs)
    elif name == "efficiency":
        import paper_experiments as P
        P.exp_efficiency(**kwargs)
    elif name == "riemann":
        import paper_experiments as P
        P.exp_riemann(**kwargs)
    elif name == "stats":
        import paper_experiments as P
        P.exp_stats()
    elif name == "uncert":
        import uncertainty_cohort as U
        U.run(**kwargs)
    elif name == "figures":
        import figures as F
        F.run(os.path.join(RESULTS, "master_within.csv"),
              os.path.join(RESULTS, "figures"))
    else:
        raise ValueError(name)


# --------------------------- morning summary ---------------------------
def _read_csv(path):
    if not os.path.exists(path):
        return None, []
    rows = [r.split(",") for r in open(path).read().splitlines() if r.strip()]
    return rows[0], rows[1:]


def _mean_by(rows, keycols, valcol, header):
    import numpy as np
    idx = {h: i for i, h in enumerate(header)}
    agg = {}
    for r in rows:
        k = tuple(r[idx[c]] for c in keycols)
        agg.setdefault(k, []).append(float(r[idx[valcol]]))
    return {k: float(np.mean(v)) for k, v in agg.items()}


def morning_summary():
    import numpy as np
    out = []
    out.append("=" * 64)
    out.append("MORNING SUMMARY  " + datetime.datetime.now().strftime("%Y-%m-%d %H:%M"))
    out.append("=" * 64)

    # channels: prior gain vs channel count (2a)
    h, rows = _read_csv(os.path.join(RESULTS, "channels.csv"))
    if rows:
        r2a = [r for r in rows if r[0] == "2a"]
        m = _mean_by(r2a, ["channels"], "prior_gain", h)
        out.append("\n[1] Channel-count causal test (2a): prior gain = Acc(CSP) - Acc(random)")
        for ch in sorted({int(k[0]) for k in m}, reverse=True):
            out.append(f"    {ch:>2} ch : {m[(str(ch),)]*100:+6.2f} pts")

    # efficiency: csp vs random by fraction (2a)
    h, rows = _read_csv(os.path.join(RESULTS, "efficiency.csv"))
    if rows:
        r2a = [r for r in rows if r[0] == "2a"]
        mc = _mean_by([r for r in r2a if r[3] == "csp"], ["frac"], "acc", h)
        mr = _mean_by([r for r in r2a if r[3] == "random"], ["frac"], "acc", h)
        out.append("\n[2] Data efficiency (2a): accuracy by training fraction")
        out.append("    frac    CSP-init  random  gain")
        for fr in sorted(mc):
            g = (mc[fr] - mr.get(fr, (float('nan'),))) * 100
            out.append(f"    {float(fr[0])*100:>4.0f}%   {mc[fr]*100:6.2f}   "
                       f"{mr.get(fr,0)*100:6.2f}  {g:+6.2f}")

    # riemann: mean per dataset per method
    h, rows = _read_csv(os.path.join(RESULTS, "riemann.csv"))
    if rows:
        out.append("\n[3] Riemannian baselines (mean accuracy %)")
        m = _mean_by(rows, ["dataset", "method"], "acc", h)
        dsets = sorted({k[0] for k in m}); meths = sorted({k[1] for k in m})
        out.append("    dataset   " + "".join(f"{me:>10}" for me in meths))
        for d in dsets:
            out.append(f"    {d:<10}" + "".join(
                f"{m.get((d,me),float('nan'))*100:>10.2f}" for me in meths))

    # uncertainty cohort: key metrics with simple mean
    h, rows = _read_csv(os.path.join(RESULTS, "uncertainty_cohort.csv"))
    if rows and h:
        idx = {c: i for i, c in enumerate(h)}
        out.append(f"\n[4] Cohort uncertainty/calibration (N={len(rows)} subjects)")
        for k in ("auroc", "ece", "adaece", "cohend"):
            if k in idx:
                v = np.array([float(r[idx[k]]) for r in rows])
                out.append(f"    {k:<8} mean={np.nanmean(v):.3f}")

    # main within-subject table (accuracy) if present
    h, rows = _read_csv(os.path.join(RESULTS, "master_within.csv"))
    if rows:
        m = _mean_by(rows, ["method", "dataset"], "acc", h)
        methods = sorted({k[0] for k in m})
        dsets = ["2a", "2b", "PhysioNet", "HGD"]
        out.append("\n[5] Within-subject accuracy (mean %), for reference")
        out.append("    method            " + "".join(f"{d:>11}" for d in dsets) + f"{'Mean':>9}")
        rank = []
        for me in methods:
            vals = [m.get((me, d)) for d in dsets]
            vv = [x for x in vals if x is not None]
            rank.append((np.mean(vv) if vv else 0, me, vals))
        for mean, me, vals in sorted(rank, reverse=True):
            out.append(f"    {me:<18}" + "".join(
                (f"{v*100:>11.2f}" if v is not None else f"{'-':>11}") for v in vals)
                + f"{mean*100:>9.2f}")

    text = "\n".join(out)
    print("\n" + text)
    with open(SUMMARY, "w", encoding="utf-8") as f:
        f.write(text + "\n")
    _log(f"summary written to {SUMMARY}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--hours", type=float, default=6.0,
                    help="soft budget: do not START a new stage after this many hours")
    args = ap.parse_args()
    t0 = time.time()
    _log(f"OVERNIGHT RUN START (budget {args.hours} h). Set Power > Sleep = Never.")
    for label, name, kwargs in STAGES:
        elapsed = (time.time() - t0) / 3600.0
        if elapsed > args.hours:
            _log(f"time budget reached ({elapsed:.1f} h); skipping remaining stages")
            break
        _log(f"STAGE START: {label}")
        try:
            _dispatch(name, kwargs)
            _log(f"STAGE DONE : {label}")
        except Exception as e:
            _log(f"STAGE FAILED: {label} :: {e}")
            with open(LOG, "a", encoding="utf-8") as f:
                f.write(traceback.format_exc() + "\n")
    _log(f"ALL STAGES ATTEMPTED in {(time.time()-t0)/3600:.2f} h. Building summary.")
    try:
        morning_summary()
    except Exception as e:
        _log(f"summary failed: {e}")
    _log("OVERNIGHT RUN COMPLETE.")


# --------------------------- self-test ---------------------------
def _selftest():
    import tempfile, numpy as np
    global RESULTS, LOG, SUMMARY
    RESULTS = tempfile.mkdtemp(); LOG = os.path.join(RESULTS, "log.txt")
    SUMMARY = os.path.join(RESULTS, "sum.txt")
    # synthetic CSVs
    with open(os.path.join(RESULTS, "channels.csv"), "w") as f:
        f.write("dataset,subject,channels,acc_csp,acc_random,prior_gain\n")
        for s in range(1, 4):
            for ch, g in [(22, .16), (12, .12), (3, .02)]:
                f.write(f"2a,{s},{ch},{0.7:.4f},{0.7-g:.4f},{g:.4f}\n")
    with open(os.path.join(RESULTS, "efficiency.csv"), "w") as f:
        f.write("dataset,subject,frac,init,acc\n")
        for s in range(1, 3):
            for fr in (0.2, 1.0):
                f.write(f"2a,{s},{fr},csp,{0.5+fr*0.2:.4f}\n2a,{s},{fr},random,{0.3+fr*0.2:.4f}\n")
    with open(os.path.join(RESULTS, "riemann.csv"), "w") as f:
        f.write("dataset,subject,method,acc\n2a,1,MDM,0.60\n2a,1,TS+LR,0.69\n")
    with open(os.path.join(RESULTS, "master_within.csv"), "w") as f:
        f.write("dataset,method,subject,acc\n2a,FBCSPNet,1,0.74\n2a,FBCSP,1,0.72\n")
    morning_summary()
    assert os.path.exists(SUMMARY) and os.path.getsize(SUMMARY) > 100
    txt = open(SUMMARY).read()
    assert "Channel-count" in txt and "Data efficiency" in txt and "Riemannian" in txt
    print("\nSELF-TEST PASSED: summary reads channels/efficiency/riemann/main tables and writes file")


if __name__ == "__main__":
    if "--selftest" in sys.argv:
        _selftest()
    else:
        main()
