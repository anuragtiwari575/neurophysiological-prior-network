"""
Two flagship figures for the JNE paper, built from the experiment CSVs.

  fig_channel_scaling  prior gain dAcc = Acc(CSP-init) - Acc(random-init) as a
                       function of channel count on 2a (mean +/- SEM over
                       subjects), showing the prior helps in proportion to the
                       spatial dimensionality.
  fig_data_efficiency  accuracy vs training-set fraction for CSP-init and
                       random-init, with the horizontal line marking
                       random-init at 100% data, showing CSP-init reaches it
                       with a small fraction of the data.

Reads results/channels.csv and results/efficiency.csv, writes 300 dpi
png+pdf. Pure pandas/matplotlib; self-tested from synthetic CSVs. American
spelling, no em-dashes.
"""
from __future__ import annotations
import os
import argparse
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({
    "font.size": 11, "axes.titlesize": 12, "axes.titleweight": "bold",
    "axes.labelsize": 11, "axes.linewidth": 0.9, "axes.edgecolor": "#444444",
    "axes.grid": True, "grid.color": "#DDDDDD", "grid.linewidth": 0.7,
})
plt.rcParams["axes.spines.top"] = False
plt.rcParams["axes.spines.right"] = False
C_CSP, C_RND, C_ACC = "#2E5A87", "#B0B0B0", "#C44E52"


def _save(fig, out_dir, name):
    os.makedirs(out_dir, exist_ok=True)
    for ext in ("png", "pdf"):
        fig.savefig(os.path.join(out_dir, f"{name}.{ext}"), dpi=300, bbox_inches="tight")
    plt.close(fig)


def fig_channel_scaling(channels_csv, out_dir, dataset="2a"):
    df = pd.read_csv(channels_csv)
    d = df[df.dataset == dataset]
    g = d.groupby("channels")["prior_gain"].agg(["mean", "std", "count"]).sort_index()
    g["sem"] = g["std"] / np.sqrt(g["count"].clip(lower=1))
    x = g.index.values
    y = g["mean"].values * 100
    err = g["sem"].values * 100
    fig, ax = plt.subplots(figsize=(6.2, 4.4))
    ax.axhline(0, color="#888888", lw=0.8, ls=":")
    ax.errorbar(x, y, yerr=err, marker="o", ms=7, lw=2.2, color=C_CSP,
                capsize=4, capthick=1.2, zorder=3)
    ax.fill_between(x, y - err, y + err, color=C_CSP, alpha=0.15, zorder=1)
    ax.set_xlabel("Number of channels")
    ax.set_ylabel("Prior gain (percentage points)")
    ax.set_title(f"Neurophysiological prior gain vs channel count ({dataset})")
    ax.set_xticks(sorted(x))
    ax.invert_xaxis()          # many -> few, left to right
    for xi, yi in zip(x, y):
        ax.annotate(f"{yi:+.1f}", (xi, yi), textcoords="offset points",
                    xytext=(0, 9), ha="center", fontsize=8.5, color="#333333")
    _save(fig, out_dir, "fig_channel_scaling")
    return g


def fig_data_efficiency(efficiency_csv, out_dir, dataset="2a"):
    df = pd.read_csv(efficiency_csv)
    d = df[df.dataset == dataset]
    piv = d.groupby(["frac", "init"])["acc"].agg(["mean", "std", "count"]).reset_index()
    piv["sem"] = piv["std"] / np.sqrt(piv["count"].clip(lower=1))
    fig, ax = plt.subplots(figsize=(6.2, 4.4))
    for init, col, lab in [("csp", C_CSP, "CSP-init (proposed)"),
                           ("random", C_RND, "Random-init")]:
        s = piv[piv.init == init].sort_values("frac")
        x = s["frac"].values * 100
        y = s["mean"].values * 100
        e = s["sem"].values * 100
        ax.errorbar(x, y, yerr=e, marker="o", ms=6, lw=2.2, color=col,
                    capsize=4, label=lab, zorder=3)
        ax.fill_between(x, y - e, y + e, color=col, alpha=0.15)
    # reference: random at 100%
    r100 = piv[(piv.init == "random") & (np.isclose(piv.frac, 1.0))]
    if len(r100):
        yv = r100["mean"].values[0] * 100
        ax.axhline(yv, color=C_ACC, ls="--", lw=1.4,
                   label=f"Random-init at 100% data ({yv:.1f}%)")
    ax.set_xlabel("Training data used (percent)")
    ax.set_ylabel("Accuracy (percent)")
    ax.set_title(f"Data efficiency of the neurophysiological prior ({dataset})")
    ax.legend(fontsize=8.5, loc="lower right", frameon=False)
    _save(fig, out_dir, "fig_data_efficiency")
    return piv


def run(results_dir, out_dir):
    fig_channel_scaling(os.path.join(results_dir, "channels.csv"), out_dir)
    fig_data_efficiency(os.path.join(results_dir, "efficiency.csv"), out_dir)
    print("Flagship figures written to", out_dir)
    for f in sorted(os.listdir(out_dir)):
        if f.startswith("fig_channel") or f.startswith("fig_data"):
            print("  ", f)


def _selftest():
    import tempfile
    r = tempfile.mkdtemp()
    # synthetic channels.csv with a decreasing gain
    rows = []
    for s in range(1, 10):
        for ch, g in [(22, .16), (16, .15), (12, .14), (8, .09),
                      (6, .07), (4, .04), (3, .02)]:
            rows.append(("2a", s, ch, 0.70, 0.70 - g, g))
    pd.DataFrame(rows, columns=["dataset", "subject", "channels", "acc_csp",
                                "acc_random", "prior_gain"]).to_csv(
        os.path.join(r, "channels.csv"), index=False)
    erows = []
    for s in range(1, 10):
        for fr in (0.2, 0.4, 0.6, 0.8, 1.0):
            erows.append(("2a", s, fr, "csp", 0.45 + fr * 0.20))
            erows.append(("2a", s, fr, "random", 0.28 + fr * 0.20))
    pd.DataFrame(erows, columns=["dataset", "subject", "frac", "init", "acc"]).to_csv(
        os.path.join(r, "efficiency.csv"), index=False)
    out = tempfile.mkdtemp()
    g = fig_channel_scaling(os.path.join(r, "channels.csv"), out)
    fig_data_efficiency(os.path.join(r, "efficiency.csv"), out)
    assert g["mean"].iloc[-1] > g["mean"].iloc[0]  # gain higher at more channels
    for n in ("fig_channel_scaling", "fig_data_efficiency"):
        assert os.path.getsize(os.path.join(out, n + ".png")) > 1000
        assert os.path.exists(os.path.join(out, n + ".pdf"))
    print("SELF-TEST PASSED: both flagship figures render from CSV; "
          "channel gain decreases with fewer channels")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default=None)
    ap.add_argument("--out", default=None)
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    if a.selftest:
        _selftest()
    else:
        base = r"C:\Users\Anurag Tiwari\OneDrive\Desktop\Motor Imagery Classification-Work"
        run(a.results or os.path.join(base, "results"),
            a.out or r"C:\mi_figures\flagship")
