"""
Controlled prior experiments for the NPN revision (Exp A, Exp B, sanity runs).

Subcommands
  smoke       end-to-end check on synthetic data (one to three minutes); run it
              first on the machine that will run the real experiments
  check-data  load every requested subject once and print shape, class counts,
              and amplitude (with --loader moabb this also downloads the data)
  diagnose    input units, first-BatchNorm scale, spatial-weight norms, and
              power per filter-bank band
  run         train and test the selected conditions; one CSV row per fold;
              finished cells are skipped, so a run can be interrupted and resumed
  summarize   subject-level means and paired comparisons from result CSVs

Data loaders
  --loader repo    npn/loaders.py, your own adapters (default; needs --root)
  --loader moabb   npn/moabb_loaders.py: BCI-IV-2a and 2b through MOABB, 8-30 Hz
                   zero-phase Butterworth, sessions pooled, window --tmin/--tmax
                   (default 0.5-4.0 s after the cue), --units V (default) or uV

Presets (condition:input_scale:recipe)
  expA     npn_random, npn_random_scaled, npn_csp_broadband, npn_csp_band
           with raw input (the paper's NPN setting)
  expB     npn_random, npn_random_scaled, npn_csp_band, eegnet_random,
           cspnet2_fix, cspnet2_upd with global input scaling and the NPN
           training recipe for every model
  sanity   eegnet_random with trial_z input and the NPN recipe (the paper's
           deep-baseline setting), and with global input and the CSP-Net
           recipe (Adam 0.01, weight decay 5e-4, batch 128, 200 epochs)
  tonight  expA + expB + sanity (12 jobs per fold)

Examples
  python scripts/run_prior_experiments.py smoke
  python scripts/run_prior_experiments.py check-data --loader moabb --datasets 2a --root /data/mne
  python scripts/run_prior_experiments.py diagnose --loader moabb --datasets 2a --subjects 1 --root /data/mne
  python scripts/run_prior_experiments.py run --preset tonight --loader moabb --datasets 2a \\
      --seeds 42,43 --root /data/mne --dry-run
  CUDA_VISIBLE_DEVICES=0 python scripts/run_prior_experiments.py run --preset tonight \\
      --loader moabb --datasets 2a --subjects 1-3 --seeds 42,43 --root /data/mne \\
      --out results/prior_gpu0.csv
  python scripts/run_prior_experiments.py summarize --inputs "results/prior_gpu*.csv"
"""
from __future__ import annotations

import argparse
import csv
try:
    import fcntl  # POSIX file locking
    _HAS_FCNTL = True
except ImportError:
    fcntl = None
    _HAS_FCNTL = False  # Windows: fall back to no advisory lock
import glob
import json
import os
import platform
import socket
import sys
import tempfile
import time
import traceback

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import torch                                        # noqa: E402
from npn import prior_experiments as P            # noqa: E402
from npn.data import to_bands, FILTER_BANK         # noqa: E402

HEADER = ["dataset", "subject", "condition", "input_scale", "recipe", "seed", "fold",
          "frac", "n_train", "n_test", "acc", "kappa", "best_val", "epochs_run",
          "spatial_cos", "spatial_norm_ratio", "seconds"]
KEY = HEADER[:8]
DEFAULT_OUT = os.path.join(os.environ.get("NPN_RESULTS", "results"), "prior_experiments.csv")

PRESETS = {
    "expA": [("npn_random", "raw", "npn"), ("npn_random_scaled", "raw", "npn"),
             ("npn_csp_broadband", "raw", "npn"), ("npn_csp_band", "raw", "npn")],
    "expB": [("npn_random", "global", "npn"), ("npn_random_scaled", "global", "npn"),
             ("npn_csp_band", "global", "npn"),
             ("eegnet_random", "global", "npn"), ("cspnet2_fix", "global", "npn"),
             ("cspnet2_upd", "global", "npn")],
    "sanity": [("eegnet_random", "trial_z", "npn"), ("eegnet_random", "global", "cspnet")],
    # every code path, used by the smoke test
    "all_paths": ([(c, "raw", "npn") for c in P.NPN_CONDITIONS]
                  + [("npn_csp_band", "global", "npn"), ("npn_csp_band", "trial_z", "npn")]
                  + [(c, "global", "npn") for c in P.EEGNET_CONDITIONS]
                  + [(c, "raw", "cspnet") for c in P.EEGNET_CONDITIONS]
                  + [("eegnet_random", "trial_z", "npn")]),
}
PRESETS["tonight"] = PRESETS["expA"] + PRESETS["expB"] + PRESETS["sanity"]

DEFAULT_PAIRS = [
    ("npn_csp_band|raw|npn", "npn_random|raw|npn", "prior gain, raw input (paper setting)"),
    ("npn_random_scaled|raw|npn", "npn_random|raw|npn", "gain from matching filter scale only"),
    ("npn_csp_band|raw|npn", "npn_random_scaled|raw|npn", "gain from CSP directions only"),
    ("npn_csp_band|raw|npn", "npn_csp_broadband|raw|npn", "band-specific vs broadband prior"),
    ("npn_csp_band|global|npn", "npn_random|global|npn", "prior gain, scale-controlled input"),
    ("npn_csp_band|global|npn", "npn_random_scaled|global|npn", "CSP directions only, global input"),
    ("npn_csp_band|global|npn", "cspnet2_fix|global|npn", "NPN vs CSP-Net-2 (fix)"),
    ("npn_csp_band|global|npn", "cspnet2_upd|global|npn", "NPN vs CSP-Net-2 (upd)"),
    ("cspnet2_fix|global|npn", "eegnet_random|global|npn", "CSP-Net-2 (fix) gain on EEGNet"),
    ("cspnet2_upd|global|npn", "eegnet_random|global|npn", "CSP-Net-2 (upd) gain on EEGNet"),
    ("eegnet_random|global|npn", "eegnet_random|trial_z|npn", "input: global vs per-trial z-score"),
    ("eegnet_random|global|cspnet", "eegnet_random|global|npn", "recipe: CSP-Net vs NPN"),
]


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #
def parse_ints(spec):
    """'1-9', '1,3,5', '42-46,50' -> list of ints; 'all', '' or None -> None."""
    if spec is None or str(spec).strip().lower() in ("", "all"):
        return None
    out = []
    for part in str(spec).split(","):
        part = part.strip()
        if "-" in part:
            a, b = part.split("-", 1)
            out.extend(range(int(a), int(b) + 1))
        elif part:
            out.append(int(part))
    return out


def fmt_frac(frac):
    return f"{float(frac):g}"


def cell_key(ds, subj, cond, scale, recipe, seed, fold, frac):
    return (str(ds), str(subj), cond, scale, recipe, str(seed), str(fold), fmt_frac(frac))


def read_done(path):
    if not os.path.exists(path):
        return set()
    with open(path, newline="") as f:
        return {tuple(r[k] for k in KEY) for r in csv.DictReader(f)}


def append_row(path, row):
    """Append one row under an exclusive lock; writes the header for a new file."""
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "a+", newline="") as f:
        if _HAS_FCNTL:
            fcntl.flock(f, fcntl.LOCK_EX)
        try:
            f.seek(0, os.SEEK_END)
            w = csv.writer(f)
            if f.tell() == 0:
                w.writerow(HEADER)
            w.writerow([row[h] for h in HEADER])
            f.flush()
            os.fsync(f.fileno())
        finally:
            if _HAS_FCNTL:
                fcntl.flock(f, fcntl.LOCK_UN)


def unit_guess(std):
    if std < 1e-3:
        return "volts (MNE convention)"
    if std > 0.1:
        return "microvolts or standardized"
    return "unclear"


def resolve_jobs(args):
    if args.preset:
        jobs = []
        for name in args.preset.split(","):
            if name not in PRESETS:
                raise SystemExit(f"unknown preset {name!r}; choose from {sorted(PRESETS)}")
            jobs.extend(PRESETS[name])
    else:
        if not args.conditions:
            raise SystemExit("give --preset or --conditions")
        scale = args.input_scale or "raw"
        recipe = args.recipe or "npn"
        jobs = [(c.strip(), scale, recipe) for c in args.conditions.split(",") if c.strip()]
    seen, uniq = set(), []
    for c, s, r in jobs:
        if c not in P.CONDITIONS:
            raise SystemExit(f"unknown condition {c!r}; choose from {list(P.CONDITIONS)}")
        if s not in P.INPUT_SCALES:
            raise SystemExit(f"unknown input scale {s!r}; choose from {list(P.INPUT_SCALES)}")
        if r not in P.RECIPES:
            raise SystemExit(f"unknown recipe {r!r}; choose from {list(P.RECIPES)}")
        if c in P.NPN_CONDITIONS:
            r = "npn"                              # NPN always uses the paper protocol
        if (c, s, r) not in seen:
            seen.add((c, s, r))
            uniq.append((c, s, r))
    return uniq


# --------------------------------------------------------------------------- #
# data loading
# --------------------------------------------------------------------------- #
def repo_info(ds):
    from npn.loaders import DATASET_INFO
    if ds not in DATASET_INFO:
        raise SystemExit(f"unknown dataset {ds!r}; known: {sorted(DATASET_INFO)}")
    return DATASET_INFO[ds]


def resolve_loader(args):
    """Return (load(ds, subj, root) -> (X, y, fs), info(ds) -> dict, config dict)."""
    kind = getattr(args, "loader", None) or "repo"
    tmin, tmax, units = (getattr(args, k, None) for k in ("tmin", "tmax", "units"))
    if kind == "moabb":
        try:
            import moabb  # noqa: F401
            from npn import moabb_loaders as M
        except ImportError as e:
            raise SystemExit(f"--loader moabb needs MOABB (pip install moabb): {e}")
        cfg = dict(loader="moabb",
                   tmin=M.DEFAULTS["tmin"] if tmin is None else float(tmin),
                   tmax=M.DEFAULTS["tmax"] if tmax is None else float(tmax),
                   fmin=M.DEFAULTS["fmin"], fmax=M.DEFAULTS["fmax"],
                   units=units or M.DEFAULTS["units"])

        def load(ds, subj, root):
            return M.load_subject(ds, subj, root, tmin=cfg["tmin"], tmax=cfg["tmax"],
                                  fmin=cfg["fmin"], fmax=cfg["fmax"], units=cfg["units"])

        def info(ds):
            try:
                return M.dataset_info(ds)
            except NotImplementedError as e:
                raise SystemExit(str(e))
        return load, info, cfg
    if kind != "repo":
        raise SystemExit(f"unknown loader {kind!r}; choose repo or moabb")
    if any(v is not None for v in (tmin, tmax, units)):
        print("note: --tmin, --tmax and --units apply only to --loader moabb and are ignored")

    def load(ds, subj, root):
        if root is None:
            raise SystemExit("--root is required with --loader repo")
        from npn.loaders import load_subject
        return load_subject(ds, subj, root)
    return load, repo_info, dict(loader="repo")


def load_subject_data(loader, ds, subj, root):
    try:
        X, y, fs = loader(ds, subj, root)
    except NotImplementedError as e:            # the public repository ships loader stubs
        raise SystemExit(f"loader not implemented: {e}")
    except FileNotFoundError as e:
        raise SystemExit(str(e))
    classes, y = np.unique(np.asarray(y), return_inverse=True)
    return np.asarray(X, dtype=np.float32), y.astype(np.int64), int(fs), len(classes)


# --------------------------------------------------------------------------- #
# run metadata: one loader configuration per results file
# --------------------------------------------------------------------------- #
def meta_path(out):
    return out + ".meta.json"


def _versions():
    v = {"python": platform.python_version(), "numpy": np.__version__, "torch": torch.__version__}
    for mod in ("mne", "sklearn", "scipy", "moabb"):
        try:
            v[mod] = __import__(mod).__version__
        except Exception:
            pass
    return v


def read_meta(out):
    path = meta_path(out)
    if not os.path.exists(path):
        return None
    with open(path) as f:
        return json.load(f)


def check_meta(out, cfg, write=True):
    """Refuse to mix results from different loader configurations in one CSV;
    on the first real run, store the configuration next to the CSV."""
    old = read_meta(out)
    if old is not None:
        if old.get("loader_config") != cfg:
            raise SystemExit(f"{out} holds results from loader config {old.get('loader_config')}, "
                             f"but this run uses {cfg}; choose another --out")
        return
    if not write:
        return
    os.makedirs(os.path.dirname(os.path.abspath(out)), exist_ok=True)
    meta = dict(loader_config=cfg, filter_bank=[list(b) for b in FILTER_BANK],
                created=time.strftime("%Y-%m-%d %H:%M:%S"), host=socket.gethostname(),
                versions=_versions())
    tmp = meta_path(out) + f".tmp{os.getpid()}"
    with open(tmp, "w") as f:
        json.dump(meta, f, indent=2)
    os.replace(tmp, meta_path(out))


# --------------------------------------------------------------------------- #
# run
# --------------------------------------------------------------------------- #
def cmd_run(args, loader=None, info_fn=None, cfg=None):
    P.quiet_mne()
    if loader is None:
        loader, info_fn, cfg = resolve_loader(args)
    cfg = cfg or {"loader": "injected"}
    jobs = resolve_jobs(args)
    seeds = parse_ints(args.seeds) or [42, 43, 44, 45, 46]
    datasets = [d.strip() for d in args.datasets.split(",") if d.strip()]
    fold_ids = parse_ints(getattr(args, "fold_ids", None))
    if fold_ids is not None and any(f < 0 or f >= args.folds for f in fold_ids):
        raise SystemExit(f"--fold-ids must lie in 0..{args.folds - 1}")
    folds = [f for f in range(args.folds) if fold_ids is None or f in fold_ids]
    out = args.out
    done = read_done(out)
    plan = []
    for seed in seeds:
        for ds in datasets:
            subjects = parse_ints(args.subjects) or list(info_fn(ds)["subjects"])
            for subj in subjects:
                for fold in folds:
                    for c, s, r in jobs:
                        if cell_key(ds, subj, c, s, r, seed, fold, args.frac) not in done:
                            plan.append((seed, ds, subj, fold, c, s, r))
    n_npn = sum(1 for p in plan if p[4] in P.NPN_CONDITIONS)
    print(f"jobs per fold: {len(jobs)} | pending trainings: {len(plan)} "
          f"(NPN {n_npn}, EEGNet {len(plan) - n_npn}) | output: {out}", flush=True)
    print(f"loader: {cfg}", flush=True)
    for c, s, r in jobs:
        print(f"  - {c}|{s}|{r}")
    check_meta(out, cfg, write=not args.dry_run and bool(plan))
    if args.dry_run or not plan:
        return 0

    dev = P.device()
    use_cuda = dev == "cuda"
    print(f"device: {dev}" + (f" ({torch.cuda.get_device_name(0)})" if use_cuda else ""), flush=True)
    failures, finished = 0, 0
    need_bands = any(c in P.NPN_CONDITIONS for c, _, _ in jobs)
    current = None
    for seed in seeds:
        for ds in datasets:
            subjects = parse_ints(args.subjects) or list(info_fn(ds)["subjects"])
            for subj in subjects:
                if not any(p[0] == seed and p[1] == ds and p[2] == subj for p in plan):
                    continue
                if current is None or current[0] != (ds, subj):
                    current = X = Xb = None          # release the previous subject's arrays
                    try:
                        X, y, fs, K = load_subject_data(loader, ds, subj, args.root)
                    except SystemExit:
                        raise                        # configuration errors stop the run
                    except Exception as e:           # e.g. a failed download: skip this subject
                        failures += 1
                        print(f"{ds} S{subj}: LOAD FAILED: {type(e).__name__}: {e}", flush=True)
                        continue
                    Xb = to_bands(X, fs) if need_bands else None
                    current = ((ds, subj), X, y, fs, K, Xb)
                    std = float(np.std(X))
                    print(f"{ds} S{subj}: X {X.shape}, fs {fs}, classes {K}, "
                          f"std {std:.3g} -> {unit_guess(std)}", flush=True)
                _, X, y, fs, K, Xb = current
                for split in P.fold_indices(y, args.folds, seed, args.frac):
                    fold = split[0]
                    if fold not in folds:
                        continue
                    for c, s, r in jobs:
                        key = cell_key(ds, subj, c, s, r, seed, fold, args.frac)
                        if key in done:
                            continue
                        tag = f"[seed {seed}] {ds} S{subj} fold {fold} {c}|{s}|{r}"
                        if use_cuda:
                            torch.cuda.reset_peak_memory_stats()
                        try:
                            res = P.run_cell(c, X, Xb if c in P.NPN_CONDITIONS else None, y, K, fs,
                                             split, s, r, seed, epochs=args.epochs, dev=dev)
                        except Exception as e:                     # keep going, report at the end
                            failures += 1
                            print(f"{tag} FAILED: {type(e).__name__}: {e}", flush=True)
                            if getattr(args, "verbose_errors", False):
                                traceback.print_exc()
                            continue
                        row = dict(dataset=ds, subject=subj, condition=c, input_scale=s,
                                   recipe=res["recipe"], seed=seed, fold=fold,
                                   frac=fmt_frac(args.frac), n_train=res["n_train"],
                                   n_test=res["n_test"], acc=f"{res['acc']:.6f}",
                                   kappa=f"{res['kappa']:.6f}", best_val=f"{res['best_val']:.6f}",
                                   epochs_run=res["epochs_run"],
                                   spatial_cos=f"{res['spatial_cos']:.12f}",
                                   spatial_norm_ratio=f"{res['spatial_norm_ratio']:.6g}",
                                   seconds=f"{res['seconds']:.1f}")
                        append_row(out, row)
                        done.add(key)
                        finished += 1
                        mem = (f" gpu {torch.cuda.max_memory_allocated() / 2 ** 20:.0f} MB"
                               if use_cuda else "")
                        print(f"{tag} acc={res['acc'] * 100:6.2f} kappa={res['kappa']:.3f} "
                              f"ep={res['epochs_run']} 1-cos={1.0 - res['spatial_cos']:.1e} "
                              f"{res['seconds']:.1f}s{mem}", flush=True)
    print(f"finished {finished} cells, {failures} failed", flush=True)
    return 1 if failures else 0


# --------------------------------------------------------------------------- #
# check-data
# --------------------------------------------------------------------------- #
def cmd_check_data(args, loader=None, info_fn=None, cfg=None):
    P.quiet_mne()
    if loader is None:
        loader, info_fn, cfg = resolve_loader(args)
    print(f"loader: {cfg or {'loader': 'injected'}}")
    problems = 0
    for ds in [d.strip() for d in args.datasets.split(",") if d.strip()]:
        info = info_fn(ds)
        shapes = set()
        for subj in parse_ints(args.subjects) or list(info["subjects"]):
            t0 = time.time()
            try:
                X, y, fs, K = load_subject_data(loader, ds, subj, args.root)
            except SystemExit:
                raise
            except Exception as e:
                problems += 1
                print(f"{ds} S{subj}: LOAD FAILED: {type(e).__name__}: {str(e)[:200]} "
                      f"(for --loader moabb this is usually a download problem)", flush=True)
                continue
            notes = []
            if not np.all(np.isfinite(X)):
                notes.append("non-finite values")
            if info.get("fs") is not None and fs != info["fs"]:
                notes.append(f"fs {fs} but expected {info['fs']}")
            if info.get("channels") is not None and X.shape[1] != info["channels"]:
                notes.append(f"{X.shape[1]} channels but expected {info['channels']}")
            if info.get("classes") is not None and K != info["classes"]:
                notes.append(f"{K} classes but expected {info['classes']}")
            if info.get("trials") is not None and len(y) != info["trials"]:
                notes.append(f"{len(y)} trials but expected {info['trials']}")
            problems += len(notes)
            shapes.add(tuple(X.shape[1:]))
            std = float(np.std(X))
            print(f"{ds} S{subj}: X {tuple(X.shape)}, fs {fs} Hz, trials per class "
                  f"{np.bincount(y).tolist()}, std {std:.3g} ({unit_guess(std)}), "
                  f"{time.time() - t0:.1f}s" + ("  !! " + "; ".join(notes) if notes else ""),
                  flush=True)
        if len(shapes) > 1:
            problems += 1
            print(f"  !! {ds}: trial shapes differ across subjects: {sorted(shapes)}")
    print("check-data finished: " + (f"{problems} problem(s)" if problems else "all subjects loaded"))
    return 1 if problems else 0


# --------------------------------------------------------------------------- #
# diagnose
# --------------------------------------------------------------------------- #
def cmd_diagnose(args, loader=None, info_fn=None, cfg=None):
    P.quiet_mne()
    if loader is None:
        loader, info_fn, cfg = resolve_loader(args)
    print(f"loader: {cfg or {'loader': 'injected'}}")
    flagged = False
    for ds in [d.strip() for d in args.datasets.split(",") if d.strip()]:
        subjects = parse_ints(args.subjects) or list(info_fn(ds)["subjects"])[:1]
        for subj in subjects:
            X, y, fs, K = load_subject_data(loader, ds, subj, args.root)
            Xb = to_bands(X, fs)
            _, tr, te, ti, vi = next(P.fold_indices(y, args.folds, 42))
            std = float(np.std(X))
            print(f"\n{ds} S{subj}: X {X.shape}, fs {fs} Hz, classes {K}, "
                  f"trials per class {np.bincount(y).tolist()}")
            print(f"  amplitude: std {std:.3g}, median |x| {float(np.median(np.abs(X))):.3g} "
                  f"-> looks like {unit_guess(std)}")
            d = P.scale_diagnostics(X, Xb, y, ti, fs)
            print(f"  variance entering NPN bn0: random init {d['random']:.3g}, "
                  f"per-band CSP init {d['csp_band']:.3g}  (BatchNorm eps = {P.BN_EPS:g})")
            print(f"  variance entering EEGNet's first BatchNorm: {d['eegnet_first_bn_input']:.3g}")
            print(f"  NPN spatial weight norm: Xavier {d['norm_random']:.3g}, per-band CSP "
                  f"{d['norm_csp_band']:.3g} (raw input), {d['norm_csp_band_global']:.3g} "
                  f"(global scaling)")
            if d["random"] < P.BN_EPS:
                flagged = True
                print("  !! SCALE CONFOUND: with raw input, random-init NPN starts below BatchNorm eps "
                      "while CSP init starts at unit variance. Raw-input random vs CSP comparisons "
                      "mix scale with direction; compare against npn_random_scaled or use "
                      "--input-scale global.")
            if d["norm_csp_band"] > 1e3:
                flagged = True
                print("  !! FROZEN IN PRACTICE: CSP weights this large barely move under Adam "
                      "(lr 1e-3) with raw input, so 'trainable' CSP init behaves like a frozen "
                      "layer; check the 1-cos column of npn_csp_band|raw.")
            if d["eegnet_first_bn_input"] < P.BN_EPS:
                flagged = True
                print("  !! EEGNet also starts below BatchNorm eps with raw input; use global or "
                      "trial_z input for EEGNet conditions.")
            fr = P.band_power_fractions(X, Xb)
            print("  power of each filter-bank band relative to the loader output:")
            for (lo, hi), f in zip(FILTER_BANK, fr):
                note = "  <- below 1%: band lies mostly outside the prefilter" if f < 0.01 else ""
                print(f"    {lo:>2}-{hi:<2} Hz  {f * 100:7.2f}%{note}")
    print("\ndiagnose finished" + (" with warnings" if flagged else ""))
    return 0


# --------------------------------------------------------------------------- #
# summarize
# --------------------------------------------------------------------------- #
def _load_results(patterns):
    import pandas as pd
    files = []
    for pat in patterns:
        files.extend(sorted(glob.glob(pat)))
    files = sorted(set(files))
    if not files:
        raise SystemExit(f"no result files match {patterns}")
    frames = [pd.read_csv(f, dtype={k: str for k in KEY}) for f in files]
    df = pd.concat(frames, ignore_index=True).drop_duplicates(subset=KEY, keep="first")
    df["acc"] = df["acc"].astype(float) * 100.0
    df["kappa"] = df["kappa"].astype(float)
    df["arm"] = df["condition"] + "|" + df["input_scale"] + "|" + df["recipe"]
    return df, files


def paired_subject_diffs(df, ds, arm_a, arm_b):
    """Per-subject mean difference (a - b) over the (seed, fold, frac) cells that
    both arms completed; subjects without common cells are dropped."""
    cols = ["subject", "seed", "fold", "frac"]
    a = df[(df.dataset == ds) & (df.arm == arm_a)][cols + ["acc"]]
    b = df[(df.dataset == ds) & (df.arm == arm_b)][cols + ["acc"]]
    m = a.merge(b, on=cols, suffixes=("_a", "_b"))
    if m.empty:
        return None
    g = m.groupby("subject")
    return dict(subjects=list(g.groups), a=g["acc_a"].mean().values, b=g["acc_b"].mean().values,
                cells=int(len(m)))


def cmd_summarize(args):
    from scipy.stats import wilcoxon
    from npn.stats import hierarchical_bootstrap, cohens_dz, wilcoxon_holm
    df, files = _load_results(args.inputs)
    print(f"read {len(df)} unique cells from {len(files)} file(s)")
    configs = {}
    for f in files:
        meta = read_meta(f)
        configs[f] = json.dumps(meta.get("loader_config") if meta else None, sort_keys=True)
    if len(set(configs.values())) > 1:
        print("!! the input files were produced with different loader configurations:")
        for f, c in configs.items():
            print(f"   {f}: {c}")
    elif configs:
        print(f"loader: {next(iter(configs.values()))}")
    lines = []
    print("\nPer-arm results (subject-level means over completed seed x fold cells)")
    print(f"{'dataset':<10} {'arm':<34} {'subj':>4} {'cells':>6} {'acc mean':>9} {'sd':>6} "
          f"{'kappa':>6} {'1-cos':>8}")
    for (ds, arm), g in df.groupby(["dataset", "arm"], sort=True):
        subj = g.groupby("subject")
        acc = subj["acc"].mean()
        kap = subj["kappa"].mean()
        fcos = g["spatial_cos"].astype(float).mean() if "spatial_cos" in g else float("nan")
        sd = acc.std(ddof=1) if len(acc) > 1 else float("nan")
        print(f"{ds:<10} {arm:<34} {len(acc):>4} {len(g):>6} {acc.mean():>9.2f} "
              f"{sd:>6.2f} {kap.mean():>6.3f} {1.0 - fcos:>8.1e}")
        lines.append(dict(kind="arm", dataset=ds, arm=arm, n_subjects=len(acc), cells=len(g),
                          mean=acc.mean(), sd=sd, kappa=kap.mean(), filter_cos=fcos))

    arms = set(df["arm"])
    if args.pairs:
        pairs = []
        for item in args.pairs.split(";"):
            a, b = [x.strip() for x in item.split(":")]
            pairs.append((a, b, f"{a} - {b}"[:38]))
    else:
        pairs = [p for p in DEFAULT_PAIRS if p[0] in arms and p[1] in arms]
    if not pairs:
        print("\nno comparable pairs in the results yet")
    else:
        print("\nPaired comparisons (A - B, percentage points; subjects as the unit)")
        print(f"{'dataset':<10} {'comparison':<38} {'n':>3} {'A':>7} {'B':>7} {'diff':>7} "
              f"{'sd':>6} {'dz':>6} {'p':>8} {'p_holm':>8}")
        by_pair_ds = {}
        for ds in sorted(df["dataset"].unique()):
            res = {}
            for a, b, label in pairs:
                r = paired_subject_diffs(df, ds, a, b)
                if r is not None and len(r["a"]) > 0:
                    res[(a, b, label)] = r
            holm = wilcoxon_holm({k: (v["a"], v["b"]) for k, v in res.items()})
            for (a, b, label), r in res.items():
                d = np.asarray(r["a"]) - np.asarray(r["b"])
                try:
                    p = (float(wilcoxon(r["a"], r["b"]).pvalue)
                         if len(d) >= 2 and np.any(d != 0) else float("nan"))
                except ValueError:
                    p = float("nan")
                ph = holm.get((a, b, label), float("nan"))
                sd = d.std(ddof=1) if len(d) > 1 else float("nan")
                print(f"{ds:<10} {label:<38} {len(d):>3} {np.mean(r['a']):>7.2f} "
                      f"{np.mean(r['b']):>7.2f} {d.mean():>+7.2f} {sd:>6.2f} "
                      f"{cohens_dz(d):>+6.2f} {p:>8.4f} {ph:>8.4f}")
                lines.append(dict(kind="pair", dataset=ds, arm=f"{a} - {b}", label=label,
                                  n_subjects=len(d), mean_a=np.mean(r["a"]), mean_b=np.mean(r["b"]),
                                  diff=d.mean(), sd=sd, dz=cohens_dz(d), p=p, p_holm=ph,
                                  cells=r["cells"]))
                by_pair_ds.setdefault((a, b, label), {})[ds] = d
        if df["dataset"].nunique() > 1:
            print("\nAcross datasets (hierarchical bootstrap: subjects resampled within datasets)")
            for (a, b, label), dd in by_pair_ds.items():
                m, lo, hi = hierarchical_bootstrap(dd, n=args.n_boot)
                print(f"  {label:<38} {m:+6.2f} pts, 95% CI [{lo:+.2f}, {hi:+.2f}] "
                      f"over {len(dd)} dataset(s)")
                lines.append(dict(kind="hier", dataset="ALL", arm=f"{a} - {b}", label=label,
                                  diff=m, ci_lo=lo, ci_hi=hi, n_datasets=len(dd)))
    if args.out_summary:
        import pandas as pd
        os.makedirs(os.path.dirname(os.path.abspath(args.out_summary)), exist_ok=True)
        pd.DataFrame(lines).to_csv(args.out_summary, index=False)
        print(f"\nsummary written to {args.out_summary}")
    return 0


# --------------------------------------------------------------------------- #
# smoke test
# --------------------------------------------------------------------------- #
def _synthetic_loader(ds, subj, root, n=64, C=8, T=256, fs=128):
    """Four-class toy data: class-specific 10 Hz power on one channel, 8-30 Hz,
    volt-scale amplitudes (so the scale diagnostics are exercised)."""
    from scipy.signal import butter, sosfiltfilt
    rng = np.random.default_rng(1000 + int(subj))
    y = np.arange(n) % 4
    X = rng.standard_normal((n, C, T))
    t = np.arange(T) / fs
    for i in range(n):
        X[i, y[i] % C] += 3.0 * np.sin(2 * np.pi * 10 * t + rng.uniform(0, 2 * np.pi)) * rng.uniform(0.6, 1.4)
    sos = butter(4, [8, 30], btype="bandpass", fs=fs, output="sos")
    return (sosfiltfilt(sos, X, axis=-1) * 1e-5).astype(np.float32), y, fs


def _smoke_moabb(tmp):
    """MOABB loader on MOABB's offline FakeDataset with the real 2a montage and
    window, then one NPN and one CSP-Net-2 cell on those shapes. Returns True,
    False, or None when MOABB is not installed."""
    try:
        import moabb  # noqa: F401
        from moabb.datasets.fake import FakeDataset
        from npn import moabb_loaders as M
    except ImportError:
        return None
    fake = FakeDataset(event_list=tuple(M.CLASS_ORDER["2a"]), n_sessions=2, n_runs=1, n_subjects=1,
                       paradigm="imagery", channels=tuple(M.CHANNELS["2a"]), sfreq=250,
                       duration=60, seed=0)

    def load(ds, subj, root):
        return M.load_subject("2a", 1, None, _dataset_obj=fake)

    X, y, fs = load("2a", 1, None)
    ok = (X.shape[1:] == (22, 876) and fs == 250 and X.dtype == np.float32
          and set(np.unique(y)) <= {0, 1, 2, 3})
    out = os.path.join(tmp, "smoke_moabb.csv")
    ns = argparse.Namespace(preset=None, conditions="npn_csp_band", input_scale="raw", recipe="npn",
                            seeds="42", datasets="2a", subjects="1", folds=2, frac=1.0, epochs=1,
                            root=None, out=out, dry_run=False, verbose_errors=True, fold_ids="0")
    info = lambda ds: {"subjects": [1]}                             # noqa: E731
    cfg = {"loader": "moabb-fake"}
    rc1 = cmd_run(ns, loader=load, info_fn=info, cfg=cfg)
    ns.conditions, ns.input_scale = "cspnet2_upd", "global"
    rc2 = cmd_run(ns, loader=load, info_fn=info, cfg=cfg)
    with open(out) as f:
        rows = sum(1 for _ in f) - 1
    return bool(ok and rc1 == 0 and rc2 == 0 and rows == 2)


def cmd_smoke(args):
    t0 = time.time()
    tmp = tempfile.mkdtemp(prefix="npn_prior_smoke_")
    out = os.path.join(tmp, "smoke.csv")
    info_fn = lambda ds: {"subjects": [1, 2]}                       # noqa: E731
    cfg = {"loader": "synthetic"}
    ns = argparse.Namespace(preset="all_paths", conditions=None, input_scale=None, recipe=None,
                            seeds="42", datasets="synthetic", subjects="1,2", folds=2, frac=1.0,
                            epochs=2, root=None, out=out, dry_run=False, verbose_errors=True,
                            fold_ids=None)
    rc = cmd_run(ns, loader=_synthetic_loader, info_fn=info_fn, cfg=cfg)
    expected = len(resolve_jobs(ns)) * 2 * 2
    with open(out) as f:
        n_rows = sum(1 for _ in f) - 1
    ok_rows = rc == 0 and n_rows == expected
    rc2 = cmd_run(ns, loader=_synthetic_loader, info_fn=info_fn, cfg=cfg)   # must skip everything
    with open(out) as f:
        n_rows2 = sum(1 for _ in f) - 1
    ok_resume = rc2 == 0 and n_rows2 == n_rows
    cmd_summarize(argparse.Namespace(inputs=[out], pairs=None, n_boot=500,
                                     out_summary=os.path.join(tmp, "summary.csv")))
    cmd_check_data(argparse.Namespace(datasets="synthetic", subjects="1,2", root=None),
                   loader=_synthetic_loader, info_fn=info_fn, cfg=cfg)
    cmd_diagnose(argparse.Namespace(datasets="synthetic", subjects="1", root=None, folds=2),
                 loader=_synthetic_loader, info_fn=info_fn, cfg=cfg)
    ok_moabb = _smoke_moabb(tmp)
    moabb_msg = {None: "MOABB not installed (needed only for --loader moabb)",
                 True: "MOABB loader path OK", False: "MOABB loader path FAILED"}[ok_moabb]
    status = "PASSED" if (ok_rows and ok_resume and ok_moabb is not False) else "FAILED"
    print(f"\nSMOKE TEST {status}: {n_rows}/{expected} cells written, resume wrote "
          f"{n_rows2 - n_rows} extra rows, {moabb_msg}, device {P.device()}, "
          f"{time.time() - t0:.0f} s, files in {tmp}")
    return 0 if status == "PASSED" else 1


# --------------------------------------------------------------------------- #
def _add_loader_args(p):
    p.add_argument("--loader", default="repo", choices=["repo", "moabb"],
                   help="repo: npn/loaders.py; moabb: npn/moabb_loaders.py (2a, 2b)")
    p.add_argument("--root", default=None,
                   help="data folder (repo loader) or MOABB download folder; must exist")
    p.add_argument("--tmin", type=float, default=None, help="moabb: window start after cue (0.5)")
    p.add_argument("--tmax", type=float, default=None, help="moabb: window end after cue (4.0)")
    p.add_argument("--units", default=None, choices=["V", "uV"], help="moabb: output units (V)")


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)

    sub.add_parser("smoke", help="end-to-end check on synthetic data")

    c = sub.add_parser("check-data", help="load every subject once and report shapes and units")
    _add_loader_args(c)
    c.add_argument("--datasets", default="2a")
    c.add_argument("--subjects", default="all")

    d = sub.add_parser("diagnose", help="units, first-BatchNorm scale, weight norms, band powers")
    _add_loader_args(d)
    d.add_argument("--datasets", default="2a")
    d.add_argument("--subjects", default="1")
    d.add_argument("--folds", type=int, default=5)

    r = sub.add_parser("run", help="train and test conditions (crash-safe, resumable)")
    _add_loader_args(r)
    r.add_argument("--preset", default=None, help="expA, expB, sanity, tonight (comma list allowed)")
    r.add_argument("--conditions", default=None, help=f"comma list from {list(P.CONDITIONS)}")
    r.add_argument("--input-scale", dest="input_scale", default=None, choices=P.INPUT_SCALES)
    r.add_argument("--recipe", default=None, choices=P.RECIPES, help="EEGNet conditions only")
    r.add_argument("--datasets", default="2a")
    r.add_argument("--subjects", default="all", help="'all', '1-9', or '1,4,7'")
    r.add_argument("--seeds", default="42-46", help="default 42-46 as in the paper")
    r.add_argument("--folds", type=int, default=5)
    r.add_argument("--fold-ids", dest="fold_ids", default=None,
                   help="run only these fold indices, e.g. 0 for a timing probe")
    r.add_argument("--frac", type=float, default=1.0, help="training fraction (1.0 = full)")
    r.add_argument("--epochs", type=int, default=None,
                   help="override epochs (default: NPN 500, EEGNet npn 500, EEGNet cspnet 200)")
    r.add_argument("--out", default=DEFAULT_OUT)
    r.add_argument("--dry-run", dest="dry_run", action="store_true")
    r.add_argument("--verbose-errors", dest="verbose_errors", action="store_true")

    s = sub.add_parser("summarize", help="per-arm means and paired comparisons")
    s.add_argument("--inputs", nargs="+", default=[DEFAULT_OUT], help="CSV files or glob patterns")
    s.add_argument("--pairs", default=None, help="'armA:armB;armC:armD' with arm = condition|scale|recipe")
    s.add_argument("--n-boot", dest="n_boot", type=int, default=5000)
    s.add_argument("--out-summary", dest="out_summary", default=None)

    args = ap.parse_args(argv)
    if args.cmd == "smoke":
        return cmd_smoke(args)
    if args.cmd == "check-data":
        return cmd_check_data(args)
    if args.cmd == "diagnose":
        return cmd_diagnose(args)
    if args.cmd == "run":
        return cmd_run(args)
    return cmd_summarize(args)


if __name__ == "__main__":
    sys.exit(main())
