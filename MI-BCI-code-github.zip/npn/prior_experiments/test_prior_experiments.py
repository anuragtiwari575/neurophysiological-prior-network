"""Tests for npn.prior_experiments and scripts/run_prior_experiments.py."""
import argparse
import importlib.util
import os

import numpy as np
import pytest

torch = pytest.importorskip("torch")
pytest.importorskip("mne")

from npn import prior_experiments as P          # noqa: E402
from npn.csp import band_csp_filters             # noqa: E402
from npn.data import to_bands                    # noqa: E402
from npn.model import NPN                        # noqa: E402
from npn.train import train_one, cross_validate  # noqa: E402

P.quiet_mne()
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def synth(n=48, C=6, T=192, fs=128, scale=1e-5, seed=0, K=4):
    from scipy.signal import butter, sosfiltfilt
    rng = np.random.default_rng(seed)
    y = np.arange(n) % K
    X = rng.standard_normal((n, C, T))
    t = np.arange(T) / fs
    for i in range(n):
        X[i, y[i] % C] += 3.0 * np.sin(2 * np.pi * 10 * t) * rng.uniform(0.5, 1.5)
    sos = butter(4, [8, 30], btype="bandpass", fs=fs, output="sos")
    return (sosfiltfilt(sos, X, axis=-1) * scale).astype(np.float32), y


@pytest.fixture(scope="module")
def data():
    X, y = synth()
    return X, to_bands(X, 128), y


@pytest.mark.parametrize("mine,theirs", [(("csp_band", False), "csp"),
                                         (("random", False), "random"),
                                         (("csp_band", True), "frozen")])
def test_train_npn_reproduces_train_one(data, mine, theirs):
    X, Xb, y = data
    tr, va = np.arange(40), np.arange(40, 48)
    m1, b1, _ = P.train_npn(Xb[tr], y[tr], Xb[va], y[va], 4, init=mine[0], freeze=mine[1],
                            epochs=2, seed=7, dev="cpu")
    m2, b2 = train_one(Xb[tr], y[tr], Xb[va], y[va], 4, init=theirs, epochs=2, seed=7)
    s1, s2 = m1.state_dict(), m2.state_dict()
    assert b1 == b2 and set(s1) == set(s2)
    assert all(torch.equal(s1[k].cpu(), s2[k].cpu()) for k in s2)


def test_run_cell_reproduces_cross_validate(data):
    X, Xb, y = data
    ref = cross_validate(Xb, y, 4, init="csp", n_folds=2, epochs=2, seed=5)
    mine = [P.run_cell("npn_csp_band", X, Xb, y, 4, 128, split, "raw", "npn", seed=5,
                       epochs=2, dev="cpu")["acc"]
            for split in P.fold_indices(y, 2, 5)]
    assert np.allclose(ref, mine)


def test_random_scaled_matches_csp_output_variance(data):
    X, Xb, y = data
    torch.manual_seed(0)
    m = NPN(4, 6, Xb.shape[1], k_spatial=4)
    P.npn_spatial_init(m, "random_scaled", Xb, y, None, 4)
    target = band_csp_filters(Xb, y, 4)
    for b in range(Xb.shape[1]):
        W = m.spatials[b].weight.detach().numpy().reshape(4, 6)
        np.testing.assert_allclose(P.filter_output_variance(W, Xb[:, b]),
                                   P.filter_output_variance(np.asarray(target[b])[:4], Xb[:, b]),
                                   rtol=1e-4)


def test_random_scaled_keeps_random_directions(data):
    X, Xb, y = data
    torch.manual_seed(0)
    a = NPN(4, 6, Xb.shape[1], k_spatial=4)
    P.npn_spatial_init(a, "random", Xb, y, None, 4)
    torch.manual_seed(0)
    b = NPN(4, 6, Xb.shape[1], k_spatial=4)
    P.npn_spatial_init(b, "random_scaled", Xb, y, None, 4)
    for sa, sb in zip(a.spatials, b.spatials):
        wa = sa.weight.detach().numpy().reshape(4, 6)
        wb = sb.weight.detach().numpy().reshape(4, 6)
        cos = np.sum(wa * wb, 1) / (np.linalg.norm(wa, axis=1) * np.linalg.norm(wb, axis=1))
        np.testing.assert_allclose(cos, 1.0, atol=1e-5)


def test_broadband_filters_copied_to_every_band(data):
    X, Xb, y = data
    m = NPN(4, 6, Xb.shape[1], k_spatial=4)
    P.npn_spatial_init(m, "csp_broadband", Xb, y, X, 4)
    f = np.asarray(band_csp_filters(X[:, None], y, 4)[0])[:4]
    for conv in m.spatials:
        np.testing.assert_allclose(conv.weight.detach().numpy().reshape(4, 6), f, rtol=1e-5, atol=1e-7)


def test_cspnet2_init_fix_and_update(data):
    X, _, y = data
    Xg = X / X.std()
    tr, va = np.arange(40), np.arange(40, 48)
    F = P.cspnet_filters(Xg[tr], y[tr])
    W_expected = np.tile(F, (2, 1))[:8]
    m = P.EEGNetCSPNet(6, 192, 4, 128)
    P.init_cspnet2(m, F)
    np.testing.assert_allclose(m.spatial.weight.detach().numpy().reshape(8, 6), W_expected)

    def cos_to_csp(model):
        W = model.spatial.weight.detach().numpy().reshape(8, 6)
        return np.sum(W * W_expected, 1) / (np.linalg.norm(W, axis=1) * np.linalg.norm(W_expected, axis=1))

    f1, _, _ = P.train_eegnet(Xg[tr], y[tr], Xg[va], y[va], 4, 128, "csp_fix", "npn", seed=3, epochs=1, dev="cpu")
    f3, _, _ = P.train_eegnet(Xg[tr], y[tr], Xg[va], y[va], 4, 128, "csp_fix", "npn", seed=3, epochs=3, dev="cpu")
    assert not f3.spatial.weight.requires_grad
    np.testing.assert_allclose(cos_to_csp(f3), 1.0, atol=1e-6)
    assert torch.equal(f1.spatial.weight, f3.spatial.weight)            # frozen after max-norm
    assert np.all(np.linalg.norm(f3.spatial.weight.detach().numpy().reshape(8, 6), axis=1) <= 1.0 + 1e-6)
    u3, _, _ = P.train_eegnet(Xg[tr], y[tr], Xg[va], y[va], 4, 128, "csp_upd", "npn", seed=3, epochs=3, dev="cpu")
    assert u3.spatial.weight.requires_grad
    assert not torch.allclose(u3.spatial.weight, f3.spatial.weight)


def test_cspnet_filters_with_few_channels():
    X, y = synth(C=3)
    F = P.cspnet_filters(X / X.std(), y)
    assert F.shape == (3, 3)
    m = P.EEGNetCSPNet(3, 192, 4, 128)
    P.init_cspnet2(m, F)
    np.testing.assert_allclose(m.spatial.weight.detach().numpy().reshape(8, 3), np.tile(F, (3, 1))[:8])


@pytest.mark.parametrize("C,fs,T", [(3, 250, 1000), (17, 160, 640), (22, 250, 875)])
def test_eegnet_shapes(C, fs, T):
    m = P.EEGNetCSPNet(C, T, 4, fs)
    assert m(torch.randn(3, C, T)).shape == (3, 4)
    assert m(torch.randn(3, 1, C, T)).shape == (3, 4)


def test_cspnet_recipe_trains_on_whole_fold(data):
    X, _, y = data
    split = next(P.fold_indices(y, 2, 1))
    res = P.run_cell("eegnet_random", X, None, y, 4, 128, split, "global", "cspnet", seed=1,
                     epochs=1, dev="cpu")
    assert res["n_train"] == len(split[1]) and np.isnan(res["best_val"]) and res["recipe"] == "cspnet"
    res = P.run_cell("eegnet_random", X, None, y, 4, 128, split, "global", "npn", seed=1,
                     epochs=1, dev="cpu")
    assert res["n_train"] == len(split[3])


def test_global_scale_uses_training_fold_only(data):
    X, _, y = data
    _, tr, te, _, _ = next(P.fold_indices(y, 2, 0))
    s1 = P.fold_scale(X, tr, "global")
    X2 = X.copy()
    X2[te] *= 1000.0
    assert P.fold_scale(X2, tr, "global") == s1
    assert P.fold_scale(X, tr, "raw") is None and P.fold_scale(X, tr, "trial_z") is None


def test_trial_z_statistics(data):
    X, Xb, _ = data
    Z = P.apply_scale(X, "trial_z", None)
    np.testing.assert_allclose(Z.mean(-1), 0.0, atol=1e-4)
    np.testing.assert_allclose(Z.std(-1), 1.0, atol=1e-3)
    assert P.apply_scale(Xb, "trial_z", None).shape == Xb.shape


def test_fold_indices_partition(data):
    _, _, y = data
    for k, tr, te, ti, vi in P.fold_indices(y, 3, 11):
        assert set(tr).isdisjoint(te) and set(ti) | set(vi) == set(tr) and set(ti).isdisjoint(vi)


def test_scale_diagnostics_detects_volt_input(data):
    X, Xb, y = data
    _, tr, _, ti, _ = next(P.fold_indices(y, 2, 0))
    d = P.scale_diagnostics(X, Xb, y, ti, fs=128)
    assert d["random"] < P.BN_EPS < d["csp_band"]
    assert d["norm_csp_band"] > 1e3 * d["norm_random"]          # volt-scale CSP weights are huge
    assert d["norm_csp_band_global"] < 1e-2 * d["norm_csp_band"]
    Xu = X * 1e6
    d2 = P.scale_diagnostics(Xu, to_bands(Xu, 128), y, ti, fs=128)
    assert d2["random"] > P.BN_EPS


def _load_driver():
    spec = importlib.util.spec_from_file_location(
        "run_prior_experiments", os.path.join(ROOT, "scripts", "run_prior_experiments.py"))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def test_driver_run_resume_and_summarize(tmp_path):
    R = _load_driver()
    out = str(tmp_path / "res.csv")
    ns = argparse.Namespace(preset=None, conditions="npn_csp_band,npn_random", input_scale="global",
                            recipe="npn", seeds="42", datasets="synthetic", subjects="1,2", folds=2,
                            frac=1.0, epochs=1, root="", out=out, dry_run=False, verbose_errors=True)
    info = lambda ds: {"subjects": [1, 2]}                                   # noqa: E731
    assert R.cmd_run(ns, loader=R._synthetic_loader, info_fn=info) == 0
    rows = open(out).read().splitlines()
    assert len(rows) == 1 + 2 * 2 * 2
    assert R.cmd_run(ns, loader=R._synthetic_loader, info_fn=info) == 0
    assert open(out).read().splitlines() == rows                            # nothing re-run
    summ = str(tmp_path / "summary.csv")
    R.cmd_summarize(argparse.Namespace(inputs=[out], pairs=None, n_boot=200, out_summary=summ))
    import pandas as pd
    s = pd.read_csv(summ)
    assert "pair" in set(s["kind"]) and "arm" in set(s["kind"])


def test_parse_ints_and_jobs():
    R = _load_driver()
    assert R.parse_ints("1-3,7") == [1, 2, 3, 7] and R.parse_ints("all") is None
    jobs = R.resolve_jobs(argparse.Namespace(preset="tonight", conditions=None, input_scale=None, recipe=None))
    assert len(jobs) == len(set(jobs)) == 12
    assert all(r == "npn" for c, s, r in jobs if c.startswith("npn_"))


def test_spatial_drift_reports_frozen_and_moving_layers(data):
    X, Xb, y = data
    split = next(P.fold_indices(y, 2, 2))
    frozen = P.run_cell("npn_csp_band_frozen", X, Xb, y, 4, 128, split, "global", "npn", seed=2,
                        epochs=2, dev="cpu")
    assert frozen["spatial_cos"] == pytest.approx(1.0, abs=1e-9)
    assert frozen["spatial_norm_ratio"] == pytest.approx(1.0, abs=1e-9)
    moving = P.run_cell("npn_random", X, Xb, y, 4, 128, split, "global", "npn", seed=2,
                        epochs=2, dev="cpu")
    assert moving["spatial_cos"] < 1.0 - 1e-6
    W = np.random.default_rng(0).standard_normal((4, 6))
    assert P.spatial_drift(W, 3.0 * W) == pytest.approx((1.0, 3.0))


def _ns(out, **kw):
    base = dict(preset=None, conditions="npn_csp_band", input_scale="global", recipe="npn",
                seeds="42", datasets="synthetic", subjects="1", folds=2, frac=1.0, epochs=1,
                root=None, out=out, dry_run=False, verbose_errors=True, fold_ids=None)
    base.update(kw)
    return argparse.Namespace(**base)


def test_meta_guard_blocks_mixed_loader_configs(tmp_path):
    R = _load_driver()
    out = str(tmp_path / "res.csv")
    info = lambda ds: {"subjects": [1]}                                     # noqa: E731
    assert R.cmd_run(_ns(out), loader=R._synthetic_loader, info_fn=info, cfg={"loader": "a"}) == 0
    assert os.path.exists(out + ".meta.json")
    with pytest.raises(SystemExit):
        R.cmd_run(_ns(out, seeds="43"), loader=R._synthetic_loader, info_fn=info, cfg={"loader": "b"})
    with pytest.raises(SystemExit):                                          # dry runs are checked too
        R.cmd_run(_ns(out, seeds="43", dry_run=True), loader=R._synthetic_loader, info_fn=info,
                  cfg={"loader": "b"})


def test_fold_ids_restrict_the_run(tmp_path):
    R = _load_driver()
    out = str(tmp_path / "res.csv")
    info = lambda ds: {"subjects": [1]}                                     # noqa: E731
    assert R.cmd_run(_ns(out, folds=3, fold_ids="1"), loader=R._synthetic_loader, info_fn=info) == 0
    import pandas as pd
    assert pd.read_csv(out)["fold"].tolist() == [1]
    with pytest.raises(SystemExit):
        R.cmd_run(_ns(out, folds=3, fold_ids="3"), loader=R._synthetic_loader, info_fn=info)


def test_check_data_reports_and_flags(tmp_path, capsys):
    R = _load_driver()
    ok = R.cmd_check_data(argparse.Namespace(datasets="synthetic", subjects="1,2", root=None),
                          loader=R._synthetic_loader, info_fn=lambda ds: {"subjects": [1, 2]})
    assert ok == 0 and "all subjects loaded" in capsys.readouterr().out
    bad = R.cmd_check_data(argparse.Namespace(datasets="synthetic", subjects="1", root=None),
                           loader=R._synthetic_loader,
                           info_fn=lambda ds: {"subjects": [1], "fs": 250, "trials": 576})
    assert bad == 1


def test_moabb_loader_on_fake_dataset():
    pytest.importorskip("moabb")
    from moabb.datasets.fake import FakeDataset
    from npn import moabb_loaders as M
    fake = FakeDataset(event_list=tuple(M.CLASS_ORDER["2a"]), n_sessions=2, n_runs=1, n_subjects=1,
                       paradigm="imagery", channels=tuple(M.CHANNELS["2a"]), sfreq=250,
                       duration=60, seed=0)
    X, y, fs = M.load_subject("2a", 1, None, _dataset_obj=fake)
    assert X.shape[1:] == (22, 876) and X.dtype == np.float32 and fs == 250
    assert y.dtype == np.int64 and set(np.unique(y)) == {0, 1, 2, 3}
    Xu, yu, _ = M.load_subject("2a", 1, None, units="uV", _dataset_obj=fake)
    np.testing.assert_allclose(Xu, X * 1e6, rtol=1e-5)
    assert np.array_equal(y, yu)
    fake_b = FakeDataset(event_list=tuple(M.CLASS_ORDER["2b"]), n_sessions=5, n_runs=1,
                         n_subjects=1, paradigm="imagery", channels=("C3", "Cz", "C4"),
                         sfreq=250, duration=30, seed=0)
    Xb_, yb_, _ = M.load_subject("2b", 1, None, _dataset_obj=fake_b)
    assert Xb_.shape[1] == 3 and set(np.unique(yb_)) == {0, 1}
    with pytest.raises(FileNotFoundError):
        M.set_data_root("/definitely/not/mounted/HDD9")
    with pytest.raises(NotImplementedError):
        M.load_subject("PhysioNet", 1)
    assert M.dataset_info("2a")["trials"] == 576


def test_run_skips_a_subject_that_fails_to_load(tmp_path):
    R = _load_driver()
    out = str(tmp_path / "res.csv")

    def flaky(ds, subj, root):
        if int(subj) == 2:
            raise RuntimeError("simulated download failure")
        return R._synthetic_loader(ds, subj, root)

    rc = R.cmd_run(_ns(out, subjects="1,2"), loader=flaky, info_fn=lambda ds: {"subjects": [1, 2]})
    import pandas as pd
    assert rc == 1 and set(pd.read_csv(out)["subject"]) == {1}
