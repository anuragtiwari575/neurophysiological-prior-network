"""
MOABB-based loaders for BCI Competition IV 2a and 2b.

Use these when `npn/loaders.py` has not been filled in (the public repository
ships stubs). Preprocessing follows the manuscript's stated protocol:

- zero-phase Butterworth band-pass, 8-30 Hz: MOABB applies MNE's IIR filter
  (4th-order Butterworth, forward and backward) to the continuous recording
  before epoching;
- all sessions of a subject pooled (2a: 2 x 288 = 576 trials), classes in a
  fixed order so that label 0 is always left hand;
- imagery window 0.5-4.0 s after the cue by default (the window drawn in
  Figure 1; the manuscript text does not state it), inclusive of both ends,
  so 876 samples at 250 Hz;
- amplitudes in volts, the MNE convention (MOABB's own array output from
  `paradigm.get_data()` is multiplied by 1e6, i.e. microvolts); pass
  `units="uV"` to match a pipeline that used microvolts;
- 2a channels in the order of `CHANNEL_SETS_2A[22]`; 2b channels C3, Cz, C4.

The first call downloads the subject's files. Pass `root` to choose the
download directory; it must already exist (a missing external-drive mount
must fail loudly instead of filling the system disk).

PhysioNet and High-Gamma are not provided here because the manuscript does not
list its 17-channel montage; use your own `npn/loaders.py` for them.
"""
from __future__ import annotations

import os

import numpy as np

from .loaders import CHANNEL_SETS_2A

DEFAULTS = dict(tmin=0.5, tmax=4.0, fmin=8.0, fmax=30.0, units="V")
CLASS_ORDER = {
    "2a": ["left_hand", "right_hand", "feet", "tongue"],
    "2b": ["left_hand", "right_hand"],
}
CHANNELS = {"2a": list(CHANNEL_SETS_2A[22]), "2b": ["C3", "Cz", "C4"]}
EXPECTED_TRIALS = {"2a": 576, "2b": None}          # 2b trial counts vary by subject
SUBJECTS = {"2a": list(range(1, 10)), "2b": list(range(1, 10))}
FS = {"2a": 250, "2b": 250}


def supported(dataset):
    return dataset in CLASS_ORDER


def dataset_info(dataset):
    if not supported(dataset):
        raise NotImplementedError(
            f"the MOABB loader covers {sorted(CLASS_ORDER)}; use --loader repo for {dataset!r}")
    return {"subjects": SUBJECTS[dataset], "classes": len(CLASS_ORDER[dataset]),
            "channels": len(CHANNELS[dataset]), "fs": FS[dataset],
            "trials": EXPECTED_TRIALS[dataset]}


def set_data_root(root):
    """Direct MOABB/MNE downloads to `root` for this process only."""
    if root is None:
        return None
    root = os.path.abspath(os.path.expanduser(str(root)))
    if not os.path.isdir(root):
        raise FileNotFoundError(
            f"data root {root} does not exist; mount the drive or create the folder first")
    os.environ["MNE_DATASETS_BNCI_PATH"] = root
    os.environ["MNE_DATA"] = root
    return root


def _moabb_dataset(dataset):
    from moabb.datasets import BNCI2014_001, BNCI2014_004
    return {"2a": BNCI2014_001, "2b": BNCI2014_004}[dataset]()


def load_subject(dataset, subject, root=None, tmin=DEFAULTS["tmin"], tmax=DEFAULTS["tmax"],
                 fmin=DEFAULTS["fmin"], fmax=DEFAULTS["fmax"], units=DEFAULTS["units"],
                 _dataset_obj=None):
    """Return (X, y, fs): X float32 (n_trials, n_channels, n_samples), y int64
    in the fixed class order, fs in Hz. `_dataset_obj` is for tests."""
    if not supported(dataset):
        raise NotImplementedError(
            f"the MOABB loader covers {sorted(CLASS_ORDER)}; use --loader repo for {dataset!r}")
    if units not in ("V", "uV"):
        raise ValueError("units must be 'V' or 'uV'")
    import mne
    from moabb.paradigms import MotorImagery
    mne.set_log_level("ERROR")
    set_data_root(root)
    classes = CLASS_ORDER[dataset]
    chans = CHANNELS[dataset]
    paradigm = MotorImagery(n_classes=len(classes), events=list(classes), fmin=fmin, fmax=fmax,
                            tmin=tmin, tmax=tmax, channels=list(chans), resample=None)
    ds = _dataset_obj if _dataset_obj is not None else _moabb_dataset(dataset)
    epochs, labels, meta = paradigm.get_data(dataset=ds, subjects=[int(subject)], return_epochs=True)
    if list(epochs.ch_names) != list(chans):
        raise RuntimeError(f"channel order mismatch: got {epochs.ch_names}, expected {chans}")
    labels = np.asarray(labels).astype(str)
    unknown = sorted(set(labels) - set(classes))
    if unknown:
        raise RuntimeError(f"unexpected labels {unknown}")
    y = np.array([classes.index(lab) for lab in labels], dtype=np.int64)
    try:
        X = epochs.get_data(copy=True)
    except TypeError:                          # MNE < 1.6 has no copy argument
        X = epochs.get_data()
    X = np.asarray(X, dtype=np.float64)
    if units == "uV":
        X = X * 1e6
    fs = int(round(float(epochs.info["sfreq"])))
    return X.astype(np.float32), y, fs


def describe(dataset, X, y, fs):
    """One-line summary used by the driver's check-data command."""
    exp = EXPECTED_TRIALS.get(dataset)
    note = "" if exp is None or len(y) == exp else f"  !! expected {exp} trials"
    return (f"X {tuple(X.shape)}, fs {fs} Hz, trials per class {np.bincount(y).tolist()}, "
            f"std {float(np.std(X)):.3g}{note}")
