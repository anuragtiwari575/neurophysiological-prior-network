"""
Controlled prior experiments for the NPN revision.

Exp A (inside NPN, protocol identical to npn.train.train_one):
    npn_random                random (Xavier) spatial init, as in the paper
    npn_random_scaled         random directions, but each filter's output
                              variance on the training data is matched to the
                              corresponding per-band CSP filter; separates the
                              effect of filter direction from filter scale
    npn_csp_broadband         one broadband (loader output, 8-30 Hz) CSP filter
                              set copied into every band; the CSP-Net style
                              prior placed inside NPN
    npn_csp_band              per-band CSP, i.e. the paper's NPN
    npn_csp_band_frozen       per-band CSP, spatial layer frozen
    npn_csp_broadband_frozen  broadband CSP, spatial layer frozen

Exp B (CSP-Net-2 of Jiang et al., Knowledge-Based Systems 305 (2024) 112668,
re-implemented from the paper and the settings in the first author's public
repository; this is not the authors' code):
    eegnet_random             EEGNet (F1=4, D=2, F2=8, temporal kernel fs/2)
    cspnet2_fix               depthwise spatial conv initialized with CSP, frozen
    cspnet2_upd               depthwise spatial conv initialized with CSP, trained

Every condition uses the same folds (StratifiedKFold with the run seed), the
same stratified 15% validation split, and the same input scaling, so a paired
difference between two conditions is attributable to the manipulated factor.

Input scaling (applied identically to every condition in a run):
    raw       loader output unchanged (the paper's NPN convention)
    global    division by one scalar, the standard deviation of the training
              fold; preserves the spatial covariance structure that CSP uses
    trial_z   per-trial, per-channel z-score over time (the paper's
              deep-baseline convention)
"""
from __future__ import annotations

import math
import time

import numpy as np
import torch
import torch.nn as nn

from .model import NPN
from .csp import band_csp_filters
from .data import augment_segrecomb

NPN_CONDITIONS = (
    "npn_random", "npn_random_scaled", "npn_csp_band", "npn_csp_broadband",
    "npn_csp_band_frozen", "npn_csp_broadband_frozen",
)
EEGNET_CONDITIONS = ("eegnet_random", "cspnet2_fix", "cspnet2_upd")
CONDITIONS = NPN_CONDITIONS + EEGNET_CONDITIONS
INPUT_SCALES = ("raw", "global", "trial_z")
RECIPES = ("npn", "cspnet")
BN_EPS = 1e-5

_NPN_INIT = {
    "npn_random": ("random", False),
    "npn_random_scaled": ("random_scaled", False),
    "npn_csp_band": ("csp_band", False),
    "npn_csp_broadband": ("csp_broadband", False),
    "npn_csp_band_frozen": ("csp_band", True),
    "npn_csp_broadband_frozen": ("csp_broadband", True),
}
_EEGNET_INIT = {
    "eegnet_random": "random",
    "cspnet2_fix": "csp_fix",
    "cspnet2_upd": "csp_upd",
}


# --------------------------------------------------------------------------- #
# utilities
# --------------------------------------------------------------------------- #
def quiet_mne():
    """Silence MNE's per-fit logging (one CSP fit per band per fold)."""
    try:
        import mne
        mne.set_log_level("ERROR")
    except Exception:
        pass


def device():
    return "cuda" if torch.cuda.is_available() else "cpu"


def seed_everything(seed):
    """Same seeding as npn.train.train_one."""
    torch.manual_seed(seed)
    np.random.seed(seed)
    try:
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    except Exception:
        pass


def zscore_trials(X):
    """Per-trial z-score over the last (time) axis; works for (n,C,T) and (n,B,C,T).
    No additive epsilon: at volt scale (std near 1e-6) a fixed 1e-7 would shrink
    the variance by several percent. Flat channels are left at zero."""
    Xd = np.asarray(X, dtype=np.float64)
    m = Xd.mean(axis=-1, keepdims=True)
    s = Xd.std(axis=-1, keepdims=True)
    s = np.where(s > 0, s, 1.0)
    return ((Xd - m) / s).astype(np.float32)


def fold_scale(Xraw, tr_idx, mode):
    """Scalar used by the 'global' mode, computed on training-fold trials only."""
    if mode != "global":
        return None
    s = float(np.std(Xraw[tr_idx], dtype=np.float64))
    if not np.isfinite(s) or s <= 0.0:
        raise ValueError("training-fold standard deviation is zero or not finite")
    return s


def apply_scale(X, mode, s):
    """Scale a subset (raw or band tensor) according to the run's input mode."""
    if mode == "raw":
        return X.astype(np.float32, copy=False)
    if mode == "global":
        return (X / s).astype(np.float32)
    if mode == "trial_z":
        return zscore_trials(X)
    raise ValueError(f"unknown input scale {mode!r}")


def fold_indices(y, n_folds, seed, frac=1.0):
    """The splits of npn.train.cross_validate, exposed as absolute indices.

    Yields (fold, tr, te, ti, vi): tr/te are the stratified k-fold partition
    (shuffle, random_state=seed); tr is optionally reduced to a stratified
    training fraction; ti/vi split tr into 85% training and a stratified 15%
    validation set used for early stopping (random_state=seed).
    """
    from sklearn.model_selection import StratifiedKFold, train_test_split
    skf = StratifiedKFold(n_folds, shuffle=True, random_state=seed)
    for k, (tr, te) in enumerate(skf.split(np.zeros(len(y)), y)):
        if frac < 1.0:
            keep, _ = train_test_split(np.arange(len(tr)), train_size=frac,
                                       stratify=y[tr], random_state=seed)
            tr = tr[keep]
        ti, vi = train_test_split(np.arange(len(tr)), test_size=0.15,
                                  stratify=y[tr], random_state=seed)
        yield k, tr, te, tr[ti], tr[vi]


def predict(model, X, dev, batch=256):
    model.eval()
    out = []
    with torch.no_grad():
        for i in range(0, len(X), batch):
            xb = torch.tensor(np.asarray(X[i:i + batch]), dtype=torch.float32, device=dev)
            out.append(model(xb).argmax(1).cpu().numpy())
    return np.concatenate(out) if out else np.empty(0, dtype=int)


# --------------------------------------------------------------------------- #
# Exp A: NPN with alternative spatial initializations
# --------------------------------------------------------------------------- #
def _second_moment(Xb):
    """Mean second-moment matrix (C, C) of trials (n, C, T), in float64."""
    Xd = np.asarray(Xb, dtype=np.float64)
    return np.einsum("nct,ndt->cd", Xd, Xd) / (Xd.shape[0] * Xd.shape[2])


def filter_output_variance(W, Xb):
    """Output variance (mean square) of each filter row of W on trials Xb."""
    S = _second_moment(Xb)
    W = np.asarray(W, dtype=np.float64)
    return np.einsum("kc,cd,kd->k", W, S, W)


def match_output_variance(model, target_filters, Xtr):
    """Rescale every random spatial filter so its output variance on the
    training data equals that of the corresponding CSP filter (per band, per
    filter index). Directions stay random; only the scale is matched."""
    with torch.no_grad():
        for b, conv in enumerate(model.spatials):
            W = conv.weight.detach().cpu().numpy().reshape(model.k_spatial, model.n_channels)
            F = np.asarray(target_filters[b], dtype=np.float64)[:model.k_spatial]
            v_t = filter_output_variance(F, Xtr[:, b])
            v_r = filter_output_variance(W, Xtr[:, b])
            scale = np.sqrt(v_t / np.maximum(v_r, 1e-300))
            Wn = (W * scale[:, None]).astype(np.float32).reshape(conv.weight.shape)
            conv.weight.copy_(torch.tensor(Wn, device=conv.weight.device))


def npn_spatial_init(model, init, Xtr, ytr, Xraw_tr, k):
    """Apply one of the Exp A initializations to a freshly built NPN.

    Torch RNG consumption matches npn.train.train_one: 'random' and
    'random_scaled' draw Xavier weights exactly like init='random'; the CSP
    variants draw nothing, exactly like init='csp'.
    """
    if init == "random":
        model.init_spatial_random()
    elif init == "random_scaled":
        target = band_csp_filters(Xtr, ytr, k)          # used for scale only
        model.init_spatial_random()
        match_output_variance(model, target, Xtr)
    elif init == "csp_band":
        model.init_spatial(band_csp_filters(Xtr, ytr, k))
    elif init == "csp_broadband":
        if Xraw_tr is None:
            raise ValueError("csp_broadband needs the broadband training trials")
        f = band_csp_filters(np.asarray(Xraw_tr)[:, None], ytr, k)[0]
        model.init_spatial([f] * model.n_bands)
    else:
        raise ValueError(f"unknown NPN init {init!r}")


def npn_spatial_weights(model):
    """All per-band spatial filters of an NPN as one (B*k, C) float64 array."""
    return np.concatenate([c.weight.detach().cpu().numpy().reshape(model.k_spatial, model.n_channels)
                           for c in model.spatials]).astype(np.float64)


def spatial_drift(W0, W1):
    """(mean row-wise cosine between initial and final filters, norm ratio).
    A cosine of 1.0000 with a ratio of 1.0000 means the layer did not move."""
    W0 = np.asarray(W0, dtype=np.float64).reshape(len(W0), -1)
    W1 = np.asarray(W1, dtype=np.float64).reshape(len(W1), -1)
    n0 = np.linalg.norm(W0, axis=1)
    n1 = np.linalg.norm(W1, axis=1)
    cos = np.sum(W0 * W1, axis=1) / np.maximum(n0 * n1, 1e-300)
    return float(np.mean(cos)), float(np.linalg.norm(W1) / max(np.linalg.norm(W0), 1e-300))


def train_npn(Xtr, ytr, Xva, yva, n_classes, init, freeze=False, Xraw_tr=None,
              k_spatial=4, epochs=500, patience=75, lr=1e-3, batch=16,
              aug_factor=3.0, seed=42, dev=None):
    """npn.train.train_one with a pluggable spatial initialization.

    For (init='csp_band', freeze=False), (init='random', freeze=False) and
    (init='csp_band', freeze=True) this reproduces train_one's 'csp', 'random'
    and 'frozen' conditions step for step. Returns (model, best_val, epochs_run).
    """
    from sklearn.metrics import accuracy_score
    dev = dev or device()
    seed_everything(seed)
    n, B, C, T = Xtr.shape
    k = min(k_spatial, C)
    model = NPN(n_classes, C, B, k_spatial=k).to(dev)
    npn_spatial_init(model, init, Xtr, ytr, Xraw_tr, k)
    if freeze:
        with torch.no_grad():
            model(torch.tensor(Xtr[:2], dtype=torch.float32, device=dev))
        model.freeze_spatial(True)
    model._spatial_init = npn_spatial_weights(model)      # plain attribute, not in state_dict

    Xa, ya = augment_segrecomb(Xtr.reshape(n, B * C, T), ytr, factor=aug_factor, seed=seed)
    Xa = Xa.reshape(len(ya), B, C, T)

    def t(a, d):
        return torch.tensor(np.asarray(a), dtype=d, device=dev)

    with torch.no_grad():
        model(t(Xa[:2], torch.float32))
    params = [p for p in model.parameters() if p.requires_grad]
    opt = torch.optim.Adam(params, lr=lr)
    ce = nn.CrossEntropyLoss()
    LX, Ly = t(Xa, torch.float32), t(ya, torch.long)
    Xv = t(Xva, torch.float32)
    best, best_state, wait, ran = -1.0, None, 0, 0
    for ep in range(epochs):
        model.train()
        perm = torch.randperm(len(Ly))
        for i in range(0, len(perm), batch):
            idx = perm[i:i + batch]
            opt.zero_grad()
            ce(model(LX[idx]), Ly[idx]).backward()
            opt.step()
        ran = ep + 1
        model.eval()
        with torch.no_grad():
            va = accuracy_score(yva, model(Xv).argmax(1).cpu().numpy())
        if va > best:
            best, wait = va, 0
            best_state = {kk: v.detach().cpu().clone() for kk, v in model.state_dict().items()}
        else:
            wait += 1
            if wait >= patience:
                break
    if best_state is not None:
        model.load_state_dict(best_state)
    return model, best, ran


# --------------------------------------------------------------------------- #
# Exp B: EEGNet backbone and CSP-Net-2
# --------------------------------------------------------------------------- #
class EEGNetCSPNet(nn.Module):
    """EEGNet (Lawhern et al., 2018) in the configuration used by CSP-Net:
    F1=4 temporal filters of length fs/2, depth multiplier D=2 (so F1*D=8
    depthwise spatial kernels), F2=8, dropout 0.25, max-norm 1.0 on the
    depthwise spatial kernels and 0.25 on the classifier."""

    def __init__(self, n_channels, n_samples, n_classes, fs, F1=4, D=2, F2=8,
                 dropout=0.25):
        super().__init__()
        k = max(2, int(fs / 2))
        self.n_channels = n_channels
        self.temporal = nn.Sequential(
            nn.ZeroPad2d((k // 2 - 1, k - k // 2, 0, 0)),
            nn.Conv2d(1, F1, (1, k), bias=False),
            nn.BatchNorm2d(F1),
        )
        self.spatial = nn.Conv2d(F1, F1 * D, (n_channels, 1), groups=F1, bias=False)
        self.post_spatial = nn.Sequential(
            nn.BatchNorm2d(F1 * D), nn.ELU(), nn.AvgPool2d((1, 4)), nn.Dropout(dropout),
        )
        self.separable = nn.Sequential(
            nn.ZeroPad2d((7, 8, 0, 0)),
            nn.Conv2d(F1 * D, F1 * D, (1, 16), groups=F1 * D, bias=False),
            nn.BatchNorm2d(F1 * D),
            nn.Conv2d(F1 * D, F2, (1, 1), bias=False),
            nn.BatchNorm2d(F2), nn.ELU(), nn.AvgPool2d((1, 8)), nn.Dropout(dropout),
        )
        was_training = self.training
        self.eval()
        with torch.no_grad():
            n_feat = self.features(torch.zeros(1, 1, n_channels, n_samples)).shape[1]
        self.train(was_training)
        if n_feat == 0:
            raise ValueError(f"trials of {n_samples} samples are too short for EEGNet pooling")
        self.classifier = nn.Linear(n_feat, n_classes)
        self.apply(_cspnet_weight_init)

    def features(self, x):
        z = self.temporal(x)
        z = self.post_spatial(self.spatial(z))
        z = self.separable(z)
        return torch.flatten(z, 1)

    def forward(self, x):
        if x.dim() == 3:                        # (N, C, T) -> (N, 1, C, T)
            x = x.unsqueeze(1)
        return self.classifier(self.features(x))

    @torch.no_grad()
    def apply_max_norm(self):
        self.spatial.weight.data = torch.renorm(self.spatial.weight.data, p=2, dim=0, maxnorm=1.0)
        self.classifier.weight.data = torch.renorm(self.classifier.weight.data, p=2, dim=0, maxnorm=0.25)


def _cspnet_weight_init(m):
    """Weight initialization used in the CSP-Net training code."""
    if isinstance(m, nn.BatchNorm2d):
        nn.init.normal_(m.weight, 1.0, 0.02)
        nn.init.zeros_(m.bias)
    elif isinstance(m, nn.Linear):
        nn.init.xavier_normal_(m.weight)
        nn.init.zeros_(m.bias)
    elif isinstance(m, nn.Conv2d):
        nn.init.kaiming_uniform_(m.weight)


def cspnet_filters(Xtr, ytr, n_filters=8):
    """CSP filters as built by the CSP-Net trainer: MNE CSP with
    n_components=8, cov_est='epoch', average-power transform, no
    regularization, rows of filters_ in MNE's default order (mutual
    information; approximate joint diagonalization for more than two classes).
    Uses min(8, C) filters when fewer than eight channels are available."""
    from mne.decoding import CSP
    C = Xtr.shape[1]
    nf = min(n_filters, C)
    csp = CSP(n_components=nf, transform_into="average_power", log=False, cov_est="epoch")
    csp.fit(np.asarray(Xtr, dtype=np.float64), ytr)
    return np.asarray(csp.filters_[:nf], dtype=np.float32)


def init_cspnet2(model, filters):
    """Copy CSP filters into the depthwise spatial kernels, cycling them to fill
    all F1*D kernels in the same order as CSP-Net's filters.repeat(...)[:K]."""
    K = model.spatial.out_channels
    reps = math.ceil(K / len(filters))
    W = np.tile(np.asarray(filters, dtype=np.float32), (reps, 1))[:K]
    with torch.no_grad():
        model.spatial.weight.copy_(torch.tensor(W, device=model.spatial.weight.device)
                                   .view(K, 1, model.n_channels, 1))


RECIPE_SETTINGS = {
    # the NPN protocol: identical to train_one except that there is no band tensor
    "npn": dict(lr=1e-3, batch=16, epochs=500, patience=75, weight_decay=0.0,
                aug_factor=3.0, early_stop=True),
    # the CSP-Net protocol: Adam 0.01, weight decay 5e-4, batch 128, 200 epochs,
    # no augmentation, no validation split, final-epoch model
    "cspnet": dict(lr=1e-2, batch=128, epochs=200, patience=None, weight_decay=5e-4,
                   aug_factor=None, early_stop=False),
}


def train_eegnet(Xtr, ytr, Xva, yva, n_classes, fs, init, recipe, seed=42,
                 epochs=None, dev=None):
    """Train EEGNet under a recipe. init in {'random', 'csp_fix', 'csp_upd'}.
    Returns (model, best_val, epochs_run); best_val is nan without early stopping."""
    from sklearn.metrics import accuracy_score
    if recipe not in RECIPE_SETTINGS:
        raise ValueError(f"unknown recipe {recipe!r}")
    cfg = dict(RECIPE_SETTINGS[recipe])
    if epochs is not None:
        cfg["epochs"] = epochs
    dev = dev or device()
    seed_everything(seed)
    n, C, T = Xtr.shape
    model = EEGNetCSPNet(C, T, n_classes, fs).to(dev)
    if init in ("csp_fix", "csp_upd"):
        init_cspnet2(model, cspnet_filters(Xtr, ytr))
        if init == "csp_fix":
            model.spatial.weight.requires_grad_(False)
    elif init != "random":
        raise ValueError(f"unknown EEGNet init {init!r}")
    model._spatial_init = model.spatial.weight.detach().cpu().numpy().reshape(
        model.spatial.out_channels, -1).astype(np.float64)

    if cfg["aug_factor"]:
        Xa, ya = augment_segrecomb(Xtr, ytr, factor=cfg["aug_factor"], seed=seed)
    else:
        Xa, ya = Xtr, ytr
    params = [p for p in model.parameters() if p.requires_grad]
    opt = torch.optim.Adam(params, lr=cfg["lr"], weight_decay=cfg["weight_decay"])
    ce = nn.CrossEntropyLoss()
    LX = torch.tensor(np.asarray(Xa), dtype=torch.float32, device=dev).unsqueeze(1)
    Ly = torch.tensor(np.asarray(ya), dtype=torch.long, device=dev)
    use_val = cfg["early_stop"] and Xva is not None and len(Xva) > 0
    Xv = (torch.tensor(np.asarray(Xva), dtype=torch.float32, device=dev).unsqueeze(1)
          if use_val else None)
    best, best_state, wait, ran = -1.0, None, 0, 0
    for ep in range(cfg["epochs"]):
        model.train()
        perm = torch.randperm(len(Ly))
        for i in range(0, len(perm), cfg["batch"]):
            idx = perm[i:i + cfg["batch"]]
            opt.zero_grad()
            ce(model(LX[idx]), Ly[idx]).backward()
            opt.step()
            model.apply_max_norm()
        ran = ep + 1
        if not use_val:
            continue
        model.eval()
        with torch.no_grad():
            va = accuracy_score(yva, model(Xv).argmax(1).cpu().numpy())
        if va > best:
            best, wait = va, 0
            best_state = {kk: v.detach().cpu().clone() for kk, v in model.state_dict().items()}
        else:
            wait += 1
            if cfg["patience"] is not None and wait >= cfg["patience"]:
                break
    if best_state is not None:
        model.load_state_dict(best_state)
    return model, (best if use_val else float("nan")), ran


# --------------------------------------------------------------------------- #
# one cell = one (condition, input scale, recipe, seed, fold)
# --------------------------------------------------------------------------- #
def run_cell(condition, Xraw, Xb, y, n_classes, fs, split, input_scale, recipe,
             seed, epochs=None, dev=None):
    """Train and test one condition on one fold. Xb may be None for EEGNet
    conditions. Returns a dict with the metrics written to the results CSV."""
    from sklearn.metrics import accuracy_score, cohen_kappa_score
    if condition not in CONDITIONS:
        raise ValueError(f"unknown condition {condition!r}")
    if input_scale not in INPUT_SCALES:
        raise ValueError(f"unknown input scale {input_scale!r}")
    dev = dev or device()
    fold, tr, te, ti, vi = split
    s = fold_scale(Xraw, tr, input_scale)
    t0 = time.time()
    if condition in NPN_CONDITIONS:
        if Xb is None:
            raise ValueError("NPN conditions need the band tensor")
        init, freeze = _NPN_INIT[condition]
        Xraw_ti = apply_scale(Xraw[ti], input_scale, s) if init == "csp_broadband" else None
        model, best_val, ran = train_npn(
            apply_scale(Xb[ti], input_scale, s), y[ti],
            apply_scale(Xb[vi], input_scale, s), y[vi], n_classes,
            init=init, freeze=freeze, Xraw_tr=Xraw_ti, seed=seed,
            epochs=500 if epochs is None else epochs, dev=dev)
        pred = predict(model, apply_scale(Xb[te], input_scale, s), dev)
        n_train, used_recipe = len(ti), "npn"
        cos, ratio = spatial_drift(model._spatial_init, npn_spatial_weights(model))
    else:
        init = _EEGNET_INIT[condition]
        if RECIPE_SETTINGS[recipe]["early_stop"]:
            tr_idx, va_idx = ti, vi
        else:                                   # CSP-Net recipe trains on the whole fold
            tr_idx, va_idx = tr, None
        model, best_val, ran = train_eegnet(
            apply_scale(Xraw[tr_idx], input_scale, s), y[tr_idx],
            None if va_idx is None else apply_scale(Xraw[va_idx], input_scale, s),
            None if va_idx is None else y[va_idx],
            n_classes, fs, init=init, recipe=recipe, seed=seed, epochs=epochs, dev=dev)
        pred = predict(model, apply_scale(Xraw[te], input_scale, s), dev)
        n_train, used_recipe = len(tr_idx), recipe
        cos, ratio = spatial_drift(model._spatial_init,
                                   model.spatial.weight.detach().cpu().numpy().reshape(
                                       model.spatial.out_channels, -1))
    yte = y[te]
    return dict(fold=fold, recipe=used_recipe, n_train=int(n_train), n_test=int(len(te)),
                acc=float(accuracy_score(yte, pred)),
                kappa=float(cohen_kappa_score(yte, pred)),
                best_val=float(best_val), epochs_run=int(ran),
                spatial_cos=cos, spatial_norm_ratio=ratio,
                seconds=float(time.time() - t0))


# --------------------------------------------------------------------------- #
# diagnostics
# --------------------------------------------------------------------------- #
def scale_diagnostics(Xraw, Xb, y, tr_idx, fs, seed=42, k_spatial=4):
    """Variance entering the first BatchNorm of NPN (random vs per-band CSP
    spatial init) and of EEGNet (random temporal conv), computed on
    training-fold trials with the raw input. Returns medians over feature maps.
    Values far below BatchNorm's eps (1e-5) mean the layer's output is
    attenuated toward zero at the start of training."""
    Xtr_b, ytr = Xb[tr_idx], y[tr_idx]
    n, B, C, T = Xtr_b.shape
    k = min(k_spatial, C)
    xb = torch.tensor(Xtr_b[: min(64, n)], dtype=torch.float32)
    out = {}
    for init in ("random", "csp_band"):
        seed_everything(seed)
        m = NPN(len(np.unique(y)), C, B, k_spatial=k)
        npn_spatial_init(m, init, Xtr_b, ytr, None, k)
        with torch.no_grad():
            z = torch.cat([m.spatials[b](xb[:, b:b + 1]) for b in range(B)], 1)
            out[init] = float(np.median(z.var(dim=(0, 2, 3)).numpy()))
        out[f"norm_{init}"] = float(np.linalg.norm(npn_spatial_weights(m)))
    # CSP filter norm after global scaling: a large norm means Adam (lr 1e-3)
    # can move the layer only by a tiny relative amount
    s = float(np.std(Xraw[tr_idx], dtype=np.float64))
    filt_g = band_csp_filters(Xtr_b / s, ytr, k)
    out["norm_csp_band_global"] = float(np.linalg.norm(
        np.concatenate([np.asarray(f, dtype=np.float64)[:k] for f in filt_g])))
    seed_everything(seed)
    eeg = EEGNetCSPNet(C, T, len(np.unique(y)), fs=fs)
    with torch.no_grad():
        z = eeg.temporal[1](eeg.temporal[0](torch.tensor(Xraw[tr_idx][:64, None], dtype=torch.float32)))
        out["eegnet_first_bn_input"] = float(np.median(z.var(dim=(0, 2, 3)).numpy()))
    return out


def band_power_fractions(Xraw, Xb):
    """Mean power of every filter-bank band relative to the loader output."""
    p_raw = float(np.mean(np.asarray(Xraw, dtype=np.float64) ** 2))
    return [float(np.mean(np.asarray(Xb[:, b], dtype=np.float64) ** 2) / p_raw)
            for b in range(Xb.shape[1])]
