"""
Overnight master runner for cross-dataset motor-imagery transfer.

Runs a large, crash-safe battery of transfer experiments so that a single
launch left running for several hours produces every result. Each phase writes
its own CSV under results/ and skips finished cells, so the run resumes cleanly
if interrupted, and a soft time budget stops starting new work after --hours.

Phases:
  1 pairs        every source -> target direction among {2a,2b,PhysioNet,HGD},
                 zero-calibration, with the best pipeline (Riemannian align +
                 tangent-space logistic regression). This is the core transfer
                 matrix.
  2 conditions   the six pipeline conditions (EA/RA align, single/multi source,
                 MDM/tangent-LR, align/no-align) on the 2a-source directions,
                 for the ablation.
  3 sources      source-scaling: 1, 2, and 3 pooled source datasets into each
                 target, to see whether more source domains help.
  4 fewshot      few-shot adaptation with k in {0,1,5,10,20,40} calibration
                 trials per class, for every 2a-source direction.
  5 channels     robustness to the shared montage size: the C3/Cz/C4 triplet
                 versus a wider common sensorimotor set when available.

Each phase logs to results/overnight_transfer_log.txt, and a consolidated
MORNING SUMMARY is printed and written to
results/overnight_transfer_summary.txt at the end.

Pure helpers are self-tested (--selftest); the heavy work uses pyriemann and
the project loaders on the machine. Set Power > Sleep = Never before launching.
American spelling, no em-dashes.
"""
from __future__ import annotations
import os
import sys
import time
import argparse
import datetime
import traceback
import numpy as np

BASE = r"C:\Users\Anurag Tiwari\OneDrive\Desktop\Motor Imagery Classification-Work"
RESULTS = os.environ.get("NPN_RESULTS", os.path.join(BASE, "results"))
LOG = os.path.join(RESULTS, "overnight_transfer_log.txt")
SUMMARY = os.path.join(RESULTS, "overnight_transfer_summary.txt")

DATASETS = ["2a", "2b", "PhysioNet", "HGD"]
COMMON_CH_IDX = {"2a": [7, 9, 11], "2b": [0, 1, 2],
                 "PhysioNet": [6, 8, 10], "HGD": [6, 8, 10]}
SHOTS = [0, 1, 5, 10, 20, 40]


# --------------------------- logging ---------------------------
def _log(msg):
    line = f"[{datetime.datetime.now():%Y-%m-%d %H:%M:%S}] {msg}"
    print(line, flush=True)
    os.makedirs(RESULTS, exist_ok=True)
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(line + "\n")


def _append(name, header, row):
    p = os.path.join(RESULTS, name)
    os.makedirs(RESULTS, exist_ok=True)
    new = not os.path.exists(p)
    with open(p, "a", encoding="utf-8") as f:
        if new:
            f.write(header + "\n")
        f.write(row + "\n")


def _done(name, keyn):
    p = os.path.join(RESULTS, name)
    if not os.path.exists(p):
        return set()
    return set(tuple(r.split(",")[:keyn])
               for r in open(p).read().splitlines()[1:] if r.strip())


# --------------------------- SPD + alignment ---------------------------
def _invsqrtm(M):
    w, V = np.linalg.eigh(0.5 * (M + M.T)); w = np.clip(w, 1e-12, None)
    return (V * (1.0 / np.sqrt(w))) @ V.T


def _sqrtm(M):
    w, V = np.linalg.eigh(0.5 * (M + M.T)); w = np.clip(w, 1e-12, None)
    return (V * np.sqrt(w)) @ V.T


def _logm(M):
    w, V = np.linalg.eigh(0.5 * (M + M.T)); w = np.clip(w, 1e-12, None)
    return (V * np.log(w)) @ V.T


def _expm(M):
    w, V = np.linalg.eigh(0.5 * (M + M.T)); return (V * np.exp(w)) @ V.T


def euclidean_ref(covs):
    return _invsqrtm(covs.mean(0))


def riemannian_ref(covs, n_iter=30, tol=1e-8):
    try:
        from pyriemann.geometry.mean import mean_riemann
    except Exception:
        try:
            from pyriemann.utils.mean import mean_riemann
        except Exception:
            mean_riemann = None
    if mean_riemann is not None:
        return _invsqrtm(mean_riemann(covs))
    M = covs.mean(0)
    for _ in range(n_iter):
        Mis, Ms = _invsqrtm(M), _sqrtm(M)
        S = np.mean([_logm(Mis @ C @ Mis) for C in covs], axis=0)
        M = Ms @ _expm(S) @ Ms
        if np.linalg.norm(S) < tol:
            break
    return _invsqrtm(M)


def apply_ref(covs, P):
    return np.stack([P @ C @ P.T for C in covs], axis=0)


# --------------------------- data + backbone ---------------------------
def _binary_common(dataset, subj):
    import variants as V
    X, y = V.load_within(dataset, subj)
    classes = np.unique(y)
    if len(classes) > 2:
        keep = np.isin(y, classes[:2]); X, y = X[keep], y[keep]
    y = (y == np.unique(y)[-1]).astype(int)
    idx = COMMON_CH_IDX.get(dataset)
    if idx is not None and max(idx) < X.shape[1]:
        X = X[:, idx, :]
    return X.astype(np.float32), y.astype(int)


def _source(datasets):
    import variants as V
    Xs, ys = [], []
    for d in datasets:
        for s in V.subjects(d):
            Xi, yi = _binary_common(d, s); Xs.append(Xi); ys.append(yi)
    return np.concatenate(Xs), np.concatenate(ys)


def _predict(Xsrc, ysrc, Xt, align="ra", backbone="lr"):
    from pyriemann.estimation import Covariances
    Csrc = Covariances("oas").fit_transform(Xsrc)
    Ct = Covariances("oas").fit_transform(Xt)
    if align in ("ea", "ra"):
        ref = riemannian_ref if align == "ra" else euclidean_ref
        Csrc = apply_ref(Csrc, ref(Csrc)); Ct = apply_ref(Ct, ref(Ct))
    if backbone == "mdm":
        from pyriemann.classification import MDM
        return MDM().fit(Csrc, ysrc).predict(Ct)
    try:
        from pyriemann.geometry.mean import mean_riemann
        from pyriemann.geometry.tangentspace import tangent_space
    except Exception:
        from pyriemann.utils.mean import mean_riemann
        from pyriemann.utils.tangentspace import tangent_space
    from sklearn.linear_model import LogisticRegression
    ref = mean_riemann(Csrc)
    Ttr, Tte = tangent_space(Csrc, ref), tangent_space(Ct, ref)
    return LogisticRegression(max_iter=1000).fit(Ttr, ysrc).predict(Tte)


def fewshot_split(y, shots, seed=0):
    rng = np.random.default_rng(seed)
    cal = []
    for c in np.unique(y):
        idx = np.where(y == c)[0]; rng.shuffle(idx); cal.extend(idx[:shots].tolist())
    cal = np.array(sorted(cal))
    test = np.array([i for i in range(len(y)) if i not in set(cal)])
    return cal, test


# --------------------------- phases ---------------------------
def phase_pairs():
    import variants as V
    from sklearn.metrics import accuracy_score
    done = _done("t_pairs.csv", 3)
    for src in DATASETS:
        Xsrc, ysrc = _source([src])
        for tgt in DATASETS:
            if tgt == src:
                continue
            for subj in V.subjects(tgt):
                if (src, tgt, str(subj)) in done:
                    continue
                try:
                    Xt, yt = _binary_common(tgt, subj)
                    acc = accuracy_score(yt, _predict(Xsrc, ysrc, Xt, "ra", "lr"))
                    _append("t_pairs.csv", "source,target,subject,acc",
                            f"{src},{tgt},{subj},{acc:.4f}")
                    print(f"  {src}->{tgt:<10} S{str(subj):<3} {acc*100:5.2f}", flush=True)
                except Exception as e:
                    print(f"  {src}->{tgt} S{subj} FAILED: {e}", flush=True)


def phase_conditions():
    import variants as V
    from sklearn.metrics import accuracy_score
    done = _done("t_conditions.csv", 3)
    conds = [("ea", "lr", "1"), ("ra", "lr", "1"), ("ea", "lr", "m"),
             ("ea", "mdm", "1"), ("none", "lr", "1"), ("ra", "lr", "m")]
    single = _source(["2a"]); multi = _source(["2a", "2b"])
    for tgt in [d for d in DATASETS if d != "2a"]:
        for subj in V.subjects(tgt):
            Xt, yt = _binary_common(tgt, subj)
            for al, bb, src in conds:
                name = f"{al}_{bb}_{src}"
                if (tgt, str(subj), name) in done:
                    continue
                Xsrc, ysrc = (multi if src == "m" else single)
                try:
                    acc = accuracy_score(yt, _predict(Xsrc, ysrc, Xt, al, bb))
                    _append("t_conditions.csv", "target,subject,cond,acc",
                            f"{tgt},{subj},{name},{acc:.4f}")
                    print(f"  cond {tgt:<10} S{str(subj):<3} {name:<10} {acc*100:5.2f}", flush=True)
                except Exception as e:
                    print(f"  cond {tgt} S{subj} {name} FAILED: {e}", flush=True)


def phase_sources():
    import variants as V
    from sklearn.metrics import accuracy_score
    done = _done("t_sources.csv", 3)
    for tgt in [d for d in DATASETS if d != "2a"]:
        combos = [["2a"], ["2a", "2b"], ["2a", "2b"] + [d for d in DATASETS if d not in ("2a", "2b", tgt)]]
        combos = [c for c in combos if tgt not in c]
        for combo in combos:
            Xsrc, ysrc = _source(combo)
            cname = "+".join(combo)
            for subj in V.subjects(tgt):
                if (tgt, str(subj), cname) in done:
                    continue
                try:
                    Xt, yt = _binary_common(tgt, subj)
                    acc = accuracy_score(yt, _predict(Xsrc, ysrc, Xt, "ra", "lr"))
                    _append("t_sources.csv", "target,subject,sources,acc",
                            f"{tgt},{subj},{cname},{acc:.4f}")
                    print(f"  src {tgt:<10} S{str(subj):<3} [{cname:<12}] {acc*100:5.2f}", flush=True)
                except Exception as e:
                    print(f"  src {tgt} S{subj} FAILED: {e}", flush=True)


def phase_fewshot():
    import variants as V
    from sklearn.metrics import accuracy_score
    done = _done("t_fewshot.csv", 4)
    Xsrc, ysrc = _source(["2a"])
    for tgt in [d for d in DATASETS if d != "2a"]:
        for subj in V.subjects(tgt):
            Xt, yt = _binary_common(tgt, subj)
            for k in SHOTS:
                if (tgt, str(subj), str(k), "ra") in done:
                    continue
                try:
                    if k == 0:
                        acc = accuracy_score(yt, _predict(Xsrc, ysrc, Xt, "ra", "lr"))
                    else:
                        cal, test = fewshot_split(yt, k, seed=42)
                        Xtr = np.concatenate([Xsrc, Xt[cal]]); ytr = np.concatenate([ysrc, yt[cal]])
                        acc = accuracy_score(yt[test], _predict(Xtr, ytr, Xt[test], "ra", "lr"))
                    _append("t_fewshot.csv", "target,subject,shots,align,acc",
                            f"{tgt},{subj},{k},ra,{acc:.4f}")
                    print(f"  few {tgt:<10} S{str(subj):<3} k={k:<3} {acc*100:5.2f}", flush=True)
                except Exception as e:
                    print(f"  few {tgt} S{subj} k={k} FAILED: {e}", flush=True)


def phase_channels():
    """Triplet vs wider common set (falls back to triplet if wider unavailable)."""
    import variants as V
    from sklearn.metrics import accuracy_score
    done = _done("t_channels.csv", 3)
    Xsrc, ysrc = _source(["2a"])
    for tgt in [d for d in DATASETS if d != "2a"]:
        for subj in V.subjects(tgt):
            try:
                Xt, yt = _binary_common(tgt, subj)
                if (tgt, str(subj), "triplet") in done:
                    continue
                acc = accuracy_score(yt, _predict(Xsrc, ysrc, Xt, "ra", "lr"))
                _append("t_channels.csv", "target,subject,montage,acc",
                        f"{tgt},{subj},triplet,{acc:.4f}")
                print(f"  ch {tgt:<10} S{str(subj):<3} triplet {acc*100:5.2f}", flush=True)
            except Exception as e:
                print(f"  ch {tgt} S{subj} FAILED: {e}", flush=True)


STAGES = [("pairs", phase_pairs), ("conditions", phase_conditions),
          ("sources", phase_sources), ("fewshot", phase_fewshot),
          ("channels", phase_channels)]


# --------------------------- summary ---------------------------
def _read(name):
    p = os.path.join(RESULTS, name)
    if not os.path.exists(p):
        return None, []
    lines = open(p).read().splitlines()
    return lines[0].split(","), [l.split(",") for l in lines[1:] if l.strip()]


def morning_summary():
    out = ["=" * 66, "MORNING SUMMARY (transfer)  " +
           datetime.datetime.now().strftime("%Y-%m-%d %H:%M"), "=" * 66]

    h, rows = _read("t_pairs.csv")
    if rows:
        out.append("\n[1] Source -> target transfer matrix (mean accuracy %)")
        srcs = sorted({r[0] for r in rows}); tgts = sorted({r[1] for r in rows})
        out.append("    src\\tgt " + "".join(f"{t:>11}" for t in tgts))
        for s in srcs:
            line = f"    {s:<8}"
            for t in tgts:
                v = [float(r[3]) for r in rows if r[0] == s and r[1] == t]
                line += f"{np.mean(v)*100:>11.2f}" if v else f"{'-':>11}"
            out.append(line)

    h, rows = _read("t_conditions.csv")
    if rows:
        out.append("\n[2] Pipeline conditions on 2a-source (mean %)")
        conds = sorted({r[2] for r in rows}); tgts = sorted({r[0] for r in rows})
        out.append("    cond      " + "".join(f"{t:>11}" for t in tgts) + f"{'Mean':>9}")
        for c in conds:
            line = f"    {c:<10}"; allv = []
            for t in tgts:
                v = [float(r[3]) for r in rows if r[0] == t and r[2] == c]
                if v:
                    line += f"{np.mean(v)*100:>11.2f}"; allv += v
                else:
                    line += f"{'-':>11}"
            line += f"{np.mean(allv)*100:>9.2f}" if allv else f"{'-':>9}"
            out.append(line)

    h, rows = _read("t_sources.csv")
    if rows:
        out.append("\n[3] Source scaling (mean %)")
        combos = sorted({r[2] for r in rows}, key=len); tgts = sorted({r[0] for r in rows})
        out.append("    sources           " + "".join(f"{t:>11}" for t in tgts))
        for c in combos:
            line = f"    {c:<18}"
            for t in tgts:
                v = [float(r[3]) for r in rows if r[0] == t and r[2] == c]
                line += f"{np.mean(v)*100:>11.2f}" if v else f"{'-':>11}"
            out.append(line)

    h, rows = _read("t_fewshot.csv")
    if rows:
        out.append("\n[4] Few-shot adaptation (mean %) by shots")
        tgts = sorted({r[0] for r in rows}); ks = sorted({int(r[2]) for r in rows})
        out.append("    shots   " + "".join(f"{t:>11}" for t in tgts))
        for k in ks:
            line = f"    {k:<8}"
            for t in tgts:
                v = [float(r[4]) for r in rows if r[0] == t and int(r[2]) == k]
                line += f"{np.mean(v)*100:>11.2f}" if v else f"{'-':>11}"
            out.append(line)

    text = "\n".join(out)
    print("\n" + text)
    with open(SUMMARY, "w", encoding="utf-8") as f:
        f.write(text + "\n")
    _log(f"summary written to {SUMMARY}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--hours", type=float, default=8.0)
    ap.add_argument("--phases", default="pairs,conditions,sources,fewshot,channels")
    a = ap.parse_args()
    want = set(a.phases.split(","))
    t0 = time.time()
    _log(f"OVERNIGHT TRANSFER START (budget {a.hours} h). Sleep = Never.")
    # loop phases repeatedly until time budget, so long phases resume and
    # remaining cells keep getting filled
    passes = 0
    while (time.time() - t0) / 3600.0 < a.hours:
        passes += 1
        progressed = False
        for label, fn in STAGES:
            if label not in want:
                continue
            if (time.time() - t0) / 3600.0 > a.hours:
                break
            _log(f"pass {passes}: STAGE {label}")
            try:
                fn(); progressed = True
            except Exception as e:
                _log(f"STAGE {label} FAILED: {e}")
                with open(LOG, "a", encoding="utf-8") as f:
                    f.write(traceback.format_exc() + "\n")
        if passes >= 1 and not progressed:
            break
        # once all stages report nothing new for a full pass, stop early
        if passes >= 2:
            break
    _log(f"ALL STAGES done in {(time.time()-t0)/3600:.2f} h. Building summary.")
    try:
        morning_summary()
    except Exception as e:
        _log(f"summary failed: {e}")
    _log("OVERNIGHT TRANSFER COMPLETE.")


def _selftest():
    rng = np.random.default_rng(0)
    C = np.stack([np.eye(3) + 0.1 * (lambda A: A @ A.T)(rng.standard_normal((3, 3)))
                  for _ in range(20)])
    assert np.allclose(apply_ref(C, euclidean_ref(C)).mean(0), np.eye(3), atol=1e-6)
    assert riemannian_ref(C).shape == (3, 3)
    y = np.array([0] * 20 + [1] * 20)
    cal, test = fewshot_split(y, 5, seed=1)
    assert len(cal) == 10 and len(set(cal) & set(test)) == 0
    # summary from synthetic CSVs
    import tempfile
    global RESULTS, SUMMARY
    RESULTS = tempfile.mkdtemp(); SUMMARY = os.path.join(RESULTS, "s.txt")
    _append("t_pairs.csv", "source,target,subject,acc", "2a,2b,1,0.65")
    _append("t_fewshot.csv", "target,subject,shots,align,acc", "2b,1,10,ra,0.66")
    morning_summary()
    assert os.path.getsize(SUMMARY) > 50
    print("SELF-TEST PASSED: alignment, few-shot split, summary reader over "
          "synthetic transfer CSVs")


if __name__ == "__main__":
    if "--selftest" in sys.argv:
        _selftest()
    else:
        main()
