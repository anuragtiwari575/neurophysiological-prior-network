"""
Cross-dataset transfer and few-shot calibration for motor-imagery decoding,
with BCI-IV-2a as the source.

Two experiments share one aligned decoding space so that datasets with
different montages and class sets can be compared:

  transfer   Train the decoder on 2a and evaluate zero-calibration on each
             target dataset (2b, PhysioNet, HGD). Because the datasets differ
             in channels and classes, both are reduced to the common
             left-versus-right-hand task on the shared sensorimotor triplet
             (C3, Cz, C4), and each target is Euclidean-aligned to the source
             covariance reference before testing.

  fewshot    Train on 2a, then adapt to a target subject with a small number of
             labeled calibration trials per class (1, 5, 10, 20), and test on
             the rest. This measures how little target data is needed once a
             source model exists.

Alignment (Euclidean Alignment, He and Wu 2020) recenters each domain by its
mean covariance so the source and target share a common reference, which is the
standard, leakage-safe way to make covariance-based decoders transfer. The
backbone here is a compact covariance + tangent-space + logistic-regression
pipeline (parameter-light, transfers cleanly); a deep backbone can be swapped
in later.

Alignment math and the few-shot splitter are pure and self-tested (--selftest);
the dataset loading uses the project's loaders on the machine. Everything that
touches target labels is confined to the calibration split. American spelling,
no em-dashes.
"""
from __future__ import annotations
import os
import argparse
import numpy as np

_RESULTS = None
COMMON_CH = ["C3", "Cz", "C4"]          # shared sensorimotor triplet
# Indices of C3, Cz, C4 in each dataset's channel order. VERIFY against your
# loaders' actual montage order; adjust here if different.
COMMON_CH_IDX = {
    "2a": [7, 9, 11],        # 22ch: Fz,FC3,FC1,FCz,FC2,FC4,C5,C3,C1,Cz,C2,C4,...
    "2b": [0, 1, 2],         # already C3, Cz, C4
    "PhysioNet": [6, 8, 10],  # 17ch sensorimotor (verify)
    "HGD": [6, 8, 10],        # 17ch sensorimotor (verify)
}
CAL_SHOTS = [1, 5, 10, 20]


# ----------------------------- covariance + alignment -----------------------------
def _cov(X, reg=1e-6):
    """Trace-normalized covariances of trials X (n, C, T)."""
    n, C, T = X.shape
    out = np.empty((n, C, C))
    for i in range(n):
        S = X[i] @ X[i].T
        S /= (np.trace(S) + 1e-12)
        out[i] = S + reg * np.eye(C)
    return out


def _invsqrtm(M):
    w, V = np.linalg.eigh(0.5 * (M + M.T))
    w = np.clip(w, 1e-12, None)
    return (V * (1.0 / np.sqrt(w))) @ V.T


def euclidean_alignment(covs):
    """Euclidean Alignment: recenter covariances by the inverse square root of
    their arithmetic mean, so the aligned mean is the identity. Returns the
    aligned covariances and the whitening matrix (for applying to new trials)."""
    R = covs.mean(0)
    P = _invsqrtm(R)
    aligned = np.stack([P @ C @ P.T for C in covs], axis=0)
    return aligned, P


def apply_alignment(covs, P):
    return np.stack([P @ C @ P.T for C in covs], axis=0)


# ----------------------------- few-shot splitter -----------------------------
def fewshot_split(y, shots, seed=0):
    """Return (cal_idx, test_idx): `shots` labeled trials per class for
    calibration, the rest for test. Stratified, reproducible."""
    rng = np.random.default_rng(seed)
    cal = []
    for c in np.unique(y):
        idx = np.where(y == c)[0]
        rng.shuffle(idx)
        cal.extend(idx[:shots].tolist())
    cal = np.array(sorted(cal))
    test = np.array([i for i in range(len(y)) if i not in set(cal)])
    return cal, test


# ----------------------------- backbone (tangent-space LR) -----------------------------
def _fit_tangent_lr(Xtr, ytr, Xte, P_align=None):
    """Covariances -> (optional alignment) -> tangent space at source mean ->
    logistic regression. Returns test predictions."""
    from pyriemann.estimation import Covariances
    try:
        from pyriemann.geometry.mean import mean_riemann
        from pyriemann.geometry.tangentspace import tangent_space
    except Exception:
        from pyriemann.utils.mean import mean_riemann
        from pyriemann.utils.tangentspace import tangent_space
    from sklearn.linear_model import LogisticRegression

    Ctr = Covariances("oas").fit_transform(Xtr)
    Cte = Covariances("oas").transform(Xte) if hasattr(Covariances("oas"), "transform") \
        else Covariances("oas").fit_transform(Xte)
    if P_align is not None:
        Ctr = apply_alignment(Ctr, _invsqrtm(Ctr.mean(0)))
        Cte = apply_alignment(Cte, P_align)
    ref = mean_riemann(Ctr)
    Ttr = tangent_space(Ctr, ref); Tte = tangent_space(Cte, ref)
    clf = LogisticRegression(max_iter=1000, C=1.0).fit(Ttr, ytr)
    return clf.predict(Tte), ref


# ----------------------------- data helpers (2-class, common channels) -----------------------------
def _binary_common(dataset, subj):
    """Load a subject as a 2-class (left/right hand) problem on the common
    C3/Cz/C4 channels, using COMMON_CH_IDX for the channel indices."""
    import variants as V
    X, y = V.load_within(dataset, subj)                # (n, C, T), broadband 8-30
    classes = np.unique(y)
    if len(classes) > 2:
        keep = np.isin(y, classes[:2])                 # first two = LH, RH
        X, y = X[keep], y[keep]
    y = (y == np.unique(y)[-1]).astype(int)            # -> {0,1}
    idx = COMMON_CH_IDX.get(dataset)
    if idx is not None and max(idx) < X.shape[1]:
        X = X[:, idx, :]                               # restrict to C3,Cz,C4
    return X.astype(np.float32), y.astype(int)


# ----------------------------- io -----------------------------
def _path(name):
    if _RESULTS is not None:
        return os.path.join(_RESULTS, name)
    base = r"C:\Users\Anurag Tiwari\OneDrive\Desktop\Motor Imagery Classification-Work"
    return os.path.join(base, "results", name)


def _append(path, header, row):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    new = not os.path.exists(path)
    with open(path, "a") as f:
        if new:
            f.write(header + "\n")
        f.write(row + "\n")


# ----------------------------- experiments -----------------------------
def exp_transfer(targets=("2b", "PhysioNet", "HGD"), align=True):
    """Train on all 2a subjects (pooled), test zero-cal on each target subject."""
    import variants as V
    from sklearn.metrics import accuracy_score
    path = _path("transfer.csv")
    # build source (2a pooled, 2-class common)
    Xs, ys = [], []
    for s in V.subjects("2a"):
        Xi, yi = _binary_common("2a", s); Xs.append(Xi); ys.append(yi)
    Xsrc = np.concatenate(Xs); ysrc = np.concatenate(ys)
    from pyriemann.estimation import Covariances
    Csrc = Covariances("oas").fit_transform(Xsrc)
    P_src = _invsqrtm(Csrc.mean(0)) if align else None
    for tgt in targets:
        for subj in V.subjects(tgt):
            try:
                Xt, yt = _binary_common(tgt, subj)
                pred, _ = _fit_tangent_lr(Xsrc, ysrc, Xt,
                                          P_align=P_src if align else None)
                acc = accuracy_score(yt, pred)
                _append(path, "target,subject,align,acc",
                        f"{tgt},{subj},{int(align)},{acc:.4f}")
                print(f"  2a -> {tgt:<10} S{str(subj):<3} align={int(align)} "
                      f"acc={acc*100:5.2f}", flush=True)
            except Exception as e:
                print(f"  2a -> {tgt} S{subj} FAILED: {e}", flush=True)


def exp_fewshot(targets=("2b", "PhysioNet", "HGD")):
    """Train on 2a, adapt to each target subject with k labeled trials/class."""
    import variants as V
    from sklearn.metrics import accuracy_score
    path = _path("fewshot.csv")
    Xs, ys = [], []
    for s in V.subjects("2a"):
        Xi, yi = _binary_common("2a", s); Xs.append(Xi); ys.append(yi)
    Xsrc = np.concatenate(Xs); ysrc = np.concatenate(ys)
    for tgt in targets:
        for subj in V.subjects(tgt):
            try:
                Xt, yt = _binary_common(tgt, subj)
                for k in CAL_SHOTS:
                    cal, test = fewshot_split(yt, k, seed=42)
                    # source + few target-calibration trials, then test
                    Xtr = np.concatenate([Xsrc, Xt[cal]])
                    ytr = np.concatenate([ysrc, yt[cal]])
                    pred, _ = _fit_tangent_lr(Xtr, ytr, Xt[test])
                    acc = accuracy_score(yt[test], pred)
                    _append(path, "target,subject,shots,acc",
                            f"{tgt},{subj},{k},{acc:.4f}")
                    print(f"  2a+{k:>2}shot -> {tgt:<10} S{str(subj):<3} "
                          f"acc={acc*100:5.2f}", flush=True)
            except Exception as e:
                print(f"  fewshot {tgt} S{subj} FAILED: {e}", flush=True)


def summarize():
    for name, key in [("transfer.csv", "align"), ("fewshot.csv", "shots")]:
        p = _path(name)
        if not os.path.exists(p):
            continue
        lines = open(p).read().splitlines(); head = lines[0].split(",")
        rows = [l.split(",") for l in lines[1:] if l.strip()]
        ti = head.index("target"); ai = head.index("acc"); ki = head.index(key)
        print(f"\n=== {name.replace('.csv','')} : mean accuracy % ===")
        tgts = sorted({r[ti] for r in rows}); keys = sorted({r[ki] for r in rows})
        print("  " + key.ljust(8) + "".join(f"{t:>12}" for t in tgts))
        for kk in keys:
            line = f"  {kk:<8}"
            for t in tgts:
                v = [float(r[ai]) for r in rows if r[ti] == t and r[ki] == kk]
                line += f"{np.mean(v)*100:>12.2f}" if v else f"{'-':>12}"
            print(line)


# ----------------------------- self-test -----------------------------
def _selftest():
    rng = np.random.default_rng(0)
    # alignment: aligned mean is identity
    X = rng.standard_normal((30, 3, 128))
    C = _cov(X)
    A, P = euclidean_alignment(C)
    assert np.allclose(A.mean(0), np.eye(3), atol=1e-6), A.mean(0)
    # apply_alignment on new trials uses same P
    A2 = apply_alignment(C[:5], P); assert A2.shape == (5, 3, 3)
    # few-shot split: k per class, disjoint, rest to test
    y = np.array([0] * 20 + [1] * 20)
    cal, test = fewshot_split(y, 5, seed=1)
    assert len(cal) == 10 and len(set(cal) & set(test)) == 0
    assert (y[cal] == 0).sum() == 5 and (y[cal] == 1).sum() == 5
    assert len(test) == 30
    print("SELF-TEST PASSED: Euclidean alignment (aligned mean = I), "
          "apply-alignment shape, stratified few-shot split (k/class, disjoint)")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("exp", nargs="?", default="transfer",
                    choices=["transfer", "fewshot", "both", "summary"])
    ap.add_argument("--targets", default="2b,PhysioNet,HGD")
    ap.add_argument("--noalign", action="store_true")
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    if a.selftest:
        _selftest()
    else:
        tg = tuple(a.targets.split(","))
        if a.exp in ("transfer", "both"):
            exp_transfer(tg, align=not a.noalign)
        if a.exp in ("fewshot", "both"):
            exp_fewshot(tg)
        summarize()
