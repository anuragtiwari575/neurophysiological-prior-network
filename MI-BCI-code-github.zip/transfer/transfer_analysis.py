"""
Domain-distance analysis and source selection (Batches E and F).

This module answers the deeper question in the title, what determines when
transfer works, and adds a deployment-oriented source-selection experiment.

  E1 domain distance    Riemannian distance between the mean covariances of
                        every dataset pair, correlated with transfer accuracy.
                        If close domains transfer better, distance predicts
                        transferability.
  E2 asymmetry          the signed accuracy difference A(i->j) - A(j->i) for
                        each unordered pair, quantifying directional asymmetry.
  E3 alignment shift    the Riemannian distance between source and target mean
                        covariances before and after alignment, to show
                        directly that alignment reduces the domain shift it is
                        claimed to remove.
  F  source selection   given only unlabeled target statistics, pick the source
                        whose mean covariance is closest to the target, and
                        compare this to a random source and to the oracle best
                        source. This is the realistic deployment protocol.

Distances and correlations are pure and self-tested (--selftest). The full run
uses the transfer CSVs and the project loaders on the machine and writes tables
into results/analysis_tables/. American spelling, no em-dashes.
"""
from __future__ import annotations
import os
import argparse
import numpy as np

RESULTS = r"C:\Users\Anurag Tiwari\OneDrive\Desktop\Motor Imagery Classification-Work\results"
OUT = os.path.join(RESULTS, "analysis_tables")
COMMON_CH_IDX = {"2a": [7, 9, 11], "2b": [0, 1, 2],
                 "PhysioNet": [6, 8, 10], "HGD": [6, 8, 10]}
DATASETS = ["2a", "2b", "PhysioNet", "HGD"]


# --------------------------- SPD distance ---------------------------
def _logm(M):
    w, V = np.linalg.eigh(0.5 * (M + M.T)); w = np.clip(w, 1e-12, None)
    return (V * np.log(w)) @ V.T


def _invsqrtm(M):
    w, V = np.linalg.eigh(0.5 * (M + M.T)); w = np.clip(w, 1e-12, None)
    return (V * (1.0 / np.sqrt(w))) @ V.T


def riemann_distance(A, B):
    """Affine-invariant Riemannian distance between SPD matrices A and B."""
    Ais = _invsqrtm(A)
    w = np.linalg.eigvalsh(0.5 * (Ais @ B @ Ais + (Ais @ B @ Ais).T))
    w = np.clip(w, 1e-12, None)
    return float(np.sqrt(np.sum(np.log(w) ** 2)))


def spearman(x, y):
    x, y = np.asarray(x, float), np.asarray(y, float)
    rx = np.argsort(np.argsort(x)).astype(float)
    ry = np.argsort(np.argsort(y)).astype(float)
    rx -= rx.mean(); ry -= ry.mean()
    d = np.sqrt((rx ** 2).sum() * (ry ** 2).sum())
    return float((rx * ry).sum() / d) if d > 0 else np.nan


# --------------------------- data ---------------------------
def _mean_cov(dataset):
    """Mean covariance of a dataset on the common triplet (pooled subjects)."""
    import variants as V
    from pyriemann.estimation import Covariances
    try:
        from pyriemann.geometry.mean import mean_riemann
    except Exception:
        from pyriemann.utils.mean import mean_riemann
    Xs = []
    idx = COMMON_CH_IDX[dataset]
    for s in V.subjects(dataset):
        X, y = V.load_within(dataset, s)
        classes = np.unique(y)
        if len(classes) > 2:
            keep = np.isin(y, classes[:2]); X = X[keep]
        Xs.append(X[:, idx, :].astype(np.float32))
    X = np.concatenate(Xs)
    C = Covariances("oas").fit_transform(X)
    return mean_riemann(C)


def _pair_acc(rows, s, t):
    v = [float(r[3]) for r in rows if r[0] == s and r[1] == t]
    return np.mean(v) if v else np.nan


def _read(name):
    p = os.path.join(RESULTS, name)
    if not os.path.exists(p):
        return None, []
    lines = open(p).read().splitlines()
    return lines[0].split(","), [l.split(",") for l in lines[1:] if l.strip()]


def _write(name, text):
    os.makedirs(OUT, exist_ok=True)
    with open(os.path.join(OUT, name), "w") as f:
        f.write(text + "\n")


# --------------------------- E1: distance vs transfer ---------------------------
def distance_vs_transfer():
    h, rows = _read("t_pairs.csv")
    if not rows:
        print("  t_pairs.csv missing"); return
    means = {d: _mean_cov(d) for d in DATASETS}
    dists, accs, out = [], [], ["source,target,riemann_distance,transfer_acc"]
    for s in DATASETS:
        for t in DATASETS:
            if s == t:
                continue
            dist = riemann_distance(means[s], means[t])
            acc = _pair_acc(rows, s, t)
            if np.isfinite(acc):
                dists.append(dist); accs.append(acc * 100)
                out.append(f"{s},{t},{dist:.4f},{acc*100:.2f}")
    rho = spearman(dists, accs)
    out.append("")
    out.append(f"spearman_distance_vs_accuracy,{rho:.4f}")
    _write("distance_vs_transfer.csv", "\n".join(out))
    print(f"  distance_vs_transfer.csv: Spearman rho(distance, accuracy) = {rho:.3f}")
    return rho


# --------------------------- E2: asymmetry ---------------------------
def asymmetry():
    h, rows = _read("t_pairs.csv")
    if not rows:
        return
    out = ["pair,acc_i_to_j,acc_j_to_i,asymmetry"]
    seen = set()
    for i in DATASETS:
        for j in DATASETS:
            if i == j or (j, i) in seen:
                continue
            seen.add((i, j))
            aij, aji = _pair_acc(rows, i, j), _pair_acc(rows, j, i)
            if np.isfinite(aij) and np.isfinite(aji):
                out.append(f"{i}<->{j},{aij*100:.2f},{aji*100:.2f},{(aij-aji)*100:+.2f}")
    _write("asymmetry.csv", "\n".join(out))
    print(f"  asymmetry.csv: {len(out)-1} unordered pairs")


# --------------------------- E3: alignment reduces shift ---------------------------
def alignment_shift():
    means = {d: _mean_cov(d) for d in DATASETS}
    out = ["source,target,dist_before,dist_after"]
    for s in DATASETS:
        for t in DATASETS:
            if s == t:
                continue
            before = riemann_distance(means[s], means[t])
            # after independent whitening, both means map to identity
            Ps, Pt = _invsqrtm(means[s]), _invsqrtm(means[t])
            after = riemann_distance(Ps @ means[s] @ Ps.T, Pt @ means[t] @ Pt.T)
            out.append(f"{s},{t},{before:.4f},{after:.4f}")
    _write("alignment_shift.csv", "\n".join(out))
    before_vals = [float(l.split(",")[2]) for l in out[1:] if l]
    after_vals = [float(l.split(",")[3]) for l in out[1:] if l]
    print(f"  alignment_shift.csv: mean Riemannian distance "
          f"{np.mean(before_vals):.3f} -> {np.mean(after_vals):.3f} after alignment")


# --------------------------- F: unlabeled source selection ---------------------------
def source_selection():
    import variants as V
    from sklearn.metrics import accuracy_score
    h, rows = _read("t_pairs.csv")
    if not rows:
        return
    means = {d: _mean_cov(d) for d in DATASETS}
    out = ["target,random_src,random_acc,selected_src,selected_acc,oracle_src,oracle_acc"]
    rng = np.random.default_rng(0)
    for t in DATASETS:
        cands = [s for s in DATASETS if s != t]
        # unlabeled selection: closest source by Riemannian distance of means
        dists = {s: riemann_distance(means[s], means[t]) for s in cands}
        sel = min(dists, key=dists.get)
        # accuracies from the matrix
        accs = {s: _pair_acc(rows, s, t) for s in cands}
        oracle = max(accs, key=lambda s: accs[s] if np.isfinite(accs[s]) else -1)
        rnd = cands[rng.integers(0, len(cands))]
        out.append(f"{t},{rnd},{accs[rnd]*100:.2f},{sel},{accs[sel]*100:.2f},"
                   f"{oracle},{accs[oracle]*100:.2f}")
    _write("source_selection.csv", "\n".join(out))
    # summary gap: selected vs random vs oracle
    sel_acc = [float(l.split(",")[4]) for l in out[1:] if l]
    rnd_acc = [float(l.split(",")[2]) for l in out[1:] if l]
    orc_acc = [float(l.split(",")[6]) for l in out[1:] if l]
    print(f"  source_selection.csv: selected {np.mean(sel_acc):.2f} vs "
          f"random {np.mean(rnd_acc):.2f} vs oracle {np.mean(orc_acc):.2f}")


def run():
    distance_vs_transfer()
    asymmetry()
    alignment_shift()
    source_selection()
    print(f"\n  analysis tables in {OUT}")


# --------------------------- self-test ---------------------------
def _selftest():
    rng = np.random.default_rng(0)
    # Riemannian distance: zero to itself, positive and symmetric otherwise
    A = np.eye(3) + 0.1 * (lambda M: M @ M.T)(rng.standard_normal((3, 3)))
    B = np.eye(3) + 0.1 * (lambda M: M @ M.T)(rng.standard_normal((3, 3)))
    assert riemann_distance(A, A) < 1e-6
    assert riemann_distance(A, B) > 0
    assert abs(riemann_distance(A, B) - riemann_distance(B, A)) < 1e-9
    # alignment collapses two means to identity -> distance ~ 0
    Pa, Pb = _invsqrtm(A), _invsqrtm(B)
    assert riemann_distance(Pa @ A @ Pa.T, Pb @ B @ Pb.T) < 1e-5
    # spearman: monotone relation -> +-1
    x = np.arange(10.0); assert abs(spearman(x, 2 * x + 1) - 1.0) < 1e-9
    assert abs(spearman(x, -x) + 1.0) < 1e-9
    # analysis tables from synthetic pairs + stubbed mean-cov
    import tempfile, sys, types
    global RESULTS, OUT, _mean_cov
    RESULTS = tempfile.mkdtemp(); OUT = os.path.join(RESULTS, "an")
    with open(os.path.join(RESULTS, "t_pairs.csv"), "w") as f:
        f.write("source,target,subject,acc\n")
        base = {"2a": 0, "2b": 1, "PhysioNet": 2, "HGD": 3}
        for s in DATASETS:
            for t in DATASETS:
                if s == t:
                    continue
                # closer index -> higher accuracy (so distance should predict acc)
                a = 0.70 - 0.03 * abs(base[s] - base[t])
                for sub in range(1, 6):
                    f.write(f"{s},{t},{sub},{a+0.01*rng.standard_normal():.4f}\n")
    sys.modules["variants"] = types.SimpleNamespace(subjects=lambda d: [1],
                                                    load_within=lambda d, s: (None, None))
    _mean_cov = lambda d: np.eye(3) * (1.0 + 0.5 * {"2a": 0, "2b": 1, "PhysioNet": 2, "HGD": 3}[d])
    r = distance_vs_transfer(); asymmetry(); alignment_shift(); source_selection()
    assert os.path.exists(os.path.join(OUT, "distance_vs_transfer.csv"))
    assert os.path.exists(os.path.join(OUT, "source_selection.csv"))
    print(f"SELF-TEST PASSED: Riemannian distance (0 to self, symmetric, "
          f"alignment->0), Spearman, and all four analysis tables (rho={r:+.2f})")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    if a.selftest:
        _selftest()
    else:
        run()
