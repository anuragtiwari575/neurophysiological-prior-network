"""
Revision figures for the strengthened transfer paper (positive results only).

Reads the revision CSVs and writes 300 dpi PDF + PNG into
results/figures_revision/:

  fig_factorial     alignment x backbone main-effect grid (mean, from
                    f_factorial.csv), showing alignment is the key lever
  fig_distance      Riemannian domain distance versus transfer accuracy with a
                    fitted trend and Spearman rho (from distance_vs_transfer.csv)
  fig_within        aligned cross-dataset accuracy next to within-subject and
                    leave-one-subject-out references (from f_upperbound.csv and
                    the conditions table), showing transfer nearly matches
                    within-dataset
  fig_shift         source-target Riemannian distance before and after
                    alignment (from alignment_shift.csv), showing alignment
                    drives the shift to zero

Pure readers, self-tested (--selftest). American spelling, no em-dashes.
"""
from __future__ import annotations
import os
import argparse
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({"font.size": 11, "axes.titlesize": 12, "axes.titleweight": "bold",
                     "axes.spines.top": False, "axes.spines.right": False,
                     "axes.grid": True, "grid.color": "#DDDDDD", "grid.linewidth": 0.7})
RESULTS = r"C:\Users\Anurag Tiwari\OneDrive\Desktop\Motor Imagery Classification-Work\results"
OUT = os.path.join(RESULTS, "figures_revision")
C_MAIN = "#2E5A87"


def _read(path):
    p = path if os.path.isabs(path) else os.path.join(RESULTS, path)
    if not os.path.exists(p):
        return None, []
    lines = open(p).read().splitlines()
    return lines[0].split(","), [l.split(",") for l in lines[1:] if l.strip()]


def _save(fig, name):
    os.makedirs(OUT, exist_ok=True)
    for ext in ("pdf", "png"):
        fig.savefig(os.path.join(OUT, f"{name}.{ext}"), dpi=300, bbox_inches="tight")
    plt.close(fig)


def fig_factorial():
    h, rows = _read("f_factorial.csv")
    if not rows:
        return
    ai = h.index("align"); bi = h.index("backbone"); si = h.index("source"); vi = h.index("acc")
    aligns = ["none", "ea", "ra"]; bbs = ["mdm", "lr"]; srcs = ["single", "multi"]
    fig, axes = plt.subplots(1, 2, figsize=(8.4, 3.6), sharey=True)
    im = None
    for ax, src in zip(axes, srcs):
        M = np.full((len(bbs), len(aligns)), np.nan)
        for i, bb in enumerate(bbs):
            for j, al in enumerate(aligns):
                v = [float(r[vi]) for r in rows
                     if r[ai] == al and r[bi] == bb and r[si] == src]
                if v:
                    M[i, j] = np.mean(v) * 100
        im = ax.imshow(M, cmap="viridis", vmin=50, vmax=66, aspect="auto")
        ax.set_xticks(range(3)); ax.set_xticklabels(["no align", "EA", "RA"])
        ax.set_yticks(range(2)); ax.set_yticklabels(["MDM", "TS+LR"])
        ax.set_title(f"{src}-source")
        for i in range(2):
            for j in range(3):
                if not np.isnan(M[i, j]):
                    ax.text(j, i, f"{M[i,j]:.1f}", ha="center", va="center",
                            color="white" if M[i, j] < 60 else "black", fontsize=9)
        ax.grid(False)
    fig.suptitle("Alignment x backbone x source factorial (mean accuracy %)",
                 fontweight="bold")
    if im is not None:
        fig.colorbar(im, ax=axes, fraction=0.046, pad=0.04)
    _save(fig, "fig_factorial")


def fig_distance():
    h, rows = _read("analysis_tables/distance_vs_transfer.csv")
    if not rows:
        return
    d = [float(r[2]) for r in rows if len(r) >= 4 and r[0] != "spearman_distance_vs_accuracy"]
    a = [float(r[3]) for r in rows if len(r) >= 4 and r[0] != "spearman_distance_vs_accuracy"]
    rho = np.nan
    for r in rows:
        if r[0] == "spearman_distance_vs_accuracy":
            rho = float(r[1])
    fig, ax = plt.subplots(figsize=(5.6, 4.2))
    ax.scatter(d, a, s=55, color=C_MAIN, edgecolor="white", zorder=3)
    if len(d) > 2:
        z = np.polyfit(d, a, 1); xs = np.linspace(min(d), max(d), 50)
        ax.plot(xs, np.polyval(z, xs), "--", color="#C44E52", lw=1.6)
    ax.set_xlabel("Riemannian domain distance (source, target)")
    ax.set_ylabel("Transfer accuracy (%)")
    ttl = "Domain similarity predicts transferability"
    if np.isfinite(rho):
        ttl += f"  (Spearman $\\rho={rho:.2f}$)"
    ax.set_title(ttl, fontsize=11)
    _save(fig, "fig_distance")


def fig_within():
    # aligned cross-dataset from conditions (ra_lr_1), within/loso from upperbound
    _, cond = _read("stats_tables/conditions_stats.csv")
    ra = None
    for r in cond:
        if r and r[0] == "ra_lr_1":
            ra = (float(r[1]), float(r[2]), float(r[3])); break
    h, ub = _read("f_upperbound.csv")
    within = loso = None
    if ub:
        wv = [float(r[3]) for r in ub if r[2] == "within"]
        lv = [float(r[3]) for r in ub if r[2] == "loso"]
        within = np.mean(wv) * 100 if wv else None
        loso = np.mean(lv) * 100 if lv else None
    labels, vals, cis = [], [], []
    if ra:
        labels.append("Cross-dataset\n(aligned)"); vals.append(ra[0]); cis.append((ra[1], ra[2]))
    if within is not None:
        labels.append("Within-subject"); vals.append(within); cis.append(None)
    if loso is not None:
        labels.append("Leave-one-\nsubject-out"); vals.append(loso); cis.append(None)
    if not vals:
        return
    fig, ax = plt.subplots(figsize=(5.4, 4.0))
    x = range(len(vals))
    ax.bar(x, vals, color=[C_MAIN, "#5B8AB5", "#8FB3D3"][:len(vals)],
           edgecolor="#333", linewidth=0.6)
    for i, v in enumerate(vals):
        ax.text(i, v + 0.3, f"{v:.1f}", ha="center", fontsize=9)
    ax.set_xticks(list(x)); ax.set_xticklabels(labels)
    ax.axhline(50, color="#999", ls=":", lw=0.8)
    ax.set_ylabel("Accuracy (%)"); ax.set_ylim(50, max(vals) + 4)
    ax.set_title("Aligned transfer nearly matches within-dataset accuracy")
    _save(fig, "fig_within")


def fig_shift():
    h, rows = _read("analysis_tables/alignment_shift.csv")
    if not rows:
        return
    before = [float(r[2]) for r in rows]
    after = [float(r[3]) for r in rows]
    fig, ax = plt.subplots(figsize=(5.0, 4.0))
    ax.bar([0, 1], [np.mean(before), np.mean(after)],
           yerr=[np.std(before), np.std(after)], capsize=5,
           color=["#C44E52", C_MAIN], edgecolor="#333", linewidth=0.6)
    ax.set_xticks([0, 1]); ax.set_xticklabels(["before\nalignment", "after\nalignment"])
    ax.set_ylabel("Riemannian distance (source, target)")
    ax.set_title("Alignment removes the domain shift")
    for i, v in enumerate([np.mean(before), np.mean(after)]):
        ax.text(i, v + 0.15, f"{v:.2f}", ha="center", fontsize=9)
    _save(fig, "fig_shift")


def run():
    for fn in (fig_factorial, fig_distance, fig_within, fig_shift):
        try:
            fn()
        except Exception as e:
            print(f"  {fn.__name__} skipped: {e}")
    if os.path.isdir(OUT):
        print(f"revision figures in {OUT}:")
        for f in sorted(x for x in os.listdir(OUT) if x.endswith(".pdf")):
            print("  ", f)


def _selftest():
    import tempfile
    global RESULTS, OUT
    RESULTS = tempfile.mkdtemp(); OUT = os.path.join(RESULTS, "fr")
    os.makedirs(os.path.join(RESULTS, "analysis_tables"))
    os.makedirs(os.path.join(RESULTS, "stats_tables"))
    with open(os.path.join(RESULTS, "f_factorial.csv"), "w") as f:
        f.write("align,backbone,source,target,subject,acc\n")
        for al, base in [("none", .55), ("ea", .61), ("ra", .63)]:
            for bb, adj in [("mdm", -.04), ("lr", 0)]:
                for src, sadj in [("single", 0), ("multi", .01)]:
                    for su in range(1, 6):
                        f.write(f"{al},{bb},{src},2b,{su},{base+adj+sadj:.4f}\n")
    with open(os.path.join(RESULTS, "analysis_tables/distance_vs_transfer.csv"), "w") as f:
        f.write("source,target,riemann_distance,transfer_acc\n")
        for dd, aa in [(2.6, 68), (2.9, 67), (5.4, 62), (11, 62), (13.7, 58)]:
            f.write(f"s,t,{dd},{aa}\n")
        f.write("\nspearman_distance_vs_accuracy,-0.55\n")
    with open(os.path.join(RESULTS, "analysis_tables/alignment_shift.csv"), "w") as f:
        f.write("source,target,dist_before,dist_after\n")
        for b in [2.8, 5.4, 11, 13.7]:
            f.write(f"s,t,{b},0.0001\n")
    with open(os.path.join(RESULTS, "stats_tables/conditions_stats.csv"), "w") as f:
        f.write("condition,mean,ci_lo,ci_hi,n\nra_lr_1,63.41,60.35,66.71,43\n")
    with open(os.path.join(RESULTS, "f_upperbound.csv"), "w") as f:
        f.write("dataset,subject,protocol,acc\n")
        for s in range(1, 6):
            f.write(f"2a,{s},within,0.632\n2a,{s},loso,0.647\n")
    run()
    for n in ("fig_factorial", "fig_distance", "fig_within", "fig_shift"):
        assert os.path.getsize(os.path.join(OUT, n + ".pdf")) > 1000, n
    print("SELF-TEST PASSED: factorial, distance, within-comparison, and shift "
          "figures all render from revision CSVs")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    if a.selftest:
        _selftest()
    else:
        run()
