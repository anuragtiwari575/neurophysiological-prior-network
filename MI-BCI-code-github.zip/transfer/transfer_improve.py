"""
Compare four improvements to cross-dataset motor-imagery transfer, with 2a as
the primary source, on the common left/right-hand task over the C3/Cz/C4
triplet. All four are evaluated zero-calibration on each target subject and
summarized side by side.

  idea1  alignment       Euclidean Alignment (EA) versus Riemannian Alignment
                         (RA, recentering by the geometric mean) as the
                         domain-recentering step. Which alignment transfers
                         better?
  idea2  multisource     single-source (2a) versus multi-source (2a + 2b)
                         pooled training, to test whether more source domains
                         help the target.
  idea3  backbone        tangent-space logistic regression versus a compact
                         MDM classifier as the transfer backbone (a
                         parameter-light stand-in for a deep backbone that can
                         be swapped in on the machine).
  idea4  ablation        alignment on versus off, to quantify how much the
                         recentering contributes.

Every condition reuses one aligned pipeline so the comparison is controlled.
Target labels are never used for training in the zero-calibration conditions.
Results append crash-safe to results/transfer_improve.csv and summarize() prints
an idea-by-idea table with the best option per target.

The alignment routines and splitters are pure and self-tested (--selftest); the
data loading uses the project loaders on the machine. American spelling, no
em-dashes.
"""
from __future__ import annotations
import os
import argparse
import numpy as np

_RESULTS = None
COMMON_CH_IDX = {
    "2a": [7, 9, 11], "2b": [0, 1, 2],
    "PhysioNet": [6, 8, 10], "HGD": [6, 8, 10],
}


# ----------------------------- SPD + alignment -----------------------------
def _cov(X, reg=1e-6):
    n, C, T = X.shape
    out = np.empty((n, C, C))
    for i in range(n):
        S = X[i] @ X[i].T; S /= (np.trace(S) + 1e-12)
        out[i] = S + reg * np.eye(C)
    return out


def _invsqrtm(M):
    w, V = np.linalg.eigh(0.5 * (M + M.T)); w = np.clip(w, 1e-12, None)
    return (V * (1.0 / np.sqrt(w))) @ V.T


def _sqrtm(M):
    w, V = np.linalg.eigh(0.5 * (M + M.T)); w = np.clip(w, 1e-12, None)
    return (V * np.sqrt(w)) @ V.T


def _logm(M):
    w, V = np.linalg.eigh(0.5 * (M + M.T)); w = np.clip(w, 1e-12, None)
    return (V * np.log(w)) @ V.T


def _expm(M):
    w, V = np.linalg.eigh(0.5 * (M + M.T)); return (V * np.exp(w)) @ V.T


def euclidean_ref(covs):
    """Whitening by inverse sqrt of the arithmetic mean (EA)."""
    return _invsqrtm(covs.mean(0))


def riemannian_ref(covs, n_iter=30, tol=1e-8):
    """Whitening by inverse sqrt of the geometric (Riemannian) mean (RA)."""
    try:
        from pyriemann.geometry.mean import mean_riemann
    except Exception:
        try:
            from pyriemann.utils.mean import mean_riemann
        except Exception:
            mean_riemann = None
    if mean_riemann is not None:
        return _invsqrtm(mean_riemann(covs))
    M = covs.mean(0)
    for _ in range(n_iter):
        Mis, Ms = _invsqrtm(M), _sqrtm(M)
        S = np.mean([_logm(Mis @ C @ Mis) for C in covs], axis=0)
        M = Ms @ _expm(S) @ Ms
        if np.linalg.norm(S) < tol:
            break
    return _invsqrtm(M)


def apply_ref(covs, P):
    return np.stack([P @ C @ P.T for C in covs], axis=0)


# ----------------------------- backbones -----------------------------
def _tangent_lr(Ctr, ytr, Cte):
    try:
        from pyriemann.geometry.mean import mean_riemann
        from pyriemann.geometry.tangentspace import tangent_space
    except Exception:
        from pyriemann.utils.mean import mean_riemann
        from pyriemann.utils.tangentspace import tangent_space
    from sklearn.linear_model import LogisticRegression
    ref = mean_riemann(Ctr)
    Ttr, Tte = tangent_space(Ctr, ref), tangent_space(Cte, ref)
    return LogisticRegression(max_iter=1000).fit(Ttr, ytr).predict(Tte)


def _mdm(Ctr, ytr, Cte):
    from pyriemann.classification import MDM
    return MDM().fit(Ctr, ytr).predict(Cte)


# ----------------------------- data -----------------------------
def _binary_common(dataset, subj):
    import variants as V
    X, y = V.load_within(dataset, subj)
    classes = np.unique(y)
    if len(classes) > 2:
        keep = np.isin(y, classes[:2]); X, y = X[keep], y[keep]
    y = (y == np.unique(y)[-1]).astype(int)
    idx = COMMON_CH_IDX.get(dataset)
    if idx is not None and max(idx) < X.shape[1]:
        X = X[:, idx, :]
    return X.astype(np.float32), y.astype(int)


def _source(datasets):
    import variants as V
    Xs, ys = [], []
    for d in datasets:
        for s in V.subjects(d):
            Xi, yi = _binary_common(d, s); Xs.append(Xi); ys.append(yi)
    return np.concatenate(Xs), np.concatenate(ys)


# ----------------------------- io -----------------------------
def _path():
    if _RESULTS is not None:
        return os.path.join(_RESULTS, "transfer_improve.csv")
    base = r"C:\Users\Anurag Tiwari\OneDrive\Desktop\Motor Imagery Classification-Work"
    return os.path.join(base, "results", "transfer_improve.csv")


def _done():
    p = _path()
    if not os.path.exists(p):
        return set()
    return set((r.split(",")[0], r.split(",")[1], r.split(",")[2])
               for r in open(p).read().splitlines()[1:] if r.strip())


def _append(tgt, subj, cond, acc):
    p = _path(); os.makedirs(os.path.dirname(p), exist_ok=True)
    new = not os.path.exists(p)
    with open(p, "a") as f:
        if new:
            f.write("target,subject,cond,acc\n")
        f.write(f"{tgt},{subj},{cond},{acc:.4f}\n")


# conditions covering the four ideas
CONDS = [
    "ea_lr_single_align",     # baseline: EA + tangent-LR + 2a + align
    "ra_lr_single_align",     # idea1: Riemannian alignment
    "ea_lr_multi_align",      # idea2: multi-source (2a+2b)
    "ea_mdm_single_align",    # idea3: MDM backbone
    "ea_lr_single_noalign",   # idea4: no alignment
    "ra_lr_multi_align",      # combine best: Riemannian + multi-source + align
]


def _predict(cond, Xsrc, ysrc, Xt):
    from pyriemann.estimation import Covariances
    Csrc = Covariances("oas").fit_transform(Xsrc)
    Ct = Covariances("oas").fit_transform(Xt)
    align = "noalign" not in cond
    if align:
        P = riemannian_ref(Csrc) if cond.startswith("ra") else euclidean_ref(Csrc)
        Pt = riemannian_ref(Ct) if cond.startswith("ra") else euclidean_ref(Ct)
        Csrc = apply_ref(Csrc, P); Ct = apply_ref(Ct, Pt)
    if "mdm" in cond:
        return _mdm(Csrc, ysrc, Ct)
    return _tangent_lr(Csrc, ysrc, Ct)


def run(targets=("2b", "PhysioNet", "HGD"), conds=None):
    import variants as V
    from sklearn.metrics import accuracy_score
    conds = conds or CONDS
    done = _done()
    # precompute sources
    src_single = _source(["2a"])
    src_multi = _source(["2a", "2b"])
    for tgt in targets:
        for subj in V.subjects(tgt):
            Xt, yt = _binary_common(tgt, subj)
            for cond in conds:
                if (tgt, str(subj), cond) in done:
                    continue
                Xsrc, ysrc = (src_multi if "multi" in cond else src_single)
                try:
                    pred = _predict(cond, Xsrc, ysrc, Xt)
                    acc = accuracy_score(yt, pred)
                    _append(tgt, subj, cond, acc)
                    print(f"  {tgt:<10} S{str(subj):<3} {cond:<22} {acc*100:5.2f}", flush=True)
                except Exception as e:
                    print(f"  {tgt} S{subj} {cond} FAILED: {e}", flush=True)
    summarize()


def summarize():
    p = _path()
    if not os.path.exists(p):
        print("no results yet"); return
    rows = [r.split(",") for r in open(p).read().splitlines()[1:] if r.strip()]
    tgts = sorted({r[0] for r in rows})
    print("\n=== Transfer improvements: mean accuracy % ===")
    print("  condition".ljust(24) + "".join(f"{t:>12}" for t in tgts) + f"{'Mean':>9}")
    means = {}
    for cond in CONDS:
        line = f"  {cond:<22}"; vals = []
        for t in tgts:
            v = [float(r[3]) for r in rows if r[0] == t and r[2] == cond]
            if v:
                line += f"{np.mean(v)*100:>12.2f}"; vals.append(np.mean(v) * 100)
            else:
                line += f"{'-':>12}"
        means[cond] = np.mean(vals) if vals else float("nan")
        line += f"{means[cond]:>9.2f}"
        print(line)
    # per-idea verdicts
    print("\n  === Verdicts ===")
    def cmp(a, b, label):
        if a in means and b in means and np.isfinite(means[a]) and np.isfinite(means[b]):
            d = means[a] - means[b]
            print(f"  {label:<26}: {means[a]:.2f} vs {means[b]:.2f} = {d:+.2f} pts")
    cmp("ra_lr_single_align", "ea_lr_single_align", "idea1 Riemann vs Euclid align")
    cmp("ea_lr_multi_align", "ea_lr_single_align", "idea2 multi vs single source")
    cmp("ea_mdm_single_align", "ea_lr_single_align", "idea3 MDM vs tangent-LR")
    cmp("ea_lr_single_align", "ea_lr_single_noalign", "idea4 align vs no-align")
    cmp("ra_lr_multi_align", "ea_lr_single_align", "combo RA+multi vs baseline")
    best = max((c for c in means if np.isfinite(means[c])), key=lambda c: means[c], default=None)
    if best:
        print(f"\n  best overall condition: {best} ({means[best]:.2f}%)")


# ----------------------------- self-test -----------------------------
def _selftest():
    rng = np.random.default_rng(0)
    X = rng.standard_normal((30, 3, 128)); C = _cov(X)
    Pe, Pr = euclidean_ref(C), riemannian_ref(C)
    assert np.allclose(apply_ref(C, Pe).mean(0), np.eye(3), atol=1e-6)   # EA -> I mean
    assert Pr.shape == (3, 3) and np.all(np.linalg.eigvalsh(Pr) > 0)      # RA SPD whitening
    # routing with stub
    import sys, types
    __import__("shutil").rmtree("/tmp/ti", ignore_errors=True)
    global _RESULTS, _predict, _source
    _RESULTS = "/tmp/ti"
    sys.modules["variants"] = types.SimpleNamespace(subjects=lambda d: [1, 2])
    rp, rs = _predict, _source
    _predict = lambda cond, Xs, ys, Xt: np.zeros(len(Xt), int)
    _source = lambda ds: (rng.standard_normal((10, 3, 64)), np.array([0, 1] * 5))
    # stub binary_common
    global _binary_common
    rb = _binary_common
    _binary_common = lambda d, s: (rng.standard_normal((8, 3, 64)), np.array([0, 1, 0, 1, 0, 1, 0, 1]))
    run(targets=("2b",))
    _predict, _source, _binary_common = rp, rs, rb
    rows = open("/tmp/ti/transfer_improve.csv").read().splitlines()
    assert len(rows) == 1 + 2 * len(CONDS), len(rows)
    _RESULTS = None
    print("SELF-TEST PASSED: EA (mean=I) and RA (SPD) alignment, 5-condition "
          "routing across the four ideas, crash-safe CSV, verdicts")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--targets", default="2b,PhysioNet,HGD")
    ap.add_argument("--conds", default=",".join(CONDS))
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    if a.selftest:
        _selftest()
    else:
        run(targets=tuple(a.targets.split(",")), conds=a.conds.split(","))
