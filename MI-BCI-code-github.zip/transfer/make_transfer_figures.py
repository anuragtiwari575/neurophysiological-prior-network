"""
Generate the transfer-paper figures from the overnight result CSVs.

Reads results/t_pairs.csv, t_conditions.csv, t_sources.csv, t_fewshot.csv and
writes 300 dpi PDF + PNG into results/figures_transfer/:

  fig_matrix        4x4 source-to-target transfer heatmap (the flagship)
  fig_alignment     alignment ablation bars (align vs no-align and variants)
  fig_sources       source-scaling lines per target
  fig_fewshot       few-shot adaptation curves per target
  fig_perdataset    per-subject distribution (box) of transfer accuracy by target
  fig_besttarget    best source per target, as a labeled bar

All figures are drawn only from the CSVs (no fabrication) and are grayscale
readable. The reducers are self-tested (--selftest). American spelling, no
em-dashes.
"""
from __future__ import annotations
import os
import argparse
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({"font.size": 11, "axes.titlesize": 12, "axes.titleweight": "bold",
                     "axes.spines.top": False, "axes.spines.right": False,
                     "axes.grid": True, "grid.color": "#DDDDDD", "grid.linewidth": 0.7})
BASE = r"C:\Users\Anurag Tiwari\OneDrive\Desktop\Motor Imagery Classification-Work"
RESULTS = os.environ.get("NPN_RESULTS", os.path.join(BASE, "results"))
OUT = os.path.join(RESULTS, "figures_transfer")
ORDER = ["2a", "2b", "PhysioNet", "HGD"]
C_MAIN = "#2E5A87"


def _read(name):
    p = os.path.join(RESULTS, name)
    if not os.path.exists(p):
        return None, []
    lines = open(p).read().splitlines()
    return lines[0].split(","), [l.split(",") for l in lines[1:] if l.strip()]


def _save(fig, name):
    os.makedirs(OUT, exist_ok=True)
    for ext in ("pdf", "png"):
        fig.savefig(os.path.join(OUT, f"{name}.{ext}"), dpi=300, bbox_inches="tight")
    plt.close(fig)


def _order(vals):
    return [v for v in ORDER if v in vals] + [v for v in sorted(vals) if v not in ORDER]


def fig_matrix():
    h, rows = _read("t_pairs.csv")
    if not rows:
        return
    srcs = _order({r[0] for r in rows}); tgts = _order({r[1] for r in rows})
    M = np.full((len(srcs), len(tgts)), np.nan)
    for i, s in enumerate(srcs):
        for j, t in enumerate(tgts):
            v = [float(r[3]) for r in rows if r[0] == s and r[1] == t]
            if v:
                M[i, j] = np.mean(v) * 100
    fig, ax = plt.subplots(figsize=(5.4, 4.6))
    im = ax.imshow(M, cmap="viridis", vmin=50, vmax=75)
    ax.set_xticks(range(len(tgts))); ax.set_xticklabels(tgts)
    ax.set_yticks(range(len(srcs))); ax.set_yticklabels(srcs)
    ax.set_xlabel("Target"); ax.set_ylabel("Source")
    ax.set_title("Cross-dataset transfer accuracy (%)")
    for i in range(len(srcs)):
        for j in range(len(tgts)):
            if not np.isnan(M[i, j]):
                ax.text(j, i, f"{M[i,j]:.1f}", ha="center", va="center",
                        color="white" if M[i, j] < 66 else "black", fontsize=9)
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04, label="accuracy (%)")
    ax.grid(False)
    _save(fig, "fig_matrix")


def fig_alignment():
    h, rows = _read("t_conditions.csv")
    if not rows:
        return
    conds = sorted({r[2] for r in rows})
    label = {"none_lr_1": "no align", "ea_lr_1": "EA", "ra_lr_1": "RA",
             "ea_lr_m": "EA+multi", "ra_lr_m": "RA+multi", "ea_mdm_1": "EA+MDM"}
    means = {}
    for c in conds:
        v = [float(r[3]) for r in rows if r[2] == c]
        means[c] = np.mean(v) * 100 if v else np.nan
    order = sorted(means, key=lambda c: means[c])
    names = [label.get(c, c) for c in order]
    vals = [means[c] for c in order]
    colors = ["#B0B0B0" if "none" in c or "mdm" in c else C_MAIN for c in order]
    fig, ax = plt.subplots(figsize=(6.2, 4.2))
    ax.bar(range(len(order)), vals, color=colors, edgecolor="#333", linewidth=0.6)
    for i, v in enumerate(vals):
        ax.text(i, v + 0.2, f"{v:.1f}", ha="center", fontsize=8.5)
    ax.set_xticks(range(len(order))); ax.set_xticklabels(names, rotation=20, ha="right")
    ax.set_ylabel("Mean accuracy (%)"); ax.set_ylim(50, max(vals) + 3)
    ax.axhline(50, color="#999", ls=":", lw=0.8)
    ax.set_title("Alignment is the key enabler of transfer")
    _save(fig, "fig_alignment")


def fig_sources():
    h, rows = _read("t_sources.csv")
    if not rows:
        return
    tgts = _order({r[0] for r in rows})
    fig, ax = plt.subplots(figsize=(6.2, 4.2))
    for t in tgts:
        combos = sorted({r[2] for r in rows if r[0] == t}, key=len)
        xs = [c.count("+") + 1 for c in combos]
        ys = [np.mean([float(r[3]) for r in rows if r[0] == t and r[2] == c]) * 100
              for c in combos]
        ax.plot(xs, ys, "o-", lw=2, ms=6, label=t)
    ax.set_xlabel("Number of source datasets"); ax.set_ylabel("Accuracy (%)")
    ax.set_xticks([1, 2, 3])
    ax.set_title("More source datasets add little")
    ax.legend(fontsize=9, frameon=False)
    _save(fig, "fig_sources")


def fig_fewshot():
    h, rows = _read("t_fewshot.csv")
    if not rows:
        return
    ai = h.index("acc"); si = h.index("shots"); ti = h.index("target")
    tgts = _order({r[ti] for r in rows})
    fig, ax = plt.subplots(figsize=(6.2, 4.2))
    for t in tgts:
        ks = sorted({int(r[si]) for r in rows if r[ti] == t})
        ys = [np.mean([float(r[ai]) for r in rows if r[ti] == t and int(r[si]) == k]) * 100
              for k in ks]
        ax.plot(ks, ys, "o-", lw=2, ms=6, label=t)
    ax.set_xlabel("Calibration trials per class"); ax.set_ylabel("Accuracy (%)")
    ax.set_title("Few-shot calibration adds little")
    ax.legend(fontsize=9, frameon=False)
    _save(fig, "fig_fewshot")


def fig_perdataset():
    h, rows = _read("t_pairs.csv")
    if not rows:
        return
    tgts = _order({r[1] for r in rows})
    data = [[float(r[3]) * 100 for r in rows if r[1] == t] for t in tgts]
    fig, ax = plt.subplots(figsize=(6.0, 4.2))
    bp = ax.boxplot(data, labels=tgts, patch_artist=True, showmeans=True)
    for patch in bp["boxes"]:
        patch.set_facecolor("#BBD3E8")
    ax.axhline(50, color="#C44E52", ls="--", lw=1.1, label="chance")
    ax.set_ylabel("Transfer accuracy (%)"); ax.set_xlabel("Target dataset")
    ax.set_title("Per-subject transfer accuracy by target")
    ax.legend(fontsize=9, frameon=False)
    _save(fig, "fig_perdataset")


def fig_besttarget():
    h, rows = _read("t_pairs.csv")
    if not rows:
        return
    tgts = _order({r[1] for r in rows})
    best = []
    for t in tgts:
        srcs = {r[0] for r in rows if r[1] == t}
        cand = {s: np.mean([float(r[3]) for r in rows if r[0] == s and r[1] == t]) * 100
                for s in srcs}
        bs = max(cand, key=cand.get)
        best.append((t, bs, cand[bs]))
    fig, ax = plt.subplots(figsize=(6.0, 4.0))
    ax.bar(range(len(best)), [b[2] for b in best], color=C_MAIN,
           edgecolor="#333", linewidth=0.6)
    for i, (t, bs, v) in enumerate(best):
        ax.text(i, v + 0.3, f"{bs}\n{v:.1f}", ha="center", fontsize=8.5)
    ax.set_xticks(range(len(best))); ax.set_xticklabels([b[0] for b in best])
    ax.axhline(50, color="#999", ls=":", lw=0.8)
    ax.set_ylabel("Best transfer accuracy (%)"); ax.set_xlabel("Target dataset")
    ax.set_ylim(50, max(b[2] for b in best) + 4)
    ax.set_title("Best source per target")
    _save(fig, "fig_besttarget")


def run():
    for fn in (fig_matrix, fig_alignment, fig_sources, fig_fewshot,
               fig_perdataset, fig_besttarget):
        try:
            fn()
        except Exception as e:
            print(f"  {fn.__name__} skipped: {e}")
    made = sorted(f for f in os.listdir(OUT) if f.endswith(".pdf")) if os.path.isdir(OUT) else []
    print(f"figures written to {OUT}:")
    for f in made:
        print("  ", f)


def _selftest():
    import tempfile
    global RESULTS, OUT
    RESULTS = tempfile.mkdtemp(); OUT = os.path.join(RESULTS, "figs")
    with open(os.path.join(RESULTS, "t_pairs.csv"), "w") as f:
        f.write("source,target,subject,acc\n")
        rng = np.random.default_rng(0)
        for s in ORDER:
            for t in ORDER:
                if s == t:
                    continue
                for sub in range(1, 6):
                    f.write(f"{s},{t},{sub},{0.55+0.1*rng.random():.4f}\n")
    with open(os.path.join(RESULTS, "t_conditions.csv"), "w") as f:
        f.write("target,subject,cond,acc\n")
        for c, a in [("none_lr_1", .57), ("ea_lr_1", .62), ("ra_lr_1", .63),
                     ("ra_lr_m", .636), ("ea_mdm_1", .575)]:
            for t in ["2b", "HGD", "PhysioNet"]:
                for sub in range(1, 4):
                    f.write(f"{t},{sub},{c},{a:.4f}\n")
    with open(os.path.join(RESULTS, "t_sources.csv"), "w") as f:
        f.write("target,subject,sources,acc\n")
        for c in ["2a", "2a+2b", "2a+2b+HGD"]:
            for sub in range(1, 4):
                f.write(f"PhysioNet,{sub},{c},0.62\n")
    with open(os.path.join(RESULTS, "t_fewshot.csv"), "w") as f:
        f.write("target,subject,shots,align,acc\n")
        for k in [0, 1, 5, 10, 20]:
            for sub in range(1, 4):
                f.write(f"2b,{sub},{k},ra,{0.67+0.001*k:.4f}\n")
    run()
    for n in ("fig_matrix", "fig_alignment", "fig_sources", "fig_fewshot",
              "fig_perdataset", "fig_besttarget"):
        assert os.path.getsize(os.path.join(OUT, n + ".pdf")) > 1000, n
    print("SELF-TEST PASSED: all six transfer figures render from CSVs")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    if a.selftest:
        _selftest()
    else:
        run()
