"""
Statistical core for the transfer benchmark (Batch A).

Adds the uncertainty and significance that a benchmark needs, on top of the raw
per-subject accuracies produced by the transfer experiments:

  - bootstrap 95% confidence intervals for any set of per-subject scores;
  - subject-level paired permutation test for two conditions on the same
    subjects (sign-flip of paired differences), with Cohen's dz effect size;
  - per-cell significance of each transfer direction against the 50% chance
    level (one-sample sign-flip permutation on centered accuracies);
  - extra metrics from stored predictions when available: balanced accuracy,
    macro F1, and Matthews correlation coefficient.

It reads the transfer CSVs (t_pairs, t_conditions, t_sources, t_fewshot) and
writes augmented tables with mean, 95% CI, and p-values into
results/stats_tables/. All statistics are pure and self-tested (--selftest).
American spelling, no em-dashes.
"""
from __future__ import annotations
import os
import argparse
import numpy as np

RESULTS = r"C:\Users\Anurag Tiwari\OneDrive\Desktop\Motor Imagery Classification-Work\results"
OUT = os.path.join(RESULTS, "stats_tables")


# --------------------------- core statistics ---------------------------
def bootstrap_ci(x, n=5000, alpha=0.05, seed=0):
    x = np.asarray([v for v in x if np.isfinite(v)], float)
    if len(x) == 0:
        return np.nan, np.nan, np.nan
    rng = np.random.default_rng(seed)
    bs = x[rng.integers(0, len(x), size=(n, len(x)))].mean(1)
    lo, hi = np.quantile(bs, [alpha / 2, 1 - alpha / 2])
    return float(x.mean()), float(lo), float(hi)


def paired_permutation(a, b, n=10000, seed=0):
    """Two-sided paired permutation test by sign-flipping paired differences.
    a, b: per-subject scores on the SAME subjects. Returns (mean_diff, p, dz)."""
    a, b = np.asarray(a, float), np.asarray(b, float)
    d = a - b
    d = d[np.isfinite(d)]
    if len(d) < 2:
        return float(np.mean(d)) if len(d) else np.nan, np.nan, np.nan
    obs = d.mean()
    rng = np.random.default_rng(seed)
    signs = rng.choice([-1.0, 1.0], size=(n, len(d)))
    perm = (signs * d).mean(1)
    p = float((int((np.abs(perm) >= abs(obs) - 1e-12).sum()) + 1) / (n + 1))
    dz = float(obs / (d.std(ddof=1) + 1e-12))
    return float(obs), p, dz


def sign_test_vs_chance(acc, chance=0.5, n=10000, seed=0):
    n_perm_total = n
    """One-sample permutation of accuracies against chance by sign-flipping the
    centered scores. acc: per-subject accuracies (fraction). Returns (mean, p)."""
    a = np.asarray(acc, float)
    a = a[np.isfinite(a)]
    if len(a) < 2:
        return float(a.mean()) if len(a) else np.nan, np.nan
    d = a - chance
    obs = d.mean()
    rng = np.random.default_rng(seed)
    signs = rng.choice([-1.0, 1.0], size=(n, len(d)))
    perm = (signs * d).mean(1)
    b = int((perm >= obs - 1e-12).sum())
    p = (b + 1) / (n_perm_total + 1)                 # (b+1)/(B+1), avoids p=0
    return float(a.mean()), float(p)


def extra_metrics(y_true, y_pred):
    from sklearn.metrics import (balanced_accuracy_score, f1_score,
                                 matthews_corrcoef, accuracy_score)
    yt, yp = np.asarray(y_true), np.asarray(y_pred)
    return {
        "acc": float(accuracy_score(yt, yp)),
        "bal_acc": float(balanced_accuracy_score(yt, yp)),
        "f1": float(f1_score(yt, yp, average="macro")),
        "mcc": float(matthews_corrcoef(yt, yp)) if len(np.unique(yt)) > 1 else 0.0,
    }




def holm_bonferroni(pvals, alpha=0.05):
    """Holm-Bonferroni step-down correction. Returns (adjusted, reject) arrays."""
    import numpy as np
    p = np.asarray(pvals, float); n = len(p)
    order = np.argsort(p); adj = np.empty(n)
    run = 0.0
    for k, idx in enumerate(order):
        val = min(1.0, (n - k) * p[idx]); run = max(run, val); adj[idx] = run
    return adj, adj < alpha

# --------------------------- table augmentation ---------------------------
def _read(name):
    p = os.path.join(RESULTS, name)
    if not os.path.exists(p):
        return None, []
    lines = open(p).read().splitlines()
    return lines[0].split(","), [l.split(",") for l in lines[1:] if l.strip()]


def _write(name, text):
    os.makedirs(OUT, exist_ok=True)
    with open(os.path.join(OUT, name), "w") as f:
        f.write(text + "\n")


def matrix_with_ci():
    h, rows = _read("t_pairs.csv")
    if not rows:
        return
    out = ["source,target,mean,ci_lo,ci_hi,p_vs_chance,n"]
    srcs = sorted({r[0] for r in rows}); tgts = sorted({r[1] for r in rows})
    for s in srcs:
        for t in tgts:
            v = [float(r[3]) for r in rows if r[0] == s and r[1] == t]
            if not v:
                continue
            m, lo, hi = bootstrap_ci(v)
            _, p = sign_test_vs_chance(v)
            out.append(f"{s},{t},{m*100:.2f},{lo*100:.2f},{hi*100:.2f},{p:.4f},{len(v)}")
    # Holm-Bonferroni over the direction p-values
    ps = [float(l.split(",")[5]) for l in out[1:] if l]
    adj, rej = holm_bonferroni(ps)
    out2 = [out[0].replace(",n", ",p_holm,sig_holm,n")]
    j = 0
    for l in out[1:]:
        parts = l.split(",")
        parts.insert(6, f"{adj[j]:.4f}"); parts.insert(7, str(bool(rej[j])))
        out2.append(",".join(parts)); j += 1
    _write("matrix_ci.csv", "\n".join(out2))
    print(f"  matrix_ci.csv: {len(out)-1} directions with 95% CI and p-vs-chance")


def conditions_with_stats():
    h, rows = _read("t_conditions.csv")
    if not rows:
        return
    # per-subject accuracy per condition, keyed by (target,subject)
    conds = sorted({r[2] for r in rows})
    by = {}
    for r in rows:
        by.setdefault(r[2], {})[(r[0], r[1])] = float(r[3])
    out = ["condition,mean,ci_lo,ci_hi,n"]
    for c in conds:
        v = list(by[c].values())
        m, lo, hi = bootstrap_ci(v)
        out.append(f"{c},{m*100:.2f},{lo*100:.2f},{hi*100:.2f},{len(v)}")
    # paired comparisons vs no-alignment baseline
    out.append("")
    out.append("comparison,delta,p_paired,dz")
    base = "none_lr_1"
    for c in conds:
        if c == base or base not in by:
            continue
        keys = sorted(set(by[c]) & set(by[base]))
        if not keys:
            continue
        a = [by[c][k] for k in keys]; b = [by[base][k] for k in keys]
        d, p, dz = paired_permutation(a, b)
        out.append(f"{c}_vs_{base},{d*100:+.2f},{p:.4f},{dz:+.2f}")
    _write("conditions_stats.csv", "\n".join(out))
    print(f"  conditions_stats.csv: per-condition CI + paired tests vs {base}")


def sources_fewshot_with_ci():
    for name, kcol, header in [("t_sources.csv", "sources", "sources"),
                               ("t_fewshot.csv", "shots", "shots")]:
        h, rows = _read(name)
        if not rows:
            continue
        ki = h.index(kcol); ti = h.index("target"); ai = h.index("acc")
        out = [f"target,{header},mean,ci_lo,ci_hi,n"]
        for t in sorted({r[ti] for r in rows}):
            for k in sorted({r[ki] for r in rows if r[ti] == t}):
                v = [float(r[ai]) for r in rows if r[ti] == t and r[ki] == k]
                m, lo, hi = bootstrap_ci(v)
                out.append(f"{t},{k},{m*100:.2f},{lo*100:.2f},{hi*100:.2f},{len(v)}")
        _write(name.replace("t_", "").replace(".csv", "_ci.csv"), "\n".join(out))
        print(f"  {name}: per-cell 95% CI written")


def run():
    matrix_with_ci()
    conditions_with_stats()
    sources_fewshot_with_ci()
    print(f"\n  stats tables in {OUT}")


# --------------------------- self-test ---------------------------
def _selftest():
    rng = np.random.default_rng(0)
    # bootstrap CI brackets the mean
    x = rng.normal(0.65, 0.08, 40)
    m, lo, hi = bootstrap_ci(x); assert lo <= m <= hi
    # paired permutation: strong positive effect -> small p, positive dz
    a = rng.normal(0.63, 0.05, 30); b = a - 0.06
    d, p, dz = paired_permutation(a, b)
    assert d > 0.05 and p < 0.01 and dz > 1.0, (d, p, dz)
    # no effect -> large p
    _, p0, _ = paired_permutation(a, a + rng.normal(0, 0.001, 30))
    assert p0 > 0.05
    # sign test vs chance: clearly above -> small p
    _, pc = sign_test_vs_chance(rng.normal(0.62, 0.05, 30)); assert pc < 0.01
    _, pc0 = sign_test_vs_chance(rng.normal(0.50, 0.05, 30)); assert pc0 > 0.05
    # extra metrics
    yt = np.array([0, 0, 1, 1, 0, 1]); yp = np.array([0, 1, 1, 1, 0, 0])
    m = extra_metrics(yt, yp)
    assert set(m) == {"acc", "bal_acc", "f1", "mcc"} and -1 <= m["mcc"] <= 1
    # table augmentation on synthetic CSV
    import tempfile
    global RESULTS, OUT
    RESULTS = tempfile.mkdtemp(); OUT = os.path.join(RESULTS, "st")
    with open(os.path.join(RESULTS, "t_pairs.csv"), "w") as f:
        f.write("source,target,subject,acc\n")
        for s in ["2a", "2b"]:
            for t in ["2a", "2b"]:
                if s == t:
                    continue
                for sub in range(1, 8):
                    f.write(f"{s},{t},{sub},{0.6+0.05*rng.standard_normal():.4f}\n")
    with open(os.path.join(RESULTS, "t_conditions.csv"), "w") as f:
        f.write("target,subject,cond,acc\n")
        for c, mu in [("none_lr_1", .57), ("ra_lr_1", .63)]:
            for sub in range(1, 8):
                f.write(f"2b,{sub},{c},{mu+0.03*rng.standard_normal():.4f}\n")
    matrix_with_ci(); conditions_with_stats()
    assert os.path.exists(os.path.join(OUT, "matrix_ci.csv"))
    assert os.path.exists(os.path.join(OUT, "conditions_stats.csv"))
    print("SELF-TEST PASSED: bootstrap CI, paired permutation (+dz), sign-test "
          "vs chance, balanced-acc/F1/MCC, and table augmentation all verified")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    if a.selftest:
        _selftest()
    else:
        run()
