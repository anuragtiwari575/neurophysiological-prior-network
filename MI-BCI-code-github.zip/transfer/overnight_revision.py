"""
Master overnight runner for the transfer-benchmark revision.

Runs, back to back and crash-safe, every experiment and analysis needed to
address the reviewer, then builds one consolidated MORNING SUMMARY. Launch once
and leave for the night; anything already computed is skipped, and a soft time
budget stops starting new stages after --hours.

Order:
  1 extended.factorial     full 3 x 2 x 2 alignment/backbone/source ablation
  2 extended.baselines     CSP+LDA vs Riemannian (and EEGNet if available)
  3 extended.upperbound    within-subject and leave-one-subject-out references
  4 extended.budget        equal-source-trial-budget scaling
  5 extended.fewshot       four few-shot protocols (zero, recal, refit, adapt)
  6 stats                  bootstrap CI, paired permutation, p-vs-chance, MCC
  7 analysis               domain distance vs transfer, asymmetry, alignment
                           shift, unlabeled source selection

Everything writes CSVs under results/; the summary is written to
results/revision_summary.txt. Set Power > Sleep = Never before launching.
American spelling, no em-dashes.
"""
from __future__ import annotations
import os
import sys
import time
import argparse
import datetime
import traceback
import numpy as np

RESULTS = r"C:\Users\Anurag Tiwari\OneDrive\Desktop\Motor Imagery Classification-Work\results"
LOG = os.path.join(RESULTS, "revision_log.txt")
SUMMARY = os.path.join(RESULTS, "revision_summary.txt")


def _log(msg):
    line = f"[{datetime.datetime.now():%Y-%m-%d %H:%M:%S}] {msg}"
    print(line, flush=True)
    os.makedirs(RESULTS, exist_ok=True)
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(line + "\n")


def _read(name):
    p = os.path.join(RESULTS, name)
    if not os.path.exists(p):
        return None, []
    lines = open(p).read().splitlines()
    return lines[0].split(","), [l.split(",") for l in lines[1:] if l.strip()]


STAGES = [
    ("factorial",  lambda: __import__("transfer_extended").exp_factorial()),
    ("baselines",  lambda: __import__("transfer_extended").exp_baselines()),
    ("upperbound", lambda: __import__("transfer_extended").exp_upperbound()),
    ("budget",     lambda: __import__("transfer_extended").exp_budget()),
    ("fewshot",    lambda: __import__("transfer_extended").exp_fewshot()),
    ("stats",      lambda: __import__("transfer_stats").run()),
    ("analysis",   lambda: __import__("transfer_analysis").run()),
]


def morning_summary():
    out = ["=" * 66, "REVISION SUMMARY  " +
           datetime.datetime.now().strftime("%Y-%m-%d %H:%M"), "=" * 66]

    # factorial main effects
    h, rows = _read("f_factorial.csv")
    if rows:
        out.append("\n[1] Factorial main effects (mean accuracy %)")
        def me(col, vals):
            i = h.index(col)
            for v in vals:
                a = [float(r[h.index('acc')]) for r in rows if r[i] == v]
                if a:
                    out.append(f"    {col}={v:<8} {np.mean(a)*100:6.2f}  (n={len(a)})")
        me("align", ["none", "ea", "ra"])
        me("backbone", ["mdm", "lr"])
        me("source", ["single", "multi"])

    h, rows = _read("f_baselines.csv")
    if rows:
        out.append("\n[2] Transfer baselines (mean accuracy %)")
        for m in sorted({r[2] for r in rows}):
            a = [float(r[3]) for r in rows if r[2] == m]
            out.append(f"    {m:<12} {np.mean(a)*100:6.2f}")

    h, rows = _read("f_upperbound.csv")
    if rows:
        out.append("\n[3] Within-dataset upper bound (mean accuracy %)")
        for proto in ["within", "loso"]:
            a = [float(r[3]) for r in rows if r[2] == proto]
            if a:
                out.append(f"    {proto:<8} {np.mean(a)*100:6.2f}")

    h, rows = _read("f_budget.csv")
    if rows:
        out.append("\n[4] Equal-budget source scaling (mean %)")
        for t in sorted({r[0] for r in rows}):
            line = f"    {t:<10} "
            for c in sorted({r[2] for r in rows if r[0] == t}, key=len):
                a = [float(r[3]) for r in rows if r[0] == t and r[2] == c]
                line += f"{c}:{np.mean(a)*100:.1f}  "
            out.append(line)

    h, rows = _read("f_fewshot.csv")
    if rows:
        out.append("\n[5] Few-shot protocols (mean %, pooled targets)")
        for proto in sorted({r[3] for r in rows}):
            for k in sorted({int(r[2]) for r in rows if r[3] == proto}):
                a = [float(r[4]) for r in rows if r[3] == proto and int(r[2]) == k]
                out.append(f"    {proto:<8} k={k:<3} {np.mean(a)*100:6.2f}")

    # stats + analysis pointers
    for f in ["stats_tables/matrix_ci.csv", "stats_tables/conditions_stats.csv",
              "analysis_tables/distance_vs_transfer.csv",
              "analysis_tables/source_selection.csv"]:
        p = os.path.join(RESULTS, f)
        if os.path.exists(p):
            out.append(f"\n[+] {f}:")
            for l in open(p).read().splitlines()[:8]:
                out.append("    " + l)

    text = "\n".join(out)
    print("\n" + text)
    with open(SUMMARY, "w", encoding="utf-8") as f:
        f.write(text + "\n")
    _log(f"summary written to {SUMMARY}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--hours", type=float, default=8.0)
    ap.add_argument("--stages", default=",".join(s for s, _ in STAGES))
    a = ap.parse_args()
    want = set(a.stages.split(","))
    t0 = time.time()
    _log(f"REVISION RUN START (budget {a.hours} h). Sleep = Never.")
    for label, fn in STAGES:
        if label not in want:
            continue
        if (time.time() - t0) / 3600.0 > a.hours:
            _log(f"time budget reached; skipping {label} and the rest"); break
        _log(f"STAGE START: {label}")
        try:
            fn(); _log(f"STAGE DONE : {label}")
        except Exception as e:
            _log(f"STAGE FAILED: {label} :: {e}")
            with open(LOG, "a", encoding="utf-8") as f:
                f.write(traceback.format_exc() + "\n")
    _log(f"ALL STAGES ATTEMPTED in {(time.time()-t0)/3600:.2f} h. Building summary.")
    try:
        morning_summary()
    except Exception as e:
        _log(f"summary failed: {e}")
    _log("REVISION RUN COMPLETE.")


if __name__ == "__main__":
    if "--selftest" in sys.argv:
        # summary reader over synthetic files
        import tempfile
        RESULTS = tempfile.mkdtemp()
        globals()["RESULTS"] = RESULTS
        SUMMARY = os.path.join(RESULTS, "s.txt"); globals()["SUMMARY"] = SUMMARY
        globals()["LOG"] = os.path.join(RESULTS, "log.txt")
        with open(os.path.join(RESULTS, "f_factorial.csv"), "w") as f:
            f.write("align,backbone,source,target,subject,acc\n")
            for al in ["none", "ea", "ra"]:
                f.write(f"{al},lr,single,2b,1,{0.57 if al=='none' else 0.63}\n")
        morning_summary()
        assert os.path.getsize(SUMMARY) > 50
        print("SELF-TEST PASSED: summary reader over synthetic factorial CSV")
    else:
        main()
