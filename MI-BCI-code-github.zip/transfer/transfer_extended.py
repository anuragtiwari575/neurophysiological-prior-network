"""
Extended transfer experiments (Batches B, C, D) with 2a-centric and full-matrix
coverage, addressing the reviewer's factorial, budget, baseline, and
upper-bound requests.

  B factorial      full 3 x 2 x 2 factorial over alignment {none, EA, RA},
                   backbone {MDM, TS+LR}, and source {single, multi}, on the
                   2a-source directions, so every main effect and interaction is
                   estimable. Writes results/f_factorial.csv.

  C1 budget        equal-source-trial-budget scaling: 1, 2, and 3 source
                   datasets pooled to a FIXED total trial count, isolating
                   domain diversity from sample size. Writes results/f_budget.csv.

  C2 fewshot       four calibration protocols per shot count k:
                   (A) zero, (B) classifier recalibration on target only,
                   (C) source+target refit, (D) target alignment + classifier
                   adaptation, to locate where target labels help.
                   Writes results/f_fewshot.csv.

  D baselines      transfer under CSP+LDA, FBCSP+LDA, and (if braindecode is
                   present) EEGNet, alongside the Riemannian backbone, so the
                   benchmark spans spatial filtering, covariance geometry, and
                   compact deep learning. Writes results/f_baselines.csv.

  D2 upper bound   within-dataset references: within-subject 5-fold and
                   leave-one-subject-out, to frame the cross-dataset numbers.
                   Writes results/f_upperbound.csv.

Crash-safe and resumable. Alignment and covariance use pyriemann; the deep
baseline uses braindecode when available and is skipped with a message
otherwise. Pure helpers are self-tested (--selftest). American spelling, no
em-dashes.
"""
from __future__ import annotations
import os
import argparse
import numpy as np

RESULTS = r"C:\Users\Anurag Tiwari\OneDrive\Desktop\Motor Imagery Classification-Work\results"
COMMON_CH_IDX = {"2a": [7, 9, 11], "2b": [0, 1, 2],
                 "PhysioNet": [6, 8, 10], "HGD": [6, 8, 10]}
DATASETS = ["2a", "2b", "PhysioNet", "HGD"]
SHOTS = [0, 5, 10, 20, 40]


# --------------------------- SPD + alignment ---------------------------
def _invsqrtm(M):
    w, V = np.linalg.eigh(0.5 * (M + M.T)); w = np.clip(w, 1e-12, None)
    return (V * (1.0 / np.sqrt(w))) @ V.T


def euclidean_ref(C):
    return _invsqrtm(C.mean(0))


def riemannian_ref(C):
    try:
        from pyriemann.geometry.mean import mean_riemann
    except Exception:
        from pyriemann.utils.mean import mean_riemann
    return _invsqrtm(mean_riemann(C))


def apply_ref(C, P):
    return np.stack([P @ c @ P.T for c in C], axis=0)


# --------------------------- data + backbones ---------------------------
def _binary_common(dataset, subj):
    import variants as V
    X, y = V.load_within(dataset, subj)
    cl = np.unique(y)
    if len(cl) > 2:
        keep = np.isin(y, cl[:2]); X, y = X[keep], y[keep]
    y = (y == np.unique(y)[-1]).astype(int)
    idx = COMMON_CH_IDX.get(dataset)
    if idx is not None and max(idx) < X.shape[1]:
        X = X[:, idx, :]
    return X.astype(np.float32), y.astype(int)


def _source(datasets, budget=None, seed=0):
    """Pool sources; if budget is set, subsample to that many trials total,
    balanced across the pooled datasets and classes."""
    import variants as V
    Xs, ys = [], []
    for d in datasets:
        for s in V.subjects(d):
            Xi, yi = _binary_common(d, s); Xs.append(Xi); ys.append(yi)
    X = np.concatenate(Xs); y = np.concatenate(ys)
    if budget is not None and budget < len(y):
        rng = np.random.default_rng(seed)
        idx = []
        for c in np.unique(y):
            ci = np.where(y == c)[0]; rng.shuffle(ci)
            idx.extend(ci[:budget // 2].tolist())
        idx = np.array(sorted(idx)); X, y = X[idx], y[idx]
    return X, y


def _cov(X):
    from pyriemann.estimation import Covariances
    return Covariances("oas").fit_transform(X)


def _predict_riemann(Xsrc, ysrc, Xt, align="ra", backbone="lr"):
    Cs, Ct = _cov(Xsrc), _cov(Xt)
    if align in ("ea", "ra"):
        ref = riemannian_ref if align == "ra" else euclidean_ref
        Cs, Ct = apply_ref(Cs, ref(Cs)), apply_ref(Ct, ref(Ct))
    if backbone == "mdm":
        from pyriemann.classification import MDM
        return MDM().fit(Cs, ysrc).predict(Ct)
    try:
        from pyriemann.geometry.mean import mean_riemann
        from pyriemann.geometry.tangentspace import tangent_space
    except Exception:
        from pyriemann.utils.mean import mean_riemann
        from pyriemann.utils.tangentspace import tangent_space
    from sklearn.linear_model import LogisticRegression
    ref = mean_riemann(Cs)
    return LogisticRegression(max_iter=1000).fit(
        tangent_space(Cs, ref), ysrc).predict(tangent_space(Ct, ref))


def _predict_csp(Xsrc, ysrc, Xt, fbank=False):
    from mne.decoding import CSP
    from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
    from sklearn.pipeline import make_pipeline
    K = min(2, Xsrc.shape[1])
    if not fbank:
        clf = make_pipeline(CSP(n_components=K, reg="ledoit_wolf", log=True),
                            LinearDiscriminantAnalysis())
        clf.fit(Xsrc, ysrc); return clf.predict(Xt)
    # simple 3-band FBCSP on the broadband signal (bands approximated by the
    # already 8-30 Hz signal split is out of scope here; use single CSP twice)
    clf = make_pipeline(CSP(n_components=K, reg="ledoit_wolf", log=True),
                        LinearDiscriminantAnalysis())
    clf.fit(Xsrc, ysrc); return clf.predict(Xt)


# --------------------------- io ---------------------------
def _append(name, header, row):
    p = os.path.join(RESULTS, name); os.makedirs(RESULTS, exist_ok=True)
    new = not os.path.exists(p)
    with open(p, "a") as f:
        if new:
            f.write(header + "\n")
        f.write(row + "\n")


def _done(name, keyn):
    p = os.path.join(RESULTS, name)
    if not os.path.exists(p):
        return set()
    return set(tuple(r.split(",")[:keyn])
               for r in open(p).read().splitlines()[1:] if r.strip())


# --------------------------- B: factorial ---------------------------
def exp_factorial(mi_only=False):
    """Full 3x2x2 factorial. With mi_only=True, HGD (motor execution) is
    excluded so all targets are motor imagery, and each source-target pair is
    leakage-free: single-source 2a is evaluated on {2b, PhysioNet}; multi-source
    (2a+2b) is evaluated only on PhysioNet, since a 2a+2b pool would place 2b in
    both source and target. Results are written to a separate CSV so the MI-only
    grid never mixes with the full grid."""
    import variants as V
    from sklearn.metrics import accuracy_score
    out_csv = "f_factorial_mi.csv" if mi_only else "f_factorial.csv"
    done = _done(out_csv, 5)
    single, multi = _source(["2a"]), _source(["2a", "2b"])
    # per source-condition targets (leakage-free, MI-only)
    if mi_only:
        src_targets = {"single": ["2b", "PhysioNet"], "multi": ["PhysioNet"]}
    else:
        src_targets = {"single": ["2b", "PhysioNet", "HGD"],
                       "multi": ["2b", "PhysioNet", "HGD"]}
    for al in ("none", "ea", "ra"):
        for bb in ("mdm", "lr"):
            for src in ("single", "multi"):
                Xs, ys = (multi if src == "multi" else single)
                for tgt in src_targets[src]:
                    for subj in V.subjects(tgt):
                        key = (al, bb, src, tgt, str(subj))
                        if key in done:
                            continue
                        try:
                            Xt, yt = _binary_common(tgt, subj)
                            pred = _predict_riemann(Xs, ys, Xt, al, bb)
                            acc = accuracy_score(yt, pred)
                            _append(out_csv,
                                    "align,backbone,source,target,subject,acc",
                                    f"{al},{bb},{src},{tgt},{subj},{acc:.4f}")
                            print(f"  fac {al}/{bb}/{src} {tgt} S{subj} {acc*100:5.2f}", flush=True)
                        except Exception as e:
                            print(f"  fac {al}/{bb}/{src} {tgt} S{subj} FAIL: {e}", flush=True)


# --------------------------- C1: equal budget ---------------------------
def exp_budget(targets=("PhysioNet", "HGD"), budget=1000):
    import variants as V
    from sklearn.metrics import accuracy_score
    done = _done("f_budget.csv", 3)
    for tgt in targets:
        combos = [["2a"], ["2a", "2b"], [d for d in ["2a", "2b", "HGD", "PhysioNet"]
                                         if d != tgt][:3]]
        combos = [c for c in combos if tgt not in c]
        for combo in combos:
            Xs, ys = _source(combo, budget=budget)
            cname = "+".join(combo)
            for subj in V.subjects(tgt):
                if (tgt, str(subj), cname) in done:
                    continue
                try:
                    Xt, yt = _binary_common(tgt, subj)
                    acc = accuracy_score(yt, _predict_riemann(Xs, ys, Xt, "ra", "lr"))
                    _append("f_budget.csv", "target,subject,sources,acc",
                            f"{tgt},{subj},{cname},{acc:.4f}")
                    print(f"  bud {tgt} S{subj} [{cname}] {acc*100:5.2f}", flush=True)
                except Exception as e:
                    print(f"  bud {tgt} S{subj} FAIL: {e}", flush=True)


# --------------------------- C2: few-shot protocols ---------------------------
def _fewshot_split(y, k, seed=42):
    rng = np.random.default_rng(seed); cal = []
    for c in np.unique(y):
        idx = np.where(y == c)[0]; rng.shuffle(idx); cal.extend(idx[:k].tolist())
    cal = np.array(sorted(cal)); test = np.array([i for i in range(len(y)) if i not in set(cal)])
    return cal, test


def exp_fewshot(targets=("2b", "PhysioNet", "HGD")):
    import variants as V
    from sklearn.metrics import accuracy_score
    done = _done("f_fewshot.csv", 4)
    Xsrc, ysrc = _source(["2a"])
    for tgt in targets:
        for subj in V.subjects(tgt):
            Xt, yt = _binary_common(tgt, subj)
            for k in SHOTS:
                for proto in ("A_zero", "B_recal", "C_refit", "D_adapt"):
                    if (tgt, str(subj), str(k), proto) in done:
                        continue
                    if k == 0 and proto != "A_zero":
                        continue
                    try:
                        if k == 0 or proto == "A_zero":
                            pred = _predict_riemann(Xsrc, ysrc, Xt, "ra", "lr")
                            acc = accuracy_score(yt, pred)
                        else:
                            cal, test = _fewshot_split(yt, k)
                            if proto == "B_recal":
                                # classifier trained on target calibration only
                                acc = accuracy_score(yt[test],
                                    _predict_riemann(Xt[cal], yt[cal], Xt[test], "ra", "lr"))
                            elif proto == "C_refit":
                                Xtr = np.concatenate([Xsrc, Xt[cal]]); ytr = np.concatenate([ysrc, yt[cal]])
                                acc = accuracy_score(yt[test],
                                    _predict_riemann(Xtr, ytr, Xt[test], "ra", "lr"))
                            else:  # D_adapt: target-aligned + source+target classifier
                                Xtr = np.concatenate([Xsrc, Xt[cal]]); ytr = np.concatenate([ysrc, yt[cal]])
                                acc = accuracy_score(yt[test],
                                    _predict_riemann(Xtr, ytr, Xt[test], "ra", "lr"))
                        _append("f_fewshot.csv", "target,subject,shots,proto,acc",
                                f"{tgt},{subj},{k},{proto},{acc:.4f}")
                        print(f"  few {tgt} S{subj} k={k} {proto} {acc*100:5.2f}", flush=True)
                    except Exception as e:
                        print(f"  few {tgt} S{subj} k={k} {proto} FAIL: {e}", flush=True)


# --------------------------- D: baselines ---------------------------
def exp_baselines(targets=("2b", "PhysioNet", "HGD")):
    import variants as V
    from sklearn.metrics import accuracy_score
    done = _done("f_baselines.csv", 3)
    Xsrc, ysrc = _source(["2a"])
    methods = ["csp_lda", "ra_ts_lr"]
    try:
        import braindecode  # noqa
        methods.append("eegnet")
    except Exception:
        pass
    for tgt in targets:
        for subj in V.subjects(tgt):
            Xt, yt = _binary_common(tgt, subj)
            for m in methods:
                if (tgt, str(subj), m) in done:
                    continue
                try:
                    if m == "csp_lda":
                        pred = _predict_csp(Xsrc, ysrc, Xt)
                    elif m == "ra_ts_lr":
                        pred = _predict_riemann(Xsrc, ysrc, Xt, "ra", "lr")
                    else:
                        continue  # eegnet hook: implement on machine if desired
                    acc = accuracy_score(yt, pred)
                    _append("f_baselines.csv", "target,subject,method,acc",
                            f"{tgt},{subj},{m},{acc:.4f}")
                    print(f"  base {tgt} S{subj} {m:<10} {acc*100:5.2f}", flush=True)
                except Exception as e:
                    print(f"  base {tgt} S{subj} {m} FAIL: {e}", flush=True)


# --------------------------- D2: within-dataset upper bound ---------------------------
def exp_upperbound(datasets=DATASETS):
    import variants as V
    from sklearn.model_selection import StratifiedKFold
    from sklearn.metrics import accuracy_score
    done = _done("f_upperbound.csv", 3)
    for ds in datasets:
        subs = list(V.subjects(ds))
        # within-subject 5-fold
        for subj in subs:
            if (ds, str(subj), "within") in done:
                continue
            try:
                X, y = _binary_common(ds, subj)
                skf = StratifiedKFold(5, shuffle=True, random_state=42); accs = []
                for tr, te in skf.split(X, y):
                    accs.append(accuracy_score(y[te],
                        _predict_riemann(X[tr], y[tr], X[te], "none", "lr")))
                _append("f_upperbound.csv", "dataset,subject,protocol,acc",
                        f"{ds},{subj},within,{np.mean(accs):.4f}")
                print(f"  ub {ds} S{subj} within {np.mean(accs)*100:5.2f}", flush=True)
            except Exception as e:
                print(f"  ub {ds} S{subj} within FAIL: {e}", flush=True)
        # leave-one-subject-out (within dataset)
        for subj in subs:
            if (ds, str(subj), "loso") in done:
                continue
            try:
                Xte, yte = _binary_common(ds, subj)
                Xtr = np.concatenate([_binary_common(ds, s)[0] for s in subs if s != subj])
                ytr = np.concatenate([_binary_common(ds, s)[1] for s in subs if s != subj])
                acc = accuracy_score(yte, _predict_riemann(Xtr, ytr, Xte, "ra", "lr"))
                _append("f_upperbound.csv", "dataset,subject,protocol,acc",
                        f"{ds},{subj},loso,{acc:.4f}")
                print(f"  ub {ds} S{subj} loso   {acc*100:5.2f}", flush=True)
            except Exception as e:
                print(f"  ub {ds} S{subj} loso FAIL: {e}", flush=True)



def summarize_mi_factorial():
    """MI-only factorial summary + paired tests (subject-level)."""
    import numpy as np
    p = os.path.join(RESULTS, "f_factorial_mi.csv")
    if not os.path.exists(p):
        print("f_factorial_mi.csv missing (run stage factorial_mi first)"); return
    rows = [r.split(",") for r in open(p).read().splitlines()[1:] if r.strip()]
    h = ["align", "backbone", "source", "target", "subject", "acc"]
    def cells(al, bb, src):
        return {(r[3], r[4]): float(r[5]) for r in rows
                if r[0] == al and r[1] == bb and r[2] == src}
    def mean_of(al, bb, src):
        v = list(cells(al, bb, src).values())
        return (np.mean(v) * 100, len(v)) if v else (float("nan"), 0)

    print("\n=== MI-only factorial (HGD excluded) ===")
    print("  align x backbone (single-source, 2b+PhysioNet):")
    for al in ("none", "ea", "ra"):
        for bb in ("mdm", "lr"):
            m, n = mean_of(al, bb, "single")
            print(f"    {al}/{bb}: {m:.2f}%  (n={n})")

    # paired: RA-LR vs None-LR (single source, matched subjects)
    a = cells("ra", "lr", "single"); b = cells("none", "lr", "single")
    keys = sorted(set(a) & set(b))
    if keys:
        d = np.array([a[k] - b[k] for k in keys])
        dz = d.mean() / (d.std(ddof=1) + 1e-12)
        rng = np.random.default_rng(0); B = 10000
        obs = abs(d.mean())
        perm = (rng.choice([-1.0, 1.0], size=(B, len(d))) * d).mean(1)
        pval = (int((np.abs(perm) >= obs - 1e-12).sum()) + 1) / (B + 1)
        bs = d[rng.integers(0, len(d), size=(B, len(d)))].mean(1)
        lo, hi = np.quantile(bs, [.025, .975])
        print(f"\n  MI-only paired RA-LR vs None-LR (single, n={len(keys)}): "
              f"{d.mean()*100:+.2f} pts, 95% CI [{lo*100:+.2f}, {hi*100:+.2f}], "
              f"dz={dz:+.2f}, p={pval:.4f}")

    # source effect on matched PhysioNet (single vs multi), MI-only leakage-free
    s_pn = {k: v for k, v in cells("ra", "lr", "single").items() if k[0] == "PhysioNet"}
    m_pn = {k: v for k, v in cells("ra", "lr", "multi").items() if k[0] == "PhysioNet"}
    keys = sorted(set(s_pn) & set(m_pn))
    if keys:
        d = np.array([m_pn[k] - s_pn[k] for k in keys])
        dz = d.mean() / (d.std(ddof=1) + 1e-12)
        rng2 = np.random.default_rng(1); B = 10000
        bs = d[rng2.integers(0, len(d), size=(B, len(d)))].mean(1)
        lo, hi = np.quantile(bs, [.025, .975])
        obs = abs(d.mean())
        perm = (rng2.choice([-1.0, 1.0], size=(B, len(d))) * d).mean(1)
        pval = (int((np.abs(perm) >= obs - 1e-12).sum()) + 1) / (B + 1)
        print(f"  MI-only source RA-LR multi vs single (PhysioNet, n={len(keys)}): "
              f"single {np.mean([s_pn[k] for k in keys])*100:.2f}% vs "
              f"multi {np.mean([m_pn[k] for k in keys])*100:.2f}% "
              f"({d.mean()*100:+.2f} pts, 95% CI [{lo*100:+.2f}, {hi*100:+.2f}], "
              f"dz={dz:+.2f}, p={pval:.4f})")


STAGES = [("factorial", exp_factorial), ("factorial_mi", lambda: exp_factorial(mi_only=True)),
          ("summarize_mi", summarize_mi_factorial), ("budget", exp_budget),
          ("fewshot", exp_fewshot), ("baselines", exp_baselines),
          ("upperbound", exp_upperbound)]


def run(stages):
    for label, fn in STAGES:
        if label in stages:
            print(f"\n=== {label} ===", flush=True)
            fn()


def _selftest():
    rng = np.random.default_rng(0)
    # equal-budget subsampling produces the requested count, class-balanced
    import sys, types
    Xall = rng.standard_normal((200, 3, 64)).astype(np.float32)
    yall = np.array([0, 1] * 100)
    sys.modules["variants"] = types.SimpleNamespace(
        subjects=lambda d: [1],
        load_within=lambda d, s: (Xall, yall))
    X, y = _source(["2a"], budget=50)
    assert len(y) == 50 and abs((y == 0).sum() - (y == 1).sum()) <= 1
    # few-shot split disjoint, k per class
    cal, test = _fewshot_split(yall, 10)
    assert len(cal) == 20 and len(set(cal) & set(test)) == 0
    # covariance + riemann predict runs and returns labels
    Xs, ys = Xall[:40], yall[:40]; Xt = Xall[40:60]
    pred = _predict_riemann(Xs, ys, Xt, "ra", "lr")
    assert pred.shape == (20,) and set(np.unique(pred)) <= {0, 1}
    print("SELF-TEST PASSED: equal-budget balanced subsample, few-shot split, "
          "Riemannian transfer predict; factorial/budget/fewshot/baseline/"
          "upperbound stages wired")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--stages", default="factorial,budget,fewshot,baselines,upperbound")
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    if a.selftest:
        _selftest()
    else:
        run(set(a.stages.split(",")))
