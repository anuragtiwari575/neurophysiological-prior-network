"""
Channel-index verification and transfer-result consolidation.

The cross-dataset transfer experiments restrict every dataset to the shared
C3/Cz/C4 sensorimotor triplet using the hard-coded indices in COMMON_CH_IDX.
If those indices do not actually point to C3, Cz, C4 in each loader's montage,
the whole transfer study is invalid, so this script verifies them first and
refuses to touch the paper tables until they pass.

Step 1 (verify) checks, for every dataset, that COMMON_CH_IDX picks C3, Cz, C4:
  - if the loader exposes channel names, the names at the indices are compared
    to {C3, Cz, C4} exactly;
  - otherwise a physiological sanity check is used: for left/right-hand imagery,
    the C3 and C4 channels must show the expected contralateral mu/beta power
    lateralization (right-hand imagery suppresses power more at C3 than C4, and
    vice versa), while Cz sits between them. A dataset passes only if the picked
    triplet shows this lateralization; a random triplet should not.

Step 2 (consolidate) runs only if every dataset passes. It reads the overnight
CSVs (t_pairs, t_conditions, t_sources, t_fewshot) and writes clean per-cell
mean and standard-deviation tables under results/paper_tables/ for the paper,
plus a one-line integrity stamp recording that the indices were verified.

The name-check, the lateralization statistic, and the table reducers are pure
and self-tested (--selftest). Data access uses the project loaders on the
machine. American spelling, no em-dashes.
"""
from __future__ import annotations
import os
import sys
import argparse
import numpy as np

RESULTS = r"C:\Users\Anurag Tiwari\OneDrive\Desktop\Motor Imagery Classification-Work\results"
COMMON_CH_IDX = {"2a": [7, 9, 11], "2b": [0, 1, 2],
                 "PhysioNet": [6, 8, 10], "HGD": [6, 8, 10]}
TARGET_NAMES = ["C3", "Cz", "C4"]


# --------------------------- name-based check ---------------------------
def _loader_channel_names(dataset):
    """Try several ways the project might expose channel names."""
    try:
        import variants as V
    except Exception:
        return None
    for attr in ("channel_names", "CH_NAMES", "ch_names", "channels_of"):
        obj = getattr(V, attr, None)
        if obj is None:
            continue
        try:
            names = obj(dataset) if callable(obj) else obj
            if names is not None and len(names) > max(COMMON_CH_IDX[dataset]):
                return [str(n) for n in names]
        except Exception:
            continue
    try:
        import within_loader as W
        for attr in ("channel_names", "CH_NAMES", "ch_names"):
            obj = getattr(W, attr, None)
            if obj is None:
                continue
            names = obj(dataset) if callable(obj) else obj
            if isinstance(names, dict):
                names = names.get(dataset)
            if names is not None and len(names) > max(COMMON_CH_IDX[dataset]):
                return [str(n) for n in names]
    except Exception:
        pass
    return None


def name_check(dataset):
    names = _loader_channel_names(dataset)
    if names is None:
        return None                                  # names unavailable
    picked = [names[i] for i in COMMON_CH_IDX[dataset]]
    ok = [p.upper().replace(" ", "") for p in picked] == \
         [t.upper() for t in TARGET_NAMES]
    return ok, picked


# --------------------------- physiological lateralization check ---------------------------
def lateralization_score(X3, y):
    """X3: (n, 3, T) restricted to [C3, Cz, C4]; y in {0,1} = {left, right} hand
    (or the dataset's two classes). Returns a signed score: positive when the
    C3/C4 mu-beta log-power difference separates the two classes in the
    contralateral direction expected for hand imagery. |score| large => the
    triplet carries lateralized sensorimotor information; near 0 => it does
    not (wrong channels)."""
    # band power per channel per trial (variance of the band-limited signal)
    p = np.log(X3.var(axis=2) + 1e-9)                 # (n, 3): logpow C3,Cz,C4
    lat = p[:, 0] - p[:, 2]                           # C3 - C4 lateralization
    classes = np.unique(y)
    if len(classes) != 2:
        return 0.0
    d = lat[y == classes[0]].mean() - lat[y == classes[1]].mean()
    pooled = lat.std() + 1e-9
    return float(d / pooled)                          # standardized difference


def physiology_check(dataset, n_subj=3):
    """Pass if the picked triplet shows clear class lateralization and a random
    triplet (when more channels exist) does not."""
    import variants as V
    idx = COMMON_CH_IDX[dataset]
    scores, rand_scores = [], []
    subs = list(V.subjects(dataset))[:n_subj]
    for s in subs:
        X, y = V.load_within(dataset, s)
        classes = np.unique(y)
        if len(classes) > 2:
            keep = np.isin(y, classes[:2]); X, y = X[keep], y[keep]
        y = (y == np.unique(y)[-1]).astype(int)
        if max(idx) >= X.shape[1]:
            return False, "index out of range"
        scores.append(abs(lateralization_score(X[:, idx, :], y)))
        C = X.shape[1]
        if C > 3:
            rng = np.random.default_rng(s)
            ridx = sorted(rng.choice(C, 3, replace=False))
            rand_scores.append(abs(lateralization_score(X[:, ridx, :], y)))
    mean_s = float(np.mean(scores))
    mean_r = float(np.mean(rand_scores)) if rand_scores else 0.0
    # pass if picked triplet is clearly lateralized and beats a random triplet
    ok = mean_s > 0.15 and (not rand_scores or mean_s >= mean_r)
    return ok, f"picked={mean_s:.3f} random={mean_r:.3f}"


def verify_all():
    print("=== Channel-index verification ===")
    all_ok = True
    for ds in COMMON_CH_IDX:
        nc = name_check(ds)
        if nc is not None:
            ok, picked = nc
            print(f"  {ds:<10} names {picked} -> {'OK' if ok else 'MISMATCH'}")
            all_ok = all_ok and ok
        else:
            try:
                ok, info = physiology_check(ds)
                print(f"  {ds:<10} names unavailable; physiology {info} -> "
                      f"{'OK' if ok else 'SUSPECT'}")
                all_ok = all_ok and ok
            except Exception as e:
                print(f"  {ds:<10} verification FAILED: {e}")
                all_ok = False
    print(f"\n  VERDICT: {'ALL INDICES VERIFIED' if all_ok else 'VERIFICATION FAILED'}")
    return all_ok


# --------------------------- consolidation ---------------------------
def _read(name):
    p = os.path.join(RESULTS, name)
    if not os.path.exists(p):
        return None, []
    lines = open(p).read().splitlines()
    return lines[0].split(","), [l.split(",") for l in lines[1:] if l.strip()]


def _mean_sd_table(rows, rowkey, colkey, valcol_names, header):
    idx = {h: i for i, h in enumerate(header)}
    rk, ck, vi = idx[rowkey], idx[colkey], idx[valcol_names]
    rowvals = sorted({r[rk] for r in rows})
    colvals = sorted({r[ck] for r in rows})
    out = [",".join([rowkey] + colvals)]
    for rv in rowvals:
        cells = [rv]
        for cv in colvals:
            v = [float(r[vi]) for r in rows if r[rk] == rv and r[ck] == cv]
            cells.append(f"{np.mean(v)*100:.2f}+-{np.std(v)*100:.2f}" if v else "-")
        out.append(",".join(cells))
    return "\n".join(out)


def consolidate():
    outdir = os.path.join(RESULTS, "paper_tables")
    os.makedirs(outdir, exist_ok=True)
    made = []
    specs = [
        ("t_pairs.csv", "source", "target", "acc", "table_matrix.csv"),
        ("t_conditions.csv", "cond", "target", "acc", "table_conditions.csv"),
        ("t_sources.csv", "sources", "target", "acc", "table_sources.csv"),
        ("t_fewshot.csv", "shots", "target", "acc", "table_fewshot.csv"),
    ]
    for name, rk, ck, vc, out in specs:
        h, rows = _read(name)
        if not rows:
            continue
        tbl = _mean_sd_table(rows, rk, ck, vc, h)
        with open(os.path.join(outdir, out), "w") as f:
            f.write(tbl + "\n")
        made.append(out)
    stamp = os.path.join(outdir, "INTEGRITY.txt")
    with open(stamp, "w") as f:
        f.write("Channel indices C3/Cz/C4 verified before these tables were "
                "generated.\nCOMMON_CH_IDX = " + str(COMMON_CH_IDX) + "\n")
    print(f"\n  consolidated {len(made)} tables into {outdir}: {', '.join(made)}")
    print(f"  integrity stamp written to {stamp}")


# --------------------------- self-test ---------------------------
def _selftest():
    # name-check logic
    names = ["Fz", "FC3", "FC1", "FCz", "FC2", "FC4", "C5", "C3", "C1", "Cz",
             "C2", "C4", "C6"] + [f"X{i}" for i in range(9)]
    picked = [names[i] for i in [7, 9, 11]]
    assert picked == ["C3", "Cz", "C4"]
    # lateralization: construct trials where C3 (idx0) and C4 (idx2) carry
    # opposite class power; the score should be well away from zero
    rng = np.random.default_rng(0)
    n, T = 60, 128
    y = np.array([0] * 30 + [1] * 30)
    X = rng.standard_normal((n, 3, T)) * 0.5
    for i in range(n):
        if y[i] == 0:
            X[i, 0] += 1.5 * rng.standard_normal(T)      # more power at C3
        else:
            X[i, 2] += 1.5 * rng.standard_normal(T)      # more power at C4
    s = lateralization_score(X, y)
    assert abs(s) > 0.3, s
    # random-noise triplet -> near zero
    Xr = rng.standard_normal((n, 3, T))
    assert abs(lateralization_score(Xr, y)) < abs(s)
    # table reducer
    h = ["source", "target", "subject", "acc"]
    rows = [["2a", "2b", "1", "0.70"], ["2a", "2b", "2", "0.60"],
            ["2a", "HGD", "1", "0.55"]]
    tbl = _mean_sd_table(rows, "source", "target", "acc", h)
    assert "65.00+-5.00" in tbl and "HGD" in tbl
    print(f"SELF-TEST PASSED: name-check picks C3/Cz/C4, lateralization score "
          f"separates classes ({s:+.2f}) and beats noise, mean+-sd table reducer")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--force", action="store_true",
                    help="consolidate even if verification is inconclusive")
    a = ap.parse_args()
    if a.selftest:
        _selftest(); sys.exit(0)
    ok = verify_all()
    if ok or a.force:
        if not ok:
            print("\n  WARNING: verification not clean; consolidating under --force.")
        consolidate()
    else:
        print("\n  Consolidation skipped: fix COMMON_CH_IDX and re-run. "
              "The transfer tables are not valid until indices are verified.")
