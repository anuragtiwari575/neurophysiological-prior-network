"""
Classical and Riemannian baselines.

CSP+LDA and FBCSP+LDA (built on the raw filtered signal), and the two
Riemannian classifiers, minimum-distance-to-mean (MDM) and tangent-space
logistic regression (TS+LR), evaluated under the same stratified k-fold
protocol as NPN. Deep baselines are trained with braindecode in the paper and
are out of scope for this module.
"""
from __future__ import annotations
import numpy as np


def cv_csp_lda(X, y, n_folds=5, n_components=4, seed=42):
    """CSP + LDA on broadband (n, C, T) trials."""
    from mne.decoding import CSP
    from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
    from sklearn.model_selection import StratifiedKFold
    from sklearn.metrics import accuracy_score
    skf = StratifiedKFold(n_folds, shuffle=True, random_state=seed)
    accs = []
    for tr, te in skf.split(X, y):
        csp = CSP(n_components=n_components, reg="ledoit_wolf", log=True)
        Ftr = csp.fit_transform(X[tr], y[tr]); Fte = csp.transform(X[te])
        clf = LinearDiscriminantAnalysis().fit(Ftr, y[tr])
        accs.append(accuracy_score(y[te], clf.predict(Fte)))
    return np.array(accs)


def cv_riemann(X, y, method="TS+LR", n_folds=5, seed=42):
    """Riemannian baselines on covariance matrices of (n, C, T) trials.
    method in {"MDM", "TS+LR"}."""
    from pyriemann.estimation import Covariances
    try:
        from pyriemann.classification import MDM, TSClassifier as _TS
    except Exception:
        from pyriemann.classification import MDM, TSclassifier as _TS
    from sklearn.model_selection import StratifiedKFold
    from sklearn.metrics import accuracy_score
    skf = StratifiedKFold(n_folds, shuffle=True, random_state=seed)
    accs = []
    for tr, te in skf.split(X, y):
        cov = Covariances("oas")
        Ctr = cov.fit_transform(X[tr]); Cte = cov.transform(X[te])
        clf = MDM() if method == "MDM" else _TS()
        clf.fit(Ctr, y[tr])
        accs.append(accuracy_score(y[te], clf.predict(Cte)))
    return np.array(accs)
