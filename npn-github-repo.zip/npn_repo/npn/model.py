"""
Neurophysiologically-Primed Network (NPN).

A compact multi-band convolutional motor-imagery decoder whose per-band spatial
layer is initialized from Common Spatial Pattern (CSP) filters and refined end
to end. The architecture follows the paper:

  input (B bands, C channels, T samples)
    -> per-band spatial conv (C, 1) -> K_s maps, CSP-initialized
    -> concat over bands -> BatchNorm -> ELU
    -> wide temporal conv (1, k_t)   -> BatchNorm -> ELU -> AvgPool(1, p1) -> Dropout
    -> depthwise-separable temporal conv (1, k_s) -> BatchNorm -> ELU -> AvgPool(1, p2) -> Dropout
    -> flatten -> linear -> logits

The squared-response average pooling is a differentiable estimator of band
power and is the learned counterpart of the CSP log-variance feature.

The spatial layers can be initialized with `init_spatial(band_filters)` (CSP)
or left at the default random initialization; a `freeze_spatial` flag supports
the CSP-frozen control experiment. See the paper's Methods section.
"""
from __future__ import annotations
import numpy as np

try:
    import torch
    import torch.nn as nn
    _HAS_TORCH = True
    _Base = nn.Module
except Exception:                # torch optional for non-model unit tests
    _HAS_TORCH = False
    _Base = object


class NPN(_Base):
    def __init__(self, n_classes: int, n_channels: int, n_bands: int,
                 k_spatial: int = 4, temporal_filters: int = 16,
                 k_t: int = 32, k_s: int = 16, pool1: int = 4, pool2: int = 8,
                 dropout: float = 0.5):
        super().__init__()
        self.n_bands = n_bands
        self.n_channels = n_channels
        self.k_spatial = k_spatial
        # one spatial conv per band: (1 -> k_spatial), kernel spans all channels
        self.spatials = nn.ModuleList([
            nn.Conv2d(1, k_spatial, (n_channels, 1), bias=False)
            for _ in range(n_bands)
        ])
        merged = n_bands * k_spatial
        self.bn0 = nn.BatchNorm2d(merged)
        self.temporal1 = nn.Conv2d(merged, temporal_filters, (1, k_t),
                                   padding=(0, k_t // 2), bias=False)
        self.bn1 = nn.BatchNorm2d(temporal_filters)
        self.pool1 = nn.AvgPool2d((1, pool1))
        self.drop1 = nn.Dropout(dropout)
        # depthwise-separable temporal conv
        self.depthwise = nn.Conv2d(temporal_filters, temporal_filters, (1, k_s),
                                   padding=(0, k_s // 2), groups=temporal_filters,
                                   bias=False)
        self.pointwise = nn.Conv2d(temporal_filters, temporal_filters, (1, 1),
                                   bias=False)
        self.bn2 = nn.BatchNorm2d(temporal_filters)
        self.pool2 = nn.AvgPool2d((1, pool2))
        self.drop2 = nn.Dropout(dropout)
        self.elu = nn.ELU()
        self._classifier = None
        self._n_classes = n_classes

    def init_spatial(self, band_filters):
        """Initialize each band's spatial conv from its CSP filters.
        band_filters[b] is an array of shape (>=k_spatial, n_channels)."""
        with torch.no_grad():
            for b, filt in enumerate(band_filters):
                f = np.asarray(filt, dtype=np.float32)[:self.k_spatial]
                w = torch.tensor(f).view(self.k_spatial, 1, self.n_channels, 1)
                self.spatials[b].weight.copy_(w)

    def init_spatial_random(self):
        for m in self.spatials:
            nn.init.xavier_uniform_(m.weight)

    def freeze_spatial(self, frozen: bool = True):
        for m in self.spatials:
            m.weight.requires_grad_(not frozen)

    def _forward_features(self, x):
        # x: (N, B, C, T)
        maps = []
        for b in range(self.n_bands):
            xb = x[:, b:b + 1]                       # (N, 1, C, T)
            maps.append(self.spatials[b](xb))        # (N, k_spatial, 1, T)
        z = torch.cat(maps, dim=1)                   # (N, merged, 1, T)
        z = self.elu(self.bn0(z))
        z = self.elu(self.bn1(self.temporal1(z)))
        z = self.drop1(self.pool1(z))
        z = self.pointwise(self.depthwise(z))
        z = self.elu(self.bn2(z))
        # squared-response average pool = differentiable band-power estimate
        z = self.drop2(self.pool2(z * z))
        return torch.flatten(z, 1)

    def forward(self, x):
        feats = self._forward_features(x)
        if self._classifier is None:
            self._classifier = nn.Linear(feats.shape[1], self._n_classes).to(feats.device)
        return self._classifier(feats)
