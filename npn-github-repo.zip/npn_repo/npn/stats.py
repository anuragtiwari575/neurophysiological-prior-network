"""
Statistical analysis for the benchmark.

Implements the hierarchical (nested) bootstrap that resamples subjects within
each dataset, a pooled Wilcoxon signed-rank test with Holm correction, and the
paired effect size (Cohen's dz), as used in the paper. Subjects are the unit of
resampling and datasets the unit of nesting; trials are never treated as
independent.
"""
from __future__ import annotations
import numpy as np


def hierarchical_bootstrap(diffs_by_dataset, n=5000, alpha=0.05, seed=0):
    """diffs_by_dataset: dict dataset -> array of per-subject paired diffs.
    Returns (mean, lo, hi) of the dataset-balanced grand mean difference."""
    rng = np.random.default_rng(seed)
    dsets = [d for d, v in diffs_by_dataset.items() if len(v) > 0]
    if not dsets:
        return np.nan, np.nan, np.nan
    boots = np.empty(n)
    for b in range(n):
        per = []
        for d in dsets:
            v = np.asarray(diffs_by_dataset[d], float)
            per.append(v[rng.integers(0, len(v), len(v))].mean())
        boots[b] = np.mean(per)
    obs = np.mean([np.mean(diffs_by_dataset[d]) for d in dsets])
    lo, hi = np.quantile(boots, [alpha / 2, 1 - alpha / 2])
    return float(obs), float(lo), float(hi)


def cohens_dz(diffs):
    d = np.asarray(diffs, float)
    return float(d.mean() / d.std(ddof=1)) if len(d) > 1 and d.std(ddof=1) > 0 else 0.0


def wilcoxon_holm(pairs):
    """pairs: dict name -> (a, b) arrays of paired per-subject accuracies.
    Returns dict name -> Holm-corrected p-value of the signed-rank test."""
    from scipy.stats import wilcoxon
    raw = {}
    for name, (a, b) in pairs.items():
        a, b = np.asarray(a, float), np.asarray(b, float)
        try:
            raw[name] = wilcoxon(a, b).pvalue
        except Exception:
            raw[name] = np.nan
    order = sorted([k for k in raw if np.isfinite(raw[k])], key=lambda k: raw[k])
    m = len(order); out = dict(raw)
    prev = 0.0
    for i, k in enumerate(order):
        adj = min(1.0, (m - i) * raw[k])
        prev = max(prev, adj)
        out[k] = prev
    return out
