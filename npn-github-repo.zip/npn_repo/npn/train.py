"""
Training and cross-validation for NPN.

`cross_validate` runs stratified k-fold CV of the model under one of three
initialization conditions: "csp" (CSP-initialized, trainable), "random"
(random-initialized, trainable), or "frozen" (CSP-initialized, spatial layer
frozen). All conditions share the identical objective, augmentation, optimizer,
and early-stopping protocol so that any difference is attributable to
initialization, following the paper's controlled design.

CSP filters are recomputed on the training partition of each fold (no leakage).
"""
from __future__ import annotations
import numpy as np

try:
    import torch
    import torch.nn as nn
    _HAS_TORCH = True
except Exception:
    _HAS_TORCH = False

from .model import NPN
from .csp import band_csp_filters
from .data import augment_segrecomb


def _device():
    return "cuda" if (_HAS_TORCH and torch.cuda.is_available()) else "cpu"


def train_one(Xtr, ytr, Xva, yva, n_classes, init="csp", k_spatial=4,
              epochs=500, patience=75, lr=1e-3, batch=16, aug_factor=3.0,
              seed=42):
    """Train a single NPN and return (model, best_val_acc)."""
    from sklearn.metrics import accuracy_score
    dev = _device()
    torch.manual_seed(seed); np.random.seed(seed)
    try:
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    except Exception:
        pass
    n, B, C, T = Xtr.shape
    k = min(k_spatial, C)
    model = NPN(n_classes, C, B, k_spatial=k).to(dev)
    if init in ("csp", "frozen"):
        model.init_spatial(band_csp_filters(Xtr, ytr, k))
        if init == "frozen":
            # build classifier lazily first, then freeze spatial
            with torch.no_grad():
                model(torch.tensor(Xtr[:2], dtype=torch.float32, device=dev))
            model.freeze_spatial(True)
    else:
        model.init_spatial_random()

    Xa, ya = augment_segrecomb(Xtr.reshape(n, B * C, T), ytr,
                               factor=aug_factor, seed=seed)
    Xa = Xa.reshape(len(ya), B, C, T)

    def t(a, d):
        return torch.tensor(np.asarray(a), dtype=d, device=dev)

    with torch.no_grad():
        model(t(Xa[:2], torch.float32))
    params = [p for p in model.parameters() if p.requires_grad]
    opt = torch.optim.Adam(params, lr=lr)
    ce = nn.CrossEntropyLoss()
    LX, Ly = t(Xa, torch.float32), t(ya, torch.long)
    Xv = t(Xva, torch.float32)
    best, best_state, wait = -1.0, None, 0
    for _ in range(epochs):
        model.train()
        perm = torch.randperm(len(Ly))
        for i in range(0, len(perm), batch):
            idx = perm[i:i + batch]
            opt.zero_grad()
            ce(model(LX[idx]), Ly[idx]).backward()
            opt.step()
        model.eval()
        with torch.no_grad():
            va = accuracy_score(yva, model(Xv).argmax(1).cpu().numpy())
        if va > best:
            best, wait = va, 0
            best_state = {kk: v.detach().cpu().clone()
                          for kk, v in model.state_dict().items()}
        else:
            wait += 1
            if wait >= patience:
                break
    if best_state is not None:
        model.load_state_dict(best_state)
    return model, best


def cross_validate(Xs, y, n_classes, init="csp", n_folds=5, frac=1.0,
                   epochs=500, seed=42):
    """Stratified k-fold CV. Xs: (n, B, C, T). Returns per-fold accuracies."""
    from sklearn.model_selection import StratifiedKFold, train_test_split
    from sklearn.metrics import accuracy_score
    dev = _device()
    skf = StratifiedKFold(n_folds, shuffle=True, random_state=seed)
    accs = []
    for tr, te in skf.split(np.zeros(len(y)), y):
        Xtr, ytr, Xte, yte = Xs[tr], y[tr], Xs[te], y[te]
        if frac < 1.0:
            keep, _ = train_test_split(np.arange(len(ytr)), train_size=frac,
                                       stratify=ytr, random_state=seed)
            Xtr, ytr = Xtr[keep], ytr[keep]
        ti, vi = train_test_split(np.arange(len(ytr)), test_size=0.15,
                                  stratify=ytr, random_state=seed)
        model, _ = train_one(Xtr[ti], ytr[ti], Xtr[vi], ytr[vi], n_classes,
                             init=init, epochs=epochs, seed=seed)
        model.eval()
        with torch.no_grad():
            pred = model(torch.tensor(Xte, dtype=torch.float32,
                                      device=dev)).argmax(1).cpu().numpy()
        accs.append(accuracy_score(yte, pred))
    return np.array(accs)
