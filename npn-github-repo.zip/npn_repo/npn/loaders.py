"""
Dataset loaders.

Each loader returns raw epoched trials `X` of shape
(n_trials, n_channels, n_samples), band-pass filtered to 8-30 Hz, and integer
labels `y`, for one subject. The four datasets used in the paper are public but
have different formats and licenses, so the concrete reading code is left as a
thin adapter that you point at your local copy. Fill in the four functions
below; everything downstream (band decomposition, CSP, training, experiments)
is dataset-agnostic.

DATASET_INFO documents the paper's configuration. `load_subject` dispatches by
dataset name and returns (X, y, fs).
"""
from __future__ import annotations
import numpy as np

DATASET_INFO = {
    "2a":        {"channels": 22, "classes": 4, "fs": 250, "subjects": list(range(1, 10))},
    "2b":        {"channels": 3,  "classes": 2, "fs": 250, "subjects": list(range(1, 10))},
    "PhysioNet": {"channels": 17, "classes": 2, "fs": 160, "subjects": list(range(1, 21))},
    "HGD":       {"channels": 17, "classes": 2, "fs": 250, "subjects": list(range(1, 15))},
}

# Exact nested channel sets for the BCI-IV-2a channel-count intervention.
CHANNEL_SETS_2A = {
    22: ["Fz", "FC3", "FC1", "FCz", "FC2", "FC4", "C5", "C3", "C1", "Cz",
         "C2", "C4", "C6", "CP3", "CP1", "CPz", "CP2", "CP4", "P1", "Pz", "P2", "POz"],
    16: ["FC3", "FC1", "FCz", "FC2", "FC4", "C3", "C1", "Cz", "C2", "C4",
         "C6", "CP3", "CP1", "CPz", "CP2", "CP4"],
    12: ["FC3", "FCz", "FC4", "C3", "C1", "Cz", "C2", "C4", "C6", "CP3", "CPz", "CP4"],
    8:  ["FC3", "FC4", "C3", "Cz", "C4", "CP3", "CPz", "CP4"],
    6:  ["FC3", "FC4", "C3", "Cz", "C4", "CPz"],
    4:  ["C3", "Cz", "C4", "CPz"],
    3:  ["C3", "Cz", "C4"],
}


def _not_implemented(name):
    raise NotImplementedError(
        f"Fill in load_{name}() in npn/loaders.py: return (X, y) for a subject, "
        f"X of shape (n_trials, n_channels, n_samples) band-pass 8-30 Hz, y integer "
        f"labels. See DATASET_INFO['{name}'] for the expected configuration."
    )


def load_2a(subject, root):
    """BCI Competition IV 2a (22 ch, 4 class, 250 Hz). GDF files."""
    _not_implemented("2a")


def load_2b(subject, root):
    """BCI Competition IV 2b (3 ch, 2 class, 250 Hz)."""
    _not_implemented("2b")


def load_physionet(subject, root):
    """PhysioNet EEGMMIDB, left/right hand on 17-ch sensorimotor montage."""
    _not_implemented("PhysioNet")


def load_hgd(subject, root):
    """High-Gamma dataset, left/right hand on 17-ch sensorimotor montage."""
    _not_implemented("HGD")


def load_subject(dataset, subject, root):
    fs = DATASET_INFO[dataset]["fs"]
    if dataset == "2a":
        X, y = load_2a(subject, root)
    elif dataset == "2b":
        X, y = load_2b(subject, root)
    elif dataset == "PhysioNet":
        X, y = load_physionet(subject, root)
    elif dataset == "HGD":
        X, y = load_hgd(subject, root)
    else:
        raise ValueError(dataset)
    return np.asarray(X, np.float32), np.asarray(y), fs
