"""
Common Spatial Pattern (CSP) prior.

Computes the class-discriminative spatial filters used to initialize the NPN
spatial layer, following the generalized-eigenvalue formulation with
Ledoit-Wolf shrinkage and a one-versus-rest extension for multiclass problems.
This mirrors the paper's Methods: the filters are estimated on the training
partition only.

The public entry point is `band_csp_filters(Xs, y, k)`, which returns one
filter matrix per band, suitable for `NPN.init_spatial`.
"""
from __future__ import annotations
import numpy as np

try:
    from mne.decoding import CSP as _MNE_CSP
    _HAS_MNE = True
except Exception:
    _HAS_MNE = False


def _shrinkage_cov(X):
    """Ledoit-Wolf shrunk covariance of trials X (n, C, T), averaged."""
    n, C, T = X.shape
    covs = np.empty((n, C, C))
    for i in range(n):
        x = X[i]
        s = x @ x.T
        s /= np.trace(s) + 1e-12
        covs[i] = s
    S = covs.mean(0)
    mu = np.trace(S) / C
    target = mu * np.eye(C)
    # simple shrinkage coefficient (bounded)
    num = np.mean([(np.linalg.norm(covs[i] - S, "fro") ** 2) for i in range(n)])
    den = np.linalg.norm(S - target, "fro") ** 2 + 1e-12
    gamma = float(np.clip(num / (n * den), 0.0, 1.0))
    return (1 - gamma) * S + gamma * target


def csp_filters_binary(Xa, Xb, k):
    """Top/bottom k CSP filters separating class-a from class-b trials.
    Xa, Xb: (n, C, T). Returns (2k or k, C) filter rows."""
    Sa = _shrinkage_cov(Xa)
    Sb = _shrinkage_cov(Xb)
    Sc = Sa + Sb
    # whiten composite
    w, U = np.linalg.eigh(Sc)
    w = np.clip(w, 1e-10, None)
    P = (U * (1.0 / np.sqrt(w))) @ U.T
    M = P @ Sa @ P.T
    psi, R = np.linalg.eigh(M)
    order = np.argsort(psi)
    W = (R.T @ P)                                    # (C, C) rows = filters
    W = W[order]
    idx = list(range(k)) + list(range(len(W) - k, len(W)))
    return W[idx]


def band_csp_filters(Xs, y, k):
    """CSP filters per band. Xs: (n, B, C, T), y: (n,). Uses MNE when available
    (log-variance, one-vs-rest for multiclass), else a numpy binary fallback."""
    n, B, C, T = Xs.shape
    classes = np.unique(y)
    filters = []
    for b in range(B):
        Xb = Xs[:, b]
        if _HAS_MNE:
            c = _MNE_CSP(n_components=min(k, C), reg="ledoit_wolf", log=True)
            c.fit(Xb, y)
            filters.append(c.filters_[:k])
        else:
            if len(classes) == 2:
                fa = Xb[y == classes[0]]; fb = Xb[y == classes[1]]
                filters.append(csp_filters_binary(fa, fb, max(1, k // 2)))
            else:                                    # one-vs-rest, stack
                rows = []
                for cl in classes:
                    fa = Xb[y == cl]; fb = Xb[y != cl]
                    rows.append(csp_filters_binary(fa, fb, 1)[:1])
                filters.append(np.vstack(rows)[:k])
    return filters
