"""
Data utilities for NPN: band decomposition, normalization, augmentation, and a
lightweight dataset-agnostic loader interface.

The four datasets in the paper (BCI-IV-2a, BCI-IV-2b, PhysioNet EEGMMIDB,
High-Gamma) are read by user-supplied loaders that return raw epoched trials
`X` of shape (n_trials, n_channels, n_samples) band-pass filtered to 8-30 Hz
and integer labels `y`. This module turns those into the multi-band tensor the
model consumes and provides the segmentation-recombination augmentation.

`FILTER_BANK` is the eight-band bank used in the paper.
"""
from __future__ import annotations
import numpy as np

try:
    from scipy.signal import butter, sosfiltfilt
    _HAS_SCIPY = True
except Exception:
    _HAS_SCIPY = False

FILTER_BANK = [(4, 8), (8, 12), (12, 16), (16, 20),
               (20, 24), (24, 28), (28, 32), (8, 30)]


def bandpass(X, lo, hi, fs, order=4):
    """Zero-phase Butterworth band-pass on (n, C, T)."""
    if not _HAS_SCIPY:
        return X.astype(np.float32)
    sos = butter(order, [lo, hi], btype="bandpass", fs=fs, output="sos")
    return sosfiltfilt(sos, X, axis=-1).astype(np.float32)


def to_bands(X, fs, bank=FILTER_BANK):
    """(n, C, T) -> (n, B, C, T) by filtering into each sub-band."""
    return np.stack([bandpass(X, lo, hi, fs) for lo, hi in bank], axis=1)


def zscore_per_trial(X):
    """Per-trial z-score used for deep baselines; NPN uses raw filtered input."""
    m = X.mean(axis=-1, keepdims=True)
    s = X.std(axis=-1, keepdims=True) + 1e-7
    return ((X - m) / s).astype(np.float32)


def augment_segrecomb(X, y, factor=3.0, n_segments=8, seed=42):
    """Segmentation-recombination augmentation on (n, C, T).
    Splits each trial into `n_segments` contiguous parts and builds synthetic
    same-class trials by concatenating segments from different donors of the
    class. Returns (X_aug, y_aug) including the originals."""
    rng = np.random.default_rng(seed)
    n, C, T = X.shape
    seg = T // n_segments
    n_new = int(round((factor - 1.0) * n))
    outX = [X]; outY = [y]
    classes = np.unique(y)
    by = {c: np.where(y == c)[0] for c in classes}
    synth = np.empty((n_new, C, T), dtype=X.dtype)
    synY = np.empty(n_new, dtype=y.dtype)
    for i in range(n_new):
        c = classes[i % len(classes)]
        idxs = by[c]
        parts = []
        for s in range(n_segments):
            donor = idxs[rng.integers(0, len(idxs))]
            a = s * seg
            b = T if s == n_segments - 1 else (s + 1) * seg
            parts.append(X[donor, :, a:b])
        synth[i] = np.concatenate(parts, axis=-1)[:, :T]
        synY[i] = c
    outX.append(synth); outY.append(synY)
    return np.concatenate(outX, 0), np.concatenate(outY, 0)


def subsample_channels(n_channels, keep):
    """Nested, reproducible channel subset spread across the montage."""
    if keep >= n_channels:
        return list(range(n_channels))
    idx = np.linspace(0, n_channels - 1, keep)
    return sorted(set(int(round(i)) for i in idx))[:keep]
