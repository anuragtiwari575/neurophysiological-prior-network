"""Neurophysiologically-Primed Network (NPN) for motor-imagery EEG decoding."""
from .csp import band_csp_filters
from .data import to_bands, augment_segrecomb, subsample_channels, FILTER_BANK
try:
    from .model import NPN
    from .train import train_one, cross_validate
except Exception:                # torch not installed: model/train unavailable
    NPN = None
    train_one = cross_validate = None

__version__ = "1.0.0"
__all__ = ["NPN", "band_csp_filters", "to_bands", "augment_segrecomb",
           "subsample_channels", "FILTER_BANK", "train_one", "cross_validate"]
