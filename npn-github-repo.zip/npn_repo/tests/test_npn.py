"""Unit tests for the NPN package (torch-optional parts + stats)."""
import numpy as np
import pytest
from npn.data import to_bands, augment_segrecomb, subsample_channels, FILTER_BANK
from npn.csp import band_csp_filters, csp_filters_binary
from npn.stats import hierarchical_bootstrap, cohens_dz


def test_bands_shape():
    X = np.random.default_rng(0).standard_normal((10, 8, 128)).astype("float32")
    Xb = to_bands(X, fs=128)
    assert Xb.shape == (10, len(FILTER_BANK), 8, 128)


def test_augment_preserves_labels_and_grows():
    rng = np.random.default_rng(0)
    X = rng.standard_normal((20, 4, 96)).astype("float32")
    y = rng.integers(0, 2, 20)
    Xa, ya = augment_segrecomb(X, y, factor=3.0, seed=1)
    assert len(ya) == 60 and Xa.shape[1:] == X.shape[1:]
    assert set(np.unique(ya)) <= set(np.unique(y))


def test_subsample_nested_and_sized():
    for k in (16, 12, 8, 6, 4, 3):
        idx = subsample_channels(22, k)
        assert len(idx) == k and max(idx) < 22 and idx == sorted(set(idx))
    assert subsample_channels(3, 6) == [0, 1, 2]


def test_csp_binary_shapes():
    rng = np.random.default_rng(0)
    Xa = rng.standard_normal((15, 6, 80)); Xb = rng.standard_normal((15, 6, 80)) * 2
    W = csp_filters_binary(Xa, Xb, k=2)
    assert W.shape[1] == 6 and W.shape[0] == 4


def test_band_csp_filters_count():
    rng = np.random.default_rng(0)
    X = rng.standard_normal((24, 3, 6, 80)).astype("float32")
    y = rng.integers(0, 2, 24)
    filt = band_csp_filters(X, y, k=2)
    assert len(filt) == 3


def test_hierarchical_bootstrap_ci_brackets_mean():
    d = {"a": np.array([5., 6., 4.5, 5.5, 6.5]), "b": np.array([4., 5., 6.])}
    m, lo, hi = hierarchical_bootstrap(d, n=2000)
    assert lo <= m <= hi and lo > 0


def test_cohens_dz_sign():
    assert cohens_dz([1, 2, 3]) > 0 and cohens_dz([1, 1, 1]) == 0.0


def test_model_forward_if_torch():
    torch = pytest.importorskip("torch")
    from npn.model import NPN
    m = NPN(n_classes=4, n_channels=8, n_bands=3, k_spatial=2)
    x = torch.randn(5, 3, 8, 64)
    out = m(x)
    assert out.shape == (5, 4)


def test_model_init_spatial_if_torch():
    torch = pytest.importorskip("torch")
    from npn.model import NPN
    m = NPN(n_classes=2, n_channels=6, n_bands=2, k_spatial=2)
    filt = [np.random.randn(2, 6).astype("float32") for _ in range(2)]
    m.init_spatial(filt)
    w = m.spatials[0].weight.detach().numpy().reshape(2, 6)
    assert np.allclose(w, filt[0][:2], atol=1e-5)
