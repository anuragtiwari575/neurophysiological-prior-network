"""
Regenerate the paper figures from the result CSVs, using the model name NPN.

  fig_channel_scaling   prior gain vs channel count (channels.csv)
  fig_data_efficiency   accuracy vs training fraction (efficiency.csv)
  fig_mean_rank         mean rank over the benchmark methods (benchmark.csv)
  fig_main_accuracy     grouped accuracy bars (benchmark.csv)

Usage: python scripts/make_figures.py --results results --out figures
"""
import os
import argparse
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({"font.size": 11, "axes.titlesize": 12, "axes.titleweight": "bold",
                     "axes.spines.top": False, "axes.spines.right": False,
                     "axes.grid": True, "grid.color": "#DDDDDD", "grid.linewidth": 0.7})
C_MAIN, C_CLASSIC, C_OTHER = "#2E5A87", "#5B8AB5", "#B0B0B0"


def _save(fig, out, name):
    os.makedirs(out, exist_ok=True)
    for ext in ("pdf", "png"):
        fig.savefig(os.path.join(out, f"{name}.{ext}"), dpi=300, bbox_inches="tight")
    plt.close(fig)


def channel_scaling(results, out):
    p = os.path.join(results, "channels.csv")
    if not os.path.exists(p):
        return
    d = pd.read_csv(p); d = d[d.dataset == "2a"]
    g = d.groupby("channels")["prior_gain"].agg(["mean", "std", "count"]).sort_index()
    sem = g["std"] / np.sqrt(g["count"].clip(lower=1))
    x, ym, e = g.index.values, g["mean"].values * 100, sem.values * 100
    fig, ax = plt.subplots(figsize=(6.2, 4.4))
    ax.axhline(0, color="#888", ls=":", lw=0.8)
    ax.errorbar(x, ym, yerr=e, marker="o", ms=7, lw=2.2, color=C_MAIN, capsize=4)
    ax.set_xticks(sorted(x)); ax.invert_xaxis()
    ax.set_xlabel("Number of channels"); ax.set_ylabel("Prior gain (points)")
    ax.set_title("Prior gain vs channel count (2a)")
    _save(fig, out, "fig_channel_scaling")


def data_efficiency(results, out):
    p = os.path.join(results, "efficiency.csv")
    if not os.path.exists(p):
        return
    d = pd.read_csv(p); d = d[d.dataset == "2a"]
    piv = d.groupby(["frac", "init"])["acc"].mean().unstack() * 100
    fig, ax = plt.subplots(figsize=(6.2, 4.4))
    ax.plot(piv.index * 100, piv["csp"], "o-", color=C_MAIN, lw=2.2, label="CSP-init")
    ax.plot(piv.index * 100, piv["random"], "o-", color=C_OTHER, lw=2.2, label="Random-init")
    if 1.0 in piv.index:
        ax.axhline(piv.loc[1.0, "random"], ls="--", color="#C44E52", lw=1.4,
                   label=f"Random-init at 100% ({piv.loc[1.0,'random']:.1f}%)")
    ax.set_xlabel("Training data used (percent)"); ax.set_ylabel("Accuracy (percent)")
    ax.set_title("Data efficiency of the prior (2a)")
    ax.legend(fontsize=8.5, frameon=False, loc="lower right")
    _save(fig, out, "fig_data_efficiency")


def mean_rank(results, out):
    p = os.path.join(results, "benchmark.csv")
    if not os.path.exists(p):
        return
    d = pd.read_csv(p); d["acc"] = d["acc"] * 100
    piv = d.pivot_table(index=["dataset", "subject"], columns="method", values="acc")
    ranks = piv.rank(axis=1, ascending=False).mean(0).sort_values()
    m, rk = ranks.index.tolist(), ranks.values
    colors = [C_MAIN if x == "NPN" else (C_CLASSIC if x in ("FBCSP", "CSP") else C_OTHER) for x in m]
    fig, ax = plt.subplots(figsize=(6.4, 4.4))
    y = np.arange(len(m))[::-1]
    ax.barh(y, rk, color=colors, edgecolor="#333", linewidth=0.5)
    for yi, r in zip(y, rk):
        ax.text(r + 0.06, yi, f"{r:.2f}", va="center", fontsize=8.5)
    ax.set_yticks(y); ax.set_yticklabels(m, fontsize=9)
    ax.set_xlabel("Mean rank (lower is better)"); ax.set_title("Overall mean rank")
    _save(fig, out, "fig_mean_rank")


def main_accuracy(results, out):
    p = os.path.join(results, "benchmark.csv")
    if not os.path.exists(p):
        return
    d = pd.read_csv(p); d["acc"] = d["acc"] * 100
    dsets = [x for x in ["2a", "2b", "PhysioNet", "HGD"] if x in d.dataset.unique()]
    piv = d.groupby(["method", "dataset"])["acc"].mean().unstack()
    meths = piv.mean(1).sort_values().index.tolist()
    meths = [m for m in meths if m != "NPN"] + ["NPN"]
    x = np.arange(len(dsets)); w = 0.8 / max(len(meths), 1)
    fig, ax = plt.subplots(figsize=(9, 4.6))
    for i, me in enumerate(meths):
        c = C_MAIN if me == "NPN" else (C_CLASSIC if me in ("FBCSP", "CSP") else None)
        ax.bar(x + (i - len(meths) / 2) * w, [piv.loc[me, dd] for dd in dsets], w,
               label=me, color=c, edgecolor="#333", linewidth=0.3)
    ax.set_xticks(x); ax.set_xticklabels(dsets); ax.set_ylim(0, 100)
    ax.set_ylabel("Accuracy (percent)"); ax.set_title("Within-subject accuracy")
    ax.legend(ncol=4, fontsize=7, loc="upper center", bbox_to_anchor=(0.5, -0.12), frameon=False)
    _save(fig, out, "fig_main_accuracy")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default="results")
    ap.add_argument("--out", default="figures")
    a = ap.parse_args()
    channel_scaling(a.results, a.out)
    data_efficiency(a.results, a.out)
    mean_rank(a.results, a.out)
    main_accuracy(a.results, a.out)
    print("figures written to", a.out)
