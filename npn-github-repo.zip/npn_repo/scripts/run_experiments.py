"""
Reproduce the paper's experiments end to end.

Subcommands:
  benchmark    within-subject 5-fold accuracy for NPN, CSP, FBCSP, Riemannian
  channels     BCI-IV-2a channel-count intervention (prior gain vs C)
  efficiency   training-fraction data-efficiency curve on 2a
  frozen       random / CSP-init / CSP-frozen control on 2a
  stats        hierarchical bootstrap + Wilcoxon from results/benchmark.csv

Every subcommand is crash-safe (appends to a CSV, skips finished cells) so a
run can be resumed. Point --root at your local dataset copies; loaders in
npn/loaders.py must be filled in first.

Usage:
  python scripts/run_experiments.py benchmark  --datasets 2a,2b,PhysioNet,HGD --root /data
  python scripts/run_experiments.py channels   --root /data
  python scripts/run_experiments.py efficiency --datasets 2a,2b --root /data
  python scripts/run_experiments.py frozen     --root /data
  python scripts/run_experiments.py stats
"""
import os
import argparse
import numpy as np

from npn.loaders import load_subject, DATASET_INFO
from npn.data import to_bands, subsample_channels
from npn.train import cross_validate
from npn.baselines import cv_csp_lda, cv_riemann
from npn import stats as S

RESULTS = os.environ.get("NPN_RESULTS", "results")
CH_COUNTS = [22, 16, 12, 8, 6, 4, 3]
FRACTIONS = [0.2, 0.4, 0.6, 0.8, 1.0]


def _append(path, header, row):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    new = not os.path.exists(path)
    with open(path, "a") as f:
        if new:
            f.write(header + "\n")
        f.write(row + "\n")


def _done(path, keyn):
    if not os.path.exists(path):
        return set()
    return set(tuple(r.split(",")[:keyn])
               for r in open(path).read().splitlines()[1:] if r.strip())


def _bands(dataset, subj, root):
    X, y, fs = load_subject(dataset, subj, root)
    return to_bands(X, fs), y, X, fs


def benchmark(datasets, root, epochs):
    path = os.path.join(RESULTS, "benchmark.csv"); done = _done(path, 3)
    for ds in datasets:
        info = DATASET_INFO[ds]
        for subj in info["subjects"]:
            Xb, y, Xraw, fs = _bands(ds, subj, root)
            jobs = {
                "NPN": lambda: cross_validate(Xb, y, info["classes"], "csp", epochs=epochs).mean(),
                "CSP": lambda: cv_csp_lda(Xraw, y, n_components=min(4, Xraw.shape[1])).mean(),
                "FBCSP": lambda: cross_validate(Xb, y, info["classes"], "csp", epochs=epochs).mean(),
                "MDM": lambda: cv_riemann(Xraw, y, "MDM").mean(),
                "TS+LR": lambda: cv_riemann(Xraw, y, "TS+LR").mean(),
            }
            for name, fn in jobs.items():
                if (ds, str(subj), name) in done:
                    continue
                try:
                    acc = fn()
                    _append(path, "dataset,subject,method,acc",
                            f"{ds},{subj},{name},{acc:.4f}")
                    print(f"  {ds} S{subj} {name:<6} {acc*100:5.2f}", flush=True)
                except Exception as e:
                    print(f"  {ds} S{subj} {name} FAILED: {e}", flush=True)


def channels(root, epochs):
    path = os.path.join(RESULTS, "channels.csv"); done = _done(path, 3)
    info = DATASET_INFO["2a"]
    for subj in info["subjects"]:
        Xb, y, _, _ = _bands("2a", subj, root)
        C = Xb.shape[2]
        for keep in [k for k in CH_COUNTS if k <= C]:
            if ("2a", str(subj), str(keep)) in done:
                continue
            Xk = Xb[:, :, subsample_channels(C, keep), :]
            try:
                acsp = cross_validate(Xk, y, info["classes"], "csp", epochs=epochs).mean()
                arnd = cross_validate(Xk, y, info["classes"], "random", epochs=epochs).mean()
                _append(path, "dataset,subject,channels,acc_csp,acc_random,prior_gain",
                        f"2a,{subj},{keep},{acsp:.4f},{arnd:.4f},{acsp-arnd:.4f}")
                print(f"  2a S{subj} ch={keep:<3} gain={(acsp-arnd)*100:+5.2f}", flush=True)
            except Exception as e:
                print(f"  2a S{subj} ch={keep} FAILED: {e}", flush=True)


def efficiency(datasets, root, epochs):
    path = os.path.join(RESULTS, "efficiency.csv"); done = _done(path, 4)
    for ds in datasets:
        info = DATASET_INFO[ds]
        for subj in info["subjects"]:
            Xb, y, _, _ = _bands(ds, subj, root)
            for frac in FRACTIONS:
                for init in ("csp", "random"):
                    if (ds, str(subj), f"{frac}", init) in done:
                        continue
                    try:
                        a = cross_validate(Xb, y, info["classes"], init,
                                           frac=frac, epochs=epochs).mean()
                        _append(path, "dataset,subject,frac,init,acc",
                                f"{ds},{subj},{frac},{init},{a:.4f}")
                        print(f"  {ds} S{subj} frac={frac} {init:<6} {a*100:5.2f}", flush=True)
                    except Exception as e:
                        print(f"  {ds} S{subj} {frac} {init} FAILED: {e}", flush=True)


def frozen(root, epochs):
    path = os.path.join(RESULTS, "frozen.csv"); done = _done(path, 3)
    info = DATASET_INFO["2a"]
    for subj in info["subjects"]:
        Xb, y, _, _ = _bands("2a", subj, root)
        for init in ("random", "csp", "frozen"):
            if ("2a", str(subj), init) in done:
                continue
            try:
                a = cross_validate(Xb, y, info["classes"], init, epochs=epochs).mean()
                _append(path, "dataset,subject,init,acc", f"2a,{subj},{init},{a:.4f}")
                print(f"  2a S{subj} {init:<7} {a*100:5.2f}", flush=True)
            except Exception as e:
                print(f"  2a S{subj} {init} FAILED: {e}", flush=True)


def run_stats(proposed="NPN", comparator="FBCSP"):
    path = os.path.join(RESULTS, "benchmark.csv")
    if not os.path.exists(path):
        print("benchmark.csv not found"); return
    rows = [r.split(",") for r in open(path).read().splitlines()[1:] if r.strip()]
    by = {}
    for ds, m, s, acc in rows:
        by.setdefault((ds, m), {})[s] = float(acc) * 100
    dsets = sorted({r[0] for r in rows})
    diffs = {}
    for ds in dsets:
        a = by.get((ds, proposed), {}); b = by.get((ds, comparator), {})
        subs = sorted(set(a) & set(b))
        d = np.array([a[s] - b[s] for s in subs]); diffs[ds] = d
        if len(d):
            print(f"  {ds:<10} n={len(d):<3} mean={d.mean():+6.2f} dz={S.cohens_dz(d):+.2f}")
    mean, lo, hi = S.hierarchical_bootstrap(diffs)
    print(f"\n  Hierarchical bootstrap {proposed}-{comparator}: "
          f"{mean:+.2f} pts, 95% CI [{lo:+.2f}, {hi:+.2f}]")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["benchmark", "channels", "efficiency", "frozen", "stats"])
    ap.add_argument("--datasets", default="2a,2b,PhysioNet,HGD")
    ap.add_argument("--root", default="/data")
    ap.add_argument("--epochs", type=int, default=500)
    a = ap.parse_args()
    dsets = tuple(a.datasets.split(","))
    if a.cmd == "benchmark":
        benchmark(dsets, a.root, a.epochs)
    elif a.cmd == "channels":
        channels(a.root, a.epochs)
    elif a.cmd == "efficiency":
        efficiency(dsets, a.root, a.epochs)
    elif a.cmd == "frozen":
        frozen(a.root, a.epochs)
    elif a.cmd == "stats":
        run_stats()
