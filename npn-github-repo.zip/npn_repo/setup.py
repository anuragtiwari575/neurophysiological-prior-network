from setuptools import setup, find_packages

setup(
    name="npn",
    version="1.0.0",
    description="Neurophysiologically-Primed Network for motor-imagery EEG decoding",
    packages=find_packages(exclude=["tests", "scripts"]),
    python_requires=">=3.9",
    install_requires=[
        "numpy>=1.23", "scipy>=1.9", "scikit-learn>=1.1", "pandas>=1.5",
        "matplotlib>=3.6", "mne>=1.3", "pyriemann>=0.5", "torch>=1.13",
    ],
)
